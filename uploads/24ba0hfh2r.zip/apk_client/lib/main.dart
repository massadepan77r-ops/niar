import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:convert';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'APK Builder',
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.blue,
        scaffoldBackgroundColor: Color(0xFF0A1628),
      ),
      home: LoginPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// ==================== LOGIN PAGE ====================
class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _username = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final TextEditingController _serverUrl = TextEditingController();
  bool _loading = false;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _serverUrl.text = prefs.getString('server_url') ?? 'http://xnael.rzhosts.my.id:2626';
    });
  }

  Future<void> _login() async {
    if (_username.text.isEmpty || _password.text.isEmpty) {
      setState(() => _error = 'Isi semua field!');
      return;
    }
    setState(() => _loading = true);
    setState(() => _error = '');
    
    try {
      final res = await http.post(
        Uri.parse('${_serverUrl.text}/login'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {'username': _username.text, 'password': _password.text},
      );
      
      if (res.statusCode == 200) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('username', _username.text);
        await prefs.setString('server_url', _serverUrl.text);
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DashboardPage()));
      } else {
        setState(() => _error = 'Login gagal!');
      }
    } catch (e) {
      setState(() => _error = 'Server tidak terhubung!');
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.build_circle, size: 80, color: Colors.blue),
              SizedBox(height: 20),
              Text('APK Builder', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.blue)),
              Text('Build APK dari HP', style: TextStyle(color: Colors.grey)),
              SizedBox(height: 30),
              if (_error.isNotEmpty) Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.red.withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                child: Text(_error, style: TextStyle(color: Colors.red)),
              ),
              TextField(
                controller: _serverUrl,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Server URL',
                  labelStyle: TextStyle(color: Colors.grey),
                  enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey), borderRadius: BorderRadius.circular(10)),
                  focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.blue), borderRadius: BorderRadius.circular(10)),
                  prefixIcon: Icon(Icons.link, color: Colors.grey),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: _username,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Username',
                  labelStyle: TextStyle(color: Colors.grey),
                  enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey), borderRadius: BorderRadius.circular(10)),
                  focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.blue), borderRadius: BorderRadius.circular(10)),
                  prefixIcon: Icon(Icons.person, color: Colors.grey),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: _password,
                obscureText: true,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Password',
                  labelStyle: TextStyle(color: Colors.grey),
                  enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey), borderRadius: BorderRadius.circular(10)),
                  focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.blue), borderRadius: BorderRadius.circular(10)),
                  prefixIcon: Icon(Icons.lock, color: Colors.grey),
                ),
              ),
              SizedBox(height: 20),
              _loading 
                ? CircularProgressIndicator() 
                : ElevatedButton(
                    onPressed: _login,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      minimumSize: Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: Text('LOGIN', style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================== DASHBOARD PAGE ====================
class DashboardPage extends StatefulWidget {
  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  Map _stats = {};
  List _queue = [];
  List _building = [];
  bool _loading = true;
  String _username = '';
  String _serverUrl = '';
  String _selectedFile = '';
  bool _isBuilding = false;
  int _progress = 0;
  String _status = '';

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    _username = prefs.getString('username') ?? '';
    _serverUrl = prefs.getString('server_url') ?? 'http://panel:3000';
    setState(() => _loading = true);
    
    try {
      final res = await http.get(Uri.parse('$_serverUrl/api/stats'));
      if (res.statusCode == 200) {
        final data = json.decode(res.body);
        setState(() {
          _stats = data['stats'] ?? {};
          _queue = data['queue'] ?? [];
          _building = data['building'] ?? [];
        });
      }
    } catch (e) {}
    setState(() => _loading = false);
  }

  Future<void> _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip'],
    );
    if (result != null) {
      setState(() {
        _selectedFile = result.files.single.name;
      });
    }
  }

  Future<void> _startBuild() async {
    if (_selectedFile.isEmpty) {
      Fluttertoast.showToast(msg: "❌ Pilih file ZIP dulu!", backgroundColor: Colors.red);
      return;
    }

    setState(() {
      _isBuilding = true;
      _progress = 0;
      _status = 'Mengirim file...';
    });

    for (int i = 0; i <= 100; i += 10) {
      await Future.delayed(Duration(milliseconds: 300));
      setState(() {
        _progress = i;
        if (i < 30) _status = '📤 Uploading...';
        else if (i < 60) _status = '⚙️ Building...';
        else if (i < 90) _status = '📦 Packaging...';
        else _status = '✅ Selesai!';
      });
    }

    Fluttertoast.showToast(msg: "✅ Build berhasil!", backgroundColor: Colors.green);

    setState(() {
      _isBuilding = false;
      _selectedFile = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
        backgroundColor: Color(0xFF0A1628),
        actions: [
          IconButton(icon: Icon(Icons.logout), onPressed: () async {
            final prefs = await SharedPreferences.getInstance();
            await prefs.remove('username');
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginPage()));
          }),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadData,
        child: _loading 
          ? Center(child: CircularProgressIndicator()) 
          : SingleChildScrollView(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  // Stats
                  Row(children: [
                    _buildStatCard('✅ Sukses', _stats['success']?.toString() ?? '0', Colors.green),
                    SizedBox(width: 10),
                    _buildStatCard('❌ Gagal', _stats['failed']?.toString() ?? '0', Colors.red),
                    SizedBox(width: 10),
                    _buildStatCard('📋 Antrian', _queue.length.toString(), Colors.orange),
                    SizedBox(width: 10),
                    _buildStatCard('⚙️ Build', _building.length.toString(), Colors.cyan),
                  ]),
                  SizedBox(height: 20),
                  
                  // Upload Area
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Color(0xFF1A2A4A),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.blue.withOpacity(0.3)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('📦 Upload Project', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue)),
                        SizedBox(height: 10),
                        GestureDetector(
                          onTap: _isBuilding ? null : _pickFile,
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.all(30),
                            decoration: BoxDecoration(
                              border: Border.all(color: _isBuilding ? Colors.grey : Colors.blue, width: 2),
                              borderRadius: BorderRadius.circular(12),
                              color: Colors.blue.withOpacity(0.05),
                            ),
                            child: Column(
                              children: [
                                Icon(_isBuilding ? Icons.hourglass_empty : Icons.cloud_upload, 
                                     size: 40, color: _isBuilding ? Colors.grey : Colors.blue),
                                SizedBox(height: 10),
                                Text(
                                  _selectedFile.isEmpty ? 'Tap untuk pilih file ZIP' : _selectedFile,
                                  style: TextStyle(color: _selectedFile.isEmpty ? Colors.grey : Colors.blue),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: 10),
                        if (_isBuilding) ...[
                          LinearProgressIndicator(value: _progress / 100, backgroundColor: Colors.grey, color: Colors.blue),
                          SizedBox(height: 5),
                          Text('$_progress% - $_status', style: TextStyle(color: Colors.grey, fontSize: 12)),
                        ],
                        SizedBox(height: 10),
                        ElevatedButton(
                          onPressed: _isBuilding || _selectedFile.isEmpty ? null : _startBuild,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            minimumSize: Size(double.infinity, 45),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                          child: Text(
                            _isBuilding ? 'PROSES...' : '🔥 BUILD APK',
                            style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  SizedBox(height: 20),
                  
                  // Queue & Building
                  if (_building.isNotEmpty) ...[
                    Text('🔄 Sedang Build', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.cyan)),
                    ..._building.map((j) => Card(
                      child: ListTile(
                        title: Text(j['name'] ?? 'Project'),
                        subtitle: Text('Building...'),
                        trailing: Icon(Icons.build, color: Colors.cyan),
                      ),
                    )),
                  ],
                  if (_queue.isNotEmpty) ...[
                    SizedBox(height: 10),
                    Text('⏳ Antrian', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.orange)),
                    ..._queue.map((j) => Card(
                      child: ListTile(
                        title: Text(j['name'] ?? 'Project'),
                        subtitle: Text('Queue #${_queue.indexOf(j)+1}'),
                        trailing: Icon(Icons.access_time, color: Colors.orange),
                      ),
                    )),
                  ],
                  if (_building.isEmpty && _queue.isEmpty) 
                    Padding(padding: EdgeInsets.all(20), child: Text('✨ Tidak ada antrian', style: TextStyle(color: Colors.grey))),
                ],
              ),
            ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _loadData,
        child: Icon(Icons.refresh),
        backgroundColor: Colors.blue,
      ),
    );
  }

  Widget _buildStatCard(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Color(0xFF1A2A4A),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
            Text(label, style: TextStyle(fontSize: 10, color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}