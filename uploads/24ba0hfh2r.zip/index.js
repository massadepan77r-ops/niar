const { Telegraf, Markup } = require("telegraf");
const fs = require("fs");
const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const multer = require("multer");
const fetch = require("node-fetch");

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 1024 * 1024 * 1024 }
});

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(__dirname));

// ================= CONFIG =================
const BOT_TOKEN = "8676066891:AAGFsYuyAi3HP8XLqp_lVzGw6p58_aTVjaI";
const GITHUB_TOKEN = "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";
const OWNER = "kinong12";
const REPO = "kinong12";
const BRANCH = "main";
const WORKFLOW_FILE = "flutter_build_apk.yml";
const OWNER_ID = 8289001931;
const BUILD_CHANNEL_ID = -1003840876260;
const PANEL_PORT = process.env.PORT || 4867;
const ADMIN_ID = 8289001931;
const WEB_LOGIN_URL = "http://xnael.rzhosts.my.id:2626";
const PANEL_URL = "http://xnael.rzhosts.my.id:2626/health";

// ========= MAINTENANCE (INTERNAL) =========
let maintenanceMode = false;

async function maintanceGuard(ctx) {
  if (maintenanceMode && !isOwner(ctx.from?.id)) {
    await ctx.reply("🔧 Bot sedang dalam maintenance. Coba lagi nanti.");
    return false;
  }
  return true;
}

async function writeState(state) {
  maintenanceMode = state;
  return state;
}

const LIXX_DEP = OWNER_ID;

// ========= BLOCKED USERS =========
const blockedUsers = new Set();

// ================= STORAGE =================
const LIMIT_FILE = path.join(process.cwd(), "limits.json");
const JOB_FILE = path.join(process.cwd(), "jobs.json");
const USER_FILE = path.join(process.cwd(), "user.json");
const KEY_FILE = path.join(process.cwd(), "data", "keys.json");
const DATA_DIR = path.join(process.cwd(), "data");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(USER_FILE)) fs.writeFileSync(USER_FILE, "[]", "utf8");
if (!fs.existsSync(LIMIT_FILE)) fs.writeFileSync(LIMIT_FILE, "{}", "utf8");
if (!fs.existsSync(JOB_FILE)) fs.writeFileSync(JOB_FILE, "{}", "utf8");
if (!fs.existsSync(KEY_FILE)) fs.writeFileSync(KEY_FILE, "{}", "utf8");

// ================= HELPERS =================
function readJson(p) {
  try {
    const raw = fs.readFileSync(p, "utf8");
    return JSON.parse(raw);
  } catch {
    if (p === USER_FILE) return [];
    return {};
  }
}

function writeJson(p, obj) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(obj, null, 2), "utf8");
}

function getUsers() {
  const arr = readJson(USER_FILE);
  return Array.isArray(arr) ? arr : [];
}

function saveUser(userId) {
  const users = getUsers();
  const id = Number(userId);
  if (!users.includes(id)) {
    users.push(id);
    writeJson(USER_FILE, users);
  }
}

function isOwner(userId) {
  return Number(userId) === Number(OWNER_ID);
}

function randomJobId() {
  return Math.random().toString(36).substring(2, 12);
}

function makeBar(pct) {
  const total = 18;
  const filled = Math.max(0, Math.min(total, Math.round((pct / 100) * total)));
  const empty = total - filled;
  return `[` + "█".repeat(filled) + "░".repeat(empty) + `] ${pct}%`;
}

function box(text) {
  return `<blockquote><pre>${text}</pre></blockquote>`;
}

// ================= LIMIT SYSTEM =================
function getUserLimit(userId) {
  if (isOwner(userId)) return Infinity;
  const db = readJson(LIMIT_FILE);
  if (db[userId] === undefined) db[userId] = 3;
  if (typeof db[userId] === 'object' && db[userId].unlimited) return Infinity;
  return Number(db[userId]?.limit ?? db[userId] ?? 0);
}

function setUserLimit(userId, val) {
  const db = readJson(LIMIT_FILE);
  db[userId] = Number(val);
  writeJson(LIMIT_FILE, db);
}

function addUserLimit(userId, add) {
  const cur = getUserLimit(userId);
  if (cur === Infinity) return Infinity;
  const next = cur + Number(add);
  setUserLimit(userId, next);
  return next;
}

function consumeLimit(userId) {
  if (isOwner(userId)) return Infinity;
  const cur = getUserLimit(userId);
  if (cur <= 0) return 0;
  setUserLimit(userId, cur - 1);
  return cur - 1;
}

// ================= QUEUE SYSTEM =================
let busyUserId = null;
let queue = [];

function inQueue(userId) {
  return queue.findIndex(q => Number(q.userId) === Number(userId));
}

function queuePosition(userId) {
  const idx = inQueue(userId);
  return idx >= 0 ? idx + 1 : null;
}

function getQueueText() {
  const lines = [];
  if (busyUserId) lines.push(`SEDANG BUILD: ${busyUserId}`);
  else lines.push(`SEDANG BUILD: -`);
  if (queue.length === 0) lines.push(`ANTRIAN: kosong`);
  else {
    lines.push(`ANTRIAN:`);
    queue.forEach((q, i) => lines.push(`${i + 1}. ${q.userId}`));
  }
  return lines.join("\n");
}

// ================= JOB SYSTEM =================
function saveJob(jobId, meta) {
  const db = readJson(JOB_FILE);
  db[jobId] = meta;
  writeJson(JOB_FILE, db);
}

function getJob(jobId) {
  const db = readJson(JOB_FILE);
  return db[jobId] || null;
}

// ================= KEY SYSTEM =================
function getKeys() {
  return readJson(KEY_FILE) || {};
}

function checkKey(userId, key) {
  const db = getKeys();
  return String(db[userId] || "") === String(key || "");
}

// ================= GITHUB HELPERS =================
function ghHeaders(extra = {}) {
  return {
    Authorization: `Bearer ${GITHUB_TOKEN}`,
    "X-GitHub-Api-Version": "2022-11-28",
    Accept: "application/vnd.github+json",
    ...extra,
  };
}

async function uploadToRepo(repoPath, buffer, message) {
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/contents/${repoPath}`;
  const body = {
    message,
    content: buffer.toString("base64"),
    branch: BRANCH,
  };
  const res = await fetch(url, {
    method: "PUT",
    headers: ghHeaders({ "Content-Type": "application/json" }),
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error("Upload gagal: " + txt);
  }
  return await res.json();
}

async function dispatchWorkflow(jobId, { zipPath = "", zipUrl = "" } = {}) {
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/actions/workflows/${WORKFLOW_FILE}/dispatches`;
  const body = {
    ref: BRANCH,
    inputs: {
      job_id: String(jobId),
      zip_path: String(zipPath || ""),
      zip_url: String(zipUrl || ""),
    },
  };
  const res = await fetch(url, {
    method: "POST",
    headers: ghHeaders({ "Content-Type": "application/json" }),
    body: JSON.stringify(body),
  });
  if (!(res.status === 204 || res.ok)) {
    const txt = await res.text();
    throw new Error("Trigger workflow gagal: " + txt);
  }
}

async function listWorkflowRuns() {
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/actions/workflows/${WORKFLOW_FILE}/runs?branch=${BRANCH}&event=workflow_dispatch&per_page=10`;
  const res = await fetch(url, { headers: ghHeaders() });
  if (!res.ok) throw new Error("Gagal list workflow runs: " + (await res.text()));
  return await res.json();
}

async function getRunById(runId) {
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/actions/runs/${runId}`;
  const res = await fetch(url, { headers: ghHeaders() });
  if (!res.ok) throw new Error("Gagal ambil status run: " + (await res.text()));
  return await res.json();
}

async function getArtifact(jobId) {
  const job = getJob(jobId);
  if (job?.run_id) {
    const runUrl = `https://api.github.com/repos/${OWNER}/${REPO}/actions/runs/${job.run_id}/artifacts`;
    const runRes = await fetch(runUrl, { headers: ghHeaders() });
    if (!runRes.ok) throw new Error("Gagal ambil artifacts run: " + (await runRes.text()));
    const runData = await runRes.json();
    const runArts = runData.artifacts || [];
    const exactName = `apk-${jobId}`;
    let found = runArts.find(a => a.name === exactName && !a.expired);
    if (!found) found = runArts.find(a => String(a.name || "").includes(jobId) && !a.expired);
    if (!found) {
      found = runArts
        .filter(a => !a.expired)
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
    }
    return found || null;
  }
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/actions/artifacts?per_page=100`;
  const res = await fetch(url, { headers: ghHeaders() });
  if (!res.ok) throw new Error("Gagal ambil artifact list: " + (await res.text()));
  const data = await res.json();
  const arts = data.artifacts || [];
  const exactName = `apk-${jobId}`;
  let found = arts.find(a => a.name === exactName && !a.expired);
  if (!found) found = arts.find(a => String(a.name || "").includes(jobId) && !a.expired);
  if (!found) {
    found = arts
      .filter(a => !a.expired)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
  }
  return found || null;
}

async function downloadArtifactZip(id) {
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/actions/artifacts/${id}/zip`;
  const res = await fetch(url, { headers: ghHeaders() });
  if (!res.ok) throw new Error("Gagal download artifact");
  return Buffer.from(await res.arrayBuffer());
}

async function downloadTelegramFile(ctx, fileId) {
  const link = await ctx.telegram.getFileLink(fileId);
  const res = await fetch(link.href);
  if (!res.ok) throw new Error("Gagal download file Telegram");
  return Buffer.from(await res.arrayBuffer());
}

// ================= IS JOIN CHANNEL (1 CHANNEL: @informationreallyyy) =================
async function isJoinChannel(ctx) {
  const userId = ctx.from?.id;
  if (!userId) return false;
  
  try {
    const ch = await ctx.telegram.getChatMember('@informationreallyyy', userId);
   
    if (ch.status === 'left' || ch.status === 'kicked') {
      await ctx.reply(
        '❌ Kamu belum join channel!\n\n👉 Wajib join Channel dulu untuk menggunakan bot.',
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: '📢 Join Channel', url: 'https://t.me/informationreallyyy' }],
              [{ text: '🔄 Refresh', callback_data: 'cek_join' }]
            ]
          }
        }
      );
      return false;
    }

    return true;

  } catch (err) {
    console.log("Error isJoinChannel:", err.message);
    return true;
  }
}

// ================= PROGRESS BAR =================
const ACTIVE_PROGRESS = new Set();

async function runProgress(ctx, chatId, msgId, jobId) {
  const key = `${chatId}:${msgId}`;
  if (ACTIVE_PROGRESS.has(key)) return;
  ACTIVE_PROGRESS.add(key);
  const start = Date.now();
  const steps = [10, 18, 27, 36, 45, 55, 66, 76, 85, 92, 97];
  let idx = 0;
  try {
    while (true) {
      const job = getJob(jobId);
      let statusText = "queued";
      let conclusion = null;
      try {
        const artifact = await getArtifact(jobId);
        if (artifact) {
          await ctx.telegram.editMessageText(
            chatId, msgId, undefined,
            box(
              `PROSES BUILD APK\nJOB: ${jobId}\nSTATUS: completed\n${makeBar(100)}\n\n🟢 BUILD SELESAI: SUCCESS\n\nAMBIL APK:\n/getapk ${jobId}`
            ),
            { parse_mode: "HTML" }
          );
          break;
        }
      } catch {}
      if (job?.run_id) {
        try {
          const run = await getRunById(job.run_id);
          statusText = run.status;
          conclusion = run.conclusion;
          if (statusText === "completed") {
            const line = conclusion === "success"
              ? `🟢 BUILD SELESAI: SUCCESS`
              : `🔴 BUILD SELESAI: FAILED (${conclusion})`;
            await ctx.telegram.editMessageText(
              chatId, msgId, undefined,
              box(
                `PROSES BUILD APK\nJOB: ${jobId}\nSTATUS: ${statusText}\n${makeBar(100)}\n\n${line}\n` +
                (conclusion === "success" ? `\nAMBIL APK:\n/getapk ${jobId}` : `\nKIRIM SCREENSHOT ERROR DARI LOG`)
              ),
              { parse_mode: "HTML" }
            );
            break;
          }
        } catch {}
      }
      const elapsedSec = Math.floor((Date.now() - start) / 1000);
      if (elapsedSec >= 10 && idx < 2) idx = 2;
      if (idx < steps.length) {
        const gate = 18 * idx + 1;
        if (elapsedSec >= gate) idx++;
      }
      let pct = steps[Math.min(idx, steps.length - 1)];
      if (statusText === "queued") pct = Math.min(pct, 20);
      if (statusText === "in_progress") pct = Math.max(pct, 35);
      try {
        await ctx.telegram.editMessageText(
          chatId, msgId, undefined,
          box(
            `PROSES BUILD APK\nJOB: ${jobId}\nSTATUS: ${statusText}\n${makeBar(pct)}\n\n⏳ Sedang build...`
          ),
          { parse_mode: "HTML" }
        );
      } catch {}
      await new Promise((r) => setTimeout(r, 6000));
    }
  } finally {
    ACTIVE_PROGRESS.delete(key);
  }
}

// ================= MAIN MENU =================
function mainMenu() {
  return {
    reply_markup: {
      inline_keyboard: [
        [
          { text: "📥 BUILDING APK", callback_data: "MENU_BUILD", style: "danger" },
          { text: "✨ ANTRIAN", callback_data: "MENU_QUEUE", style: "success" },
        ],
        [
          { text: "🔐 PANDUAN", callback_data: "MENU_GUIDE", style: "primary" },
          { text: "🔴 SERVER STATUS", callback_data: "MENU_SERVER", style: "danger" },
        ],
        [
          { text: "📜 TQTO", callback_data: "MENU_TQTO", style: "success" },
          { text: "👤 CHAT ADMIN", callback_data: "MENU_CHAT_ADMIN", style: "primary" },
        ],
        [
          { text: "👥 TOTAL USER", callback_data: "MENU_TOTAL_USER", style: "success" },
          { text: "👤 ADMIN", url: "https://t.me/wh4tyou", style: "primary" },
        ],
      ],
    },
  };
}

// ================= BOT =================
const bot = new Telegraf(BOT_TOKEN);

bot.use(async (ctx, next) => {
  try {
    const uid = ctx.from?.id;
    if (uid) saveUser(uid);
  } catch {}
  return next();
});

bot.action('cek_join', async (ctx) => {
  await ctx.answerCbQuery();
  if (await isJoinChannel(ctx)) {
    await ctx.editMessageText('✅ Akses berhasil! Sekarang kamu bisa menggunakan bot.');
  }
});

// ================= START COMMAND =================
bot.start(async (ctx) => {
  if (!(await isJoinChannel(ctx))) return;
  if (blockedUsers.has(ctx.from.id)) {
    return ctx.reply("❌ Kamu telah diblokir dari bot.");
  }
  if (!(await maintanceGuard(ctx))) return;
  const text =
    `✨𝖲𝗉𝗂𝗇𝗂𝖼 𝖡𝗎𝗂𝗅𝖽𝗂𝗇𝗀✨

*𝖨𝗇𝖿𝗈𝗋𝗆𝖺𝗍𝗂𝗈𝗇 𝖲𝗍𝖺𝗍𝗎𝗌*
𝖡𝗈𝗍 𝖨𝗌 𝖱𝗎𝗇𝗇𝗂𝗇𝗀: 𝖠𝖼𝗍𝗂𝗏𝖾
𝖮𝗐𝗇𝖾𝗋: @wh4tyou
𝖳𝗒𝗉𝖾 𝖲𝖼𝗋𝗂𝗉𝗍: 𝖩𝖺𝗏𝖺𝖲𝖼𝗋𝗂𝗉𝗍 
──────────────────────────────────
*𝖲𝗉𝖾𝗌𝗂𝖿𝗂𝗄𝖺𝗌𝗂 𝖡𝗈𝗍*
──────────────────────────────────
🚀 Unlimited Build (Tanpa limit harian)
⚡ Prioritas Tanpa Antrian (Auto diproses duluan)
📦 Support File .AAB (Siap upload PlayStore)
🛡️ Anti Cooldown (No delay antar build)
🔥 Build Lebih Cepat & Stabil
☁️ Auto Upload (File besar langsung ke Drive)
──────────────────────────────────
CREATOR'S COUNTRY OF ORIGIN : 🇲🇨
this is bot build apps 𝖿𝗅𝗎𝗍𝖾𝗋!`;
  await ctx.replyWithVideo(
    "https://files.catbox.moe/pjmurw.mp4",
    {
      caption: box(text),
      parse_mode: "HTML",
      ...mainMenu(),
    }
  );
});

// ================= MENU ACTIONS =================
bot.action("MENU_BUILD", async (ctx) => {
  await ctx.answerCbQuery();
  const t =
    `⚠️BUILDING APK\n\nSILAHKAN KIRIM FILE .ZIP\nLALU REPLY FILE TERSEBUT DENGAN TEKS:\n/buildapk\n\nNOTE:\n- ZIP harus berisi project Flutter (pubspec.yaml ada)\n- Jangan spam, pakai menu ANTRIAN untuk cek.\n`;
  await ctx.reply(box(t), { parse_mode: "HTML" });
});

bot.action("MENU_GUIDE", async (ctx) => {
  await ctx.answerCbQuery();
  const t =
    `✍️PANDUAN MENGGUNAKAN BOT\n\n1) KIRIM FILE .ZIP PROJECT FLUTTER\n2) REPLY FILE .ZIP ITU\n3) KETIK: /buildapk\n4) TUNGGU PROGRESS BAR\n5) KALAU SUCCESS, AMBIL HASIL: /getapk Id antrian\n\nCEK STATUS:\n/status id antrian\n\nLIMIT:\n- USER BIASA: 3x build\n- TERIMA KASIH TELAH MENGGUNAKAN BOT XEZPHERZ\n`;
  await ctx.reply(box(t), { parse_mode: "HTML" });
});

bot.action("MENU_QUEUE", async (ctx) => {
  await ctx.answerCbQuery();
  await ctx.reply(box(getQueueText()), { parse_mode: "HTML" });
});

bot.action("MENU_SERVER", async (ctx) => {
  await ctx.answerCbQuery("Ngecek ping panel...");
  try {
    const controller = new AbortController();
    const t = setTimeout(() => controller.abort(), 4000);
    const res = await fetch(PANEL_URL, { signal: controller.signal });
    clearTimeout(t);
    const vpsLine = res.ok ? `🟢 PANEL: ONLINE` : `🔴 PANEL: OFFLINE`;
    return ctx.reply(
      box(`⚙️ SERVER STATUS\n\n${vpsLine}\n🟣 BOT: ONLINE\n\nSERVER TER VERIFIKASI`),
      { parse_mode: "HTML" }
    );
  } catch (e) {
    return ctx.reply(box(`⚙️ SERVER STATUS\n\n🔴 PANEL: OFFLINE\n🟣 BOT: ONLINE`), { parse_mode: "HTML" });
  }
});

bot.action("MENU_TQTO", async (ctx) => {
  await ctx.answerCbQuery();
  return ctx.reply(
    box(`💯 TQTO SPECIAL THANKS\n\n👑 DanzOfficial\n🔥 all friends\n\nTERIMA KASIH SUDAH SUPPORT XENO`),
    { parse_mode: "HTML" }
  );
});

bot.action("MENU_TOTAL_USER", async (ctx) => {
  await ctx.answerCbQuery();
  const users = getUsers();
  return ctx.reply(`👥 TOTAL USER: ${users.length}`);
});

// ================= CHAT ADMIN =================
const pendingChat = {};

bot.action("MENU_CHAT_ADMIN", async (ctx) => {
  const userId = ctx.from.id;
  pendingChat[userId] = { waiting: true, message: null };
  await ctx.answerCbQuery();
  return ctx.reply(
    "👤 *Chat Admin*\n\nSilahkan kirim pesan yang ingin disampaikan ke admin.",
    { parse_mode: "Markdown" }
  );
});

bot.on("text", async (ctx, next) => {
  const userId = ctx.from.id;
  const s = pendingChat[userId];
  if (s?.waiting) {
    s.waiting = false;
    s.message = ctx.message.text;
    return ctx.reply(
      `📨 *Konfirmasi Pesan*\n\n${s.message}\n\nKirim ke admin?`,
      {
        parse_mode: "Markdown",
        ...Markup.inlineKeyboard([
          [
            Markup.button.callback("📨 Kirim Admin", `SEND_ADMIN:${userId}`),
            Markup.button.callback("❌ Batal", `CANCEL_ADMIN:${userId}`)
          ]
        ])
      }
    );
  }
  return next();
});

bot.action(/^SEND_ADMIN:(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery("Mengirim...");
  const userId = Number(ctx.match[1]);
  const data = pendingChat[userId];
  if (!data?.message) {
    return ctx.reply("❌ Tidak ada pesan yang bisa dikirim.");
  }
  await bot.telegram.sendMessage(
    ADMIN_ID,
    `📩 *Pesan Baru*\n\n👤 Dari ID: \`${userId}\`\n🧑 Nama: ${ctx.from.first_name || "-"}\n\n💬 Pesan:\n${data.message}`,
    { parse_mode: "Markdown" }
  );
  delete pendingChat[userId];
  await ctx.editMessageReplyMarkup({ inline_keyboard: [] }).catch(() => {});
  return ctx.reply("✅ Pesan sudah dikirim ke admin.");
});

bot.action(/^CANCEL_ADMIN:(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery("Dibatalkan");
  const userId = Number(ctx.match[1]);
  delete pendingChat[userId];
  await ctx.editMessageReplyMarkup({ inline_keyboard: [] }).catch(() => {});
  return ctx.reply("❌ Dibatalkan. Tekan *Chat Admin* lagi kalau mau kirim pesan.", { parse_mode: "Markdown" });
});

// ================= COMMANDS =================
bot.command("status", async (ctx) => {
  try {
    const parts = (ctx.message.text || "").trim().split(/\s+/);
    const jobId = parts[1];
    if (!jobId) return ctx.reply(box("FORMAT:\n/status <jobId>"), { parse_mode: "HTML" });
    const job = getJob(jobId);
    if (!job) return ctx.reply(box("JOB TIDAK DITEMUKAN"), { parse_mode: "HTML" });
    if (!job.run_id) {
      return ctx.reply(box("RUN ID BELUM ADA. COBA LAGI SEBENTAR."), { parse_mode: "HTML" });
    }
    const run = await getRunById(job.run_id);
    const line =
      `STATUS BUILD APK\nJOB ANTRIAN: ${jobId}\nSTATUS: ${run.status}\nCONCLUSION: ${run.conclusion || "-"}\nLOG: ${run.html_url}\n`;
    return ctx.reply(box(line), { parse_mode: "HTML" });
  } catch (e) {
    return ctx.reply(box("ERROR:\n" + e.message), { parse_mode: "HTML" });
  }
});

bot.command("getapk", async (ctx) => {
  try {
    const parts = (ctx.message.text || "").trim().split(/\s+/);
    const jobId = parts[1];
    if (!jobId) return ctx.reply(box("FORMAT:\n/getapk jobantrian"), { parse_mode: "HTML" });
    await ctx.reply(box("🔎 MENCARI APK..."), { parse_mode: "HTML" });
    const artifact = await getArtifact(jobId);
    if (!artifact) return ctx.reply(box("⏳ BELUM ADA ARTIFACT.\nCEK STATUS:\n/status " + jobId), { parse_mode: "HTML" });
    const zipBuffer = await downloadArtifactZip(artifact.id);
    await ctx.replyWithDocument(
      { source: zipBuffer, filename: `apk-${jobId}.zip` },
      { caption: box(`✅ APK SIAP (DALAM ZIP)\nANTRIAN: ${jobId}`), parse_mode: "HTML" }
    );
  } catch (e) {
    return ctx.reply(box("❌ ERROR:\n" + e.message), { parse_mode: "HTML" });
  }
});

bot.command("ceklimit", async (ctx) => {
  const userId = ctx.from?.id;
  if (isOwner(userId)) {
    return ctx.reply(box("LIMIT KAMU: UNLIMITED (OWNER)"), { parse_mode: "HTML" });
  }
  const sisa = getUserLimit(userId);
  return ctx.reply(box(`CEK LIMIT\nUSER: ${userId}\nSISA LIMIT: ${sisa}`), { parse_mode: "HTML" });
});

bot.command("antrian", async (ctx) => {
  return ctx.reply(box(getQueueText()), { parse_mode: "HTML" });
});

// ================= BUILDAPK =================
bot.command("buildapk", async (ctx) => {
  if (blockedUsers.has(ctx.from.id)) {
    return ctx.reply("❌ Kamu telah diblokir dari bot.");
  }
  if (!(await maintanceGuard(ctx))) return;
  if (!(await isJoinChannel(ctx))) return;

  const userId = ctx.from?.id;
  const chatId = ctx.chat?.id;

  try {
    const replied = ctx.message.reply_to_message;
    const doc = replied?.document;
    if (!doc) {
      return ctx.reply(box("❌ REPLY FILE .ZIP PROJECT FLUTTER LALU KETIK /buildapk"), { parse_mode: "HTML" });
    }
    if (!String(doc.file_name || "").toLowerCase().endsWith(".zip")) {
      return ctx.reply(box("❌ FILE HARUS .ZIP"), { parse_mode: "HTML" });
    }
    if (!isOwner(userId)) {
      const limit = getUserLimit(userId);
      if (limit <= 0) {
        return ctx.reply(box("LIMIT HABIS ❌\n\nKAMU SUDAH PAKAI 3x.\nHUBUNGI ADMIN UNTUK TAMBAH LIMIT."), { parse_mode: "HTML" });
      }
    }
    if (!isOwner(userId)) {
      if (busyUserId && Number(busyUserId) !== Number(userId)) {
        const pos = queuePosition(userId);
        if (pos) {
          return ctx.reply(box(`SEDANG ADA USER LAIN YG MENGGUNAKAN\nKAMU MASIH DI ANTRIAN KE ${pos}\n\nCEK MENU: ANTRIAN`), { parse_mode: "HTML" });
        }
        queue.push({ userId, chatId });
        const myPos = queuePosition(userId);
        return ctx.reply(box(`SEDANG ADA USER LAIN YG MENGGUNAKAN\nKAMU ANTRIAN KE ${myPos}\n\nCEK MENU: ANTRIAN`), { parse_mode: "HTML" });
      }
      busyUserId = userId;
    }
    if (!isOwner(userId)) {
      const left = consumeLimit(userId);
      await ctx.reply(box(`LIMIT TERPAKAI 1x ✅\nSISA LIMIT KAMU: ${left}`), { parse_mode: "HTML" });
    }
    const jobId = randomJobId();
    const zipPath = `uploads/${jobId}.zip`;
    try {
      await ctx.telegram.sendMessage(
        BUILD_CHANNEL_ID,
        box(`🚨 PROSES BUILD APK\n👤 USER: ${userId}\n📜 ANTRIAN: ${jobId}\n🔴 MODE: ZIP UPLOAD\n🖥️REPO: [HIDDEN]\n🌐 STATUS: BUILD DIMULAI ✅`),
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "👤 BUKA PROFILE USER", url: `tg://user?id=${userId}` }]
            ]
          }
        }
      );
    } catch (e) {
      console.log("CHANNEL NOTIF ERROR:", e?.message);
    }
    const progressMsg = await ctx.reply(box(`PROSES BUILD APK\nJOB: ${jobId}\nSTATUS: starting\n${makeBar(0)}\n\n⏳ Sedang mulai...`), { parse_mode: "HTML" });
    await ctx.telegram.editMessageText(chatId, progressMsg.message_id, undefined, box(`PROSES BUILD APK\nJOB: ${jobId}\nSTATUS: downloading\n${makeBar(8)}\n\n📥 Downloading file...`), { parse_mode: "HTML" });
    const buffer = await downloadTelegramFile(ctx, doc.file_id);
    await ctx.telegram.editMessageText(chatId, progressMsg.message_id, undefined, box(`PROSES BUILD APK\nJOB: ${jobId}\nSTATUS: uploading\n${makeBar(18)}\n\n⬆️ Uploading...`), { parse_mode: "HTML" });
    await uploadToRepo(zipPath, buffer, `Upload job ${jobId}`);
    await ctx.telegram.editMessageText(chatId, progressMsg.message_id, undefined, box(`PROSES BUILD APK\nJOB: ${jobId}\nSTATUS: triggering\n${makeBar(25)}\n\n🚀 Triggering build...`), { parse_mode: "HTML" });
    const dispatchAt = Date.now();
    await dispatchWorkflow(jobId, { zipPath });
    let runId = null;
    let runUrl = null;
    for (let i = 0; i < 10; i++) {
      await new Promise((r) => setTimeout(r, 2500));
      const runsData = await listWorkflowRuns();
      const runs = runsData.workflow_runs || [];
      const candidate = runs
        .filter((r) => new Date(r.created_at).getTime() >= dispatchAt - 30000)
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
      const newest = candidate || runs[0];
      if (newest?.id) {
        runId = newest.id;
        runUrl = newest.html_url;
        break;
      }
    }
    saveJob(jobId, {
      job_id: jobId,
      zip_path: zipPath,
      zip_url: "",
      run_id: runId,
      run_url: runUrl,
      user_id: userId,
      created_at: new Date().toISOString(),
    });
    runProgress(ctx, chatId, progressMsg.message_id, jobId)
      .finally(() => {
        if (!isOwner(userId)) {
          busyUserId = null;
          if (queue.length > 0) {
            const next = queue.shift();
            busyUserId = next.userId;
            ctx.telegram.sendMessage(
              next.chatId,
              box(`ANTRIAN KAMU SEKARANG GILIRAN ✅\nSILAHKAN REPLY FILE .ZIP KAMU LALU KETIK /buildapk`),
              { parse_mode: "HTML" }
            ).catch(() => {});
          }
        }
      });
  } catch (e) {
    if (!isOwner(userId)) {
      try { addUserLimit(userId, 1); } catch {}
      if (busyUserId && Number(busyUserId) === Number(userId)) busyUserId = null;
    }
    return ctx.reply(box("❌ ERROR:\n" + (e?.message || String(e))), { parse_mode: "HTML" });
  }
});

// ================= BUILDURL =================
bot.command("buildurl", async (ctx) => {
  if (blockedUsers.has(ctx.from.id)) {
    return ctx.reply("❌ Kamu telah diblokir dari bot.");
  }
  if (!(await maintanceGuard(ctx))) return;
  if (!(await isJoinChannel(ctx))) return;
  const userId = ctx.from?.id;
  const chatId = ctx.chat?.id;
  try {
    const parts = (ctx.message.text || "").trim().split(/\s+/);
    const zipUrl = parts.slice(1).join(" ");
    if (!zipUrl) {
      return ctx.reply(box("FORMAT:\n/buildurl url_zip"), { parse_mode: "HTML" });
    }
    if (!isOwner(userId)) {
      const limit = getUserLimit(userId);
      if (limit <= 0) {
        return ctx.reply(box("LIMIT HABIS ❌\n\nKAMU SUDAH PAKAI 3x.\nHUBUNGI ADMIN UNTUK TAMBAH LIMIT."), { parse_mode: "HTML" });
      }
    }
    if (!isOwner(userId)) {
      if (busyUserId && Number(busyUserId) !== Number(userId)) {
        const pos = queuePosition(userId);
        if (pos) {
          return ctx.reply(box(`SEDANG ADA USER LAIN YG MENGGUNAKAN\nKAMU MASIH DI ANTRIAN KE ${pos}\n\nCEK MENU: ANTRIAN`), { parse_mode: "HTML" });
        }
        queue.push({ userId, chatId });
        const myPos = queuePosition(userId);
        return ctx.reply(box(`SEDANG ADA USER LAIN YG MENGGUNAKAN\nKAMU ANTRIAN KE ${myPos}\n\nCEK MENU: ANTRIAN`), { parse_mode: "HTML" });
      }
      busyUserId = userId;
    }
    if (!isOwner(userId)) {
      const left = consumeLimit(userId);
      await ctx.reply(box(`LIMIT TERPAKAI 1x ✅\nSISA LIMIT KAMU: ${left}`), { parse_mode: "HTML" });
    }
    const jobId = randomJobId();
    try {
      await ctx.telegram.sendMessage(
        BUILD_CHANNEL_ID,
        box(`🚨 PROSES BUILD APK\n👤 USER: ${userId}\n📜 ANTRIAN: ${jobId}\n🔴 MODE: URL MODE\n🖥️REPO: [HIDDEN]\n🌐 STATUS: BUILD DIMULAI ✅`),
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "👤 BUKA PROFILE USER", url: `tg://user?id=${userId}` }]
            ]
          }
        }
      );
    } catch (e) {
      console.log("CHANNEL NOTIF ERROR:", e?.message);
    }
    const progressMsg = await ctx.reply(
      box(`PROSES BUILD APK (URL)\nJOB: ${jobId}\nSTATUS: triggering\n${makeBar(25)}\n\n🚀 Triggering build...`),
      { parse_mode: "HTML" }
    );
    const dispatchAt = Date.now();
    await dispatchWorkflow(jobId, { zipUrl });
    let runId = null;
    let runUrl = null;
    for (let i = 0; i < 10; i++) {
      await new Promise((r) => setTimeout(r, 2500));
      const runsData = await listWorkflowRuns();
      const runs = runsData.workflow_runs || [];
      const candidate = runs
        .filter((r) => new Date(r.created_at).getTime() >= dispatchAt - 30000)
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
      const newest = candidate || runs[0];
      if (newest?.id) {
        runId = newest.id;
        runUrl = newest.html_url;
        break;
      }
    }
    saveJob(jobId, {
      job_id: jobId,
      zip_path: "",
      zip_url: zipUrl,
      run_id: runId,
      run_url: runUrl,
      user_id: userId,
      created_at: new Date().toISOString(),
    });
    runProgress(ctx, chatId, progressMsg.message_id, jobId)
      .finally(() => {
        if (!isOwner(userId)) {
          busyUserId = null;
          if (queue.length > 0) {
            const next = queue.shift();
            busyUserId = next.userId;
            ctx.telegram.sendMessage(
              next.chatId,
              box(`ANTRIAN KAMU SEKARANG GILIRAN ✅\nSILAHKAN KETIK:\n/buildurl <url_zip>`),
              { parse_mode: "HTML" }
            ).catch(() => {});
          }
        }
      })
      .catch(() => {});
    return ctx.reply(
      box(`✅ BUILD DIMULAI (URL)\nJOB: ${jobId}\n\n/getapk ${jobId}\n/status ${jobId}`),
      { parse_mode: "HTML" }
    );
  } catch (e) {
    if (!isOwner(userId)) {
      try { addUserLimit(userId, 1); } catch {}
      if (busyUserId && Number(busyUserId) === Number(userId)) busyUserId = null;
    }
    return ctx.reply(box("❌ ERROR:\n" + (e?.message || String(e))), { parse_mode: "HTML" });
  }
});

// ================= BROADCAST =================
bot.command("broadcast", async (ctx) => {
  const userId = ctx.from?.id;
  if (!isOwner(userId)) {
    return ctx.reply(box("AKSES DITOLAK: OWNER ONLY"), { parse_mode: "HTML" });
  }
  const replied = ctx.message?.reply_to_message;
  if (!replied) {
    return ctx.reply(
      box("CARANYA:\nREPLY PESAN YANG MAU DIKIRIM\nLALU KETIK:\n/broadcast"),
      { parse_mode: "HTML" }
    );
  }
  const users = getUsers();
  if (users.length === 0) {
    return ctx.reply(box("USER LIST KOSONG. BELUM ADA USER TERSIMPAN."), { parse_mode: "HTML" });
  }
  const statusMsg = await ctx.reply(box(`BROADCAST DIMULAI...\nTOTAL USER: ${users.length}`), { parse_mode: "HTML" });
  const fromChatId = ctx.chat.id;
  const messageId = replied.message_id;
  let ok = 0, fail = 0;
  for (const uid of users) {
    try {
      await ctx.telegram.forwardMessage(uid, fromChatId, messageId);
      ok++;
    } catch (e) {
      fail++;
    }
    if ((ok + fail) % 20 === 0) {
      await ctx.telegram.editMessageText(
        ctx.chat.id,
        statusMsg.message_id,
        undefined,
        box(`BROADCAST PROGRESS...\nBERHASIL: ${ok}\nFAIL: ${fail}\nTOTAL: ${users.length}`),
        { parse_mode: "HTML" }
      ).catch(() => {});
    }
    await new Promise(r => setTimeout(r, 80));
  }
  await ctx.telegram.editMessageText(
    ctx.chat.id,
    statusMsg.message_id,
    undefined,
    box(`BROADCAST SELESAI ✅\nOK: ${ok}\nFAIL: ${fail}\nTOTAL: ${users.length}`),
    { parse_mode: "HTML" }
  ).catch(() => {});
});

// ================= MAINTENANCE COMMAND =================
bot.command("maintance", async (ctx) => {
  if (ctx.from?.id !== LIXX_DEP)
    return ctx.reply("❌ Akses ditolak.");
  const args = (ctx.message.text || "").split(" ");
  const sub = (args[1] || "").toLowerCase();
  if (sub === "on") {
    await writeState(true);
    return ctx.reply("✅ Maintenance ON");
  }
  if (sub === "off") {
    await writeState(false);
    return ctx.reply("✅ Maintenance OFF");
  }
  return ctx.reply("Gunakan:\n/maintance on\n/maintance off");
});

// ================= BLOCK / UNBLOCK =================
bot.command("blokir", async (ctx) => {
  if (ctx.from.id !== OWNER_ID) {
    return ctx.reply("❌ Command ini khusus OWNER.");
  }
  const text = ctx.message?.text || "";
  const args = text.split(/\s+/).slice(1);
  let targetId = null;
  let targetName = null;
  if (ctx.message?.reply_to_message?.from?.id) {
    const u = ctx.message.reply_to_message.from;
    targetId = u.id;
    targetName = u.username ? `@${u.username}` : (u.first_name || `${u.id}`);
  }
  if (!targetId && Array.isArray(ctx.message?.entities)) {
    const ent = ctx.message.entities.find(e => e.type === "text_mention");
    if (ent && ent.user?.id) {
      targetId = ent.user.id;
      targetName = ent.user.username ? `@${ent.user.username}` : (ent.user.first_name || `${ent.user.id}`);
    }
  }
  if (!targetId && args[0] && /^\d+$/.test(args[0])) {
    targetId = Number(args[0]);
    targetName = `${targetId}`;
  }
  if (!targetId && args[0] && args[0].startsWith("@")) {
    const username = args[0].replace("@", "").trim();
    try {
      const chat = await ctx.telegram.getChat(`@${username}`);
      if (chat?.id) {
        targetId = chat.id;
        targetName = `@${username}`;
      }
    } catch (e) {}
  }
  if (!targetId) {
    return ctx.reply("❌ salah /blokir id user");
  }
  blockedUsers.add(targetId);
  return ctx.reply(`✅ ${targetName} berhasil diblokir. (ID: ${targetId})`);
});

bot.command(["unblock", "unblokir"], async (ctx) => {
  if (ctx.from.id !== OWNER_ID) {
    return ctx.reply("❌ Command ini khusus OWNER.");
  }
  let targetId;
  let targetName;
  if (ctx.message.reply_to_message) {
    targetId = ctx.message.reply_to_message.from.id;
    targetName = ctx.message.reply_to_message.from.username
      ? `@${ctx.message.reply_to_message.from.username}`
      : ctx.message.reply_to_message.from.first_name;
  } else if (ctx.message.text.split(" ")[1]) {
    const username = ctx.message.text.split(" ")[1].replace("@", "");
    try {
      const member = await ctx.telegram.getChatMember(ctx.chat.id, username);
      targetId = member.user.id;
      targetName = `@${username}`;
    } catch {
      return ctx.reply("❌ Username tidak ditemukan.");
    }
  } else {
    return ctx.reply("❌ Reply user atau /unblock @username");
  }
  if (!blockedUsers.has(targetId)) {
    return ctx.reply(`⚠️ ${targetName} tidak diblokir.`);
  }
  blockedUsers.delete(targetId);
  ctx.reply(`✅ ${targetName} berhasil di-unblock.`);
});

bot.command(["listblok", "listblock"], async (ctx) => {
  if (ctx.from.id !== OWNER_ID) {
    return ctx.reply("❌ Command ini khusus OWNER.");
  }
  if (blockedUsers.size === 0) {
    return ctx.reply("📭 Tidak ada user yang diblokir.");
  }
  let teks = "📄 <b>DAFTAR USER TERBLOKIR</b>\n\n";
  let no = 1;
  for (const userId of blockedUsers) {
    teks += `${no++}. <code>${userId}</code>\n`;
  }
  ctx.reply(teks, { parse_mode: "HTML" });
});

// ================= ADDLIMIT =================
bot.command("addlimit", async (ctx) => {
  const userId = ctx.from?.id;
  if (!isOwner(userId)) {
    return ctx.reply(box("AKSES DITOLAK ❌\nOWNER ONLY"), { parse_mode: "HTML" });
  }
  const parts = (ctx.message.text || "").trim().split(/\s+/);
  const targetId = parts[1];
  const value = parts[2];
  if (!targetId || !value) {
    return ctx.reply(
      box("FORMAT:\n/addlimit userId jumlah|free\n\nCONTOH:\n/addlimit 123456 5\n/addlimit 123456 free"),
      { parse_mode: "HTML" }
    );
  }
  const db = readJson(LIMIT_FILE);
  if (value.toLowerCase() === "free") {
    db[targetId] = { unlimited: true, limit: 999999999 };
    writeJson(LIMIT_FILE, db);
    return ctx.reply(box("USER DIJADIKAN UNLIMITED ✅\n\nUSER: " + targetId + "\nSTATUS: BEBAS LIMIT (PERMANEN)"), { parse_mode: "HTML" });
  }
  const amount = Number(value);
  if (isNaN(amount) || amount <= 0) {
    return ctx.reply(box("JUMLAH LIMIT HARUS ANGKA > 0"), { parse_mode: "HTML" });
  }
  if (!db[targetId]) {
    db[targetId] = { unlimited: false, limit: 0 };
  }
  db[targetId].unlimited = false;
  db[targetId].limit += amount;
  writeJson(LIMIT_FILE, db);
  return ctx.reply(box("ADD LIMIT BERHASIL ✅\n\nUSER: " + targetId + "\nDITAMBAH: " + amount + "\nTOTAL LIMIT: " + db[targetId].limit), { parse_mode: "HTML" });
});

// ================= ADDKEY =================
bot.command("addkey", async (ctx) => {
  if (ctx.from.id !== 8289001931)
    return ctx.reply("OWNER ONLY");
  const targetId = ctx.message.text.split(" ")[1];
  if (!targetId)
    return ctx.reply("FORMAT:\n/addkey <id_user>");
  const key = "KEY-" + Math.random().toString(36).substring(2, 14).toUpperCase();
  const db = readJson(KEY_FILE);
  db[targetId] = key;
  writeJson(KEY_FILE, db);
  await ctx.telegram.sendMessage(
    targetId,
    `🔐 <b>XENO BOT SYSTEM KEY</b>\n\nHalo 👋\nKey akses web kamu berhasil dibuat.\n\n📥 DETAIL AKSES\n👤 USER ID : <code>${targetId}</code>\n🔑 ACCESS KEY : <code>${key}</code>\n🖥 WEB LOGIN : ${WEB_LOGIN_URL}\n\n⚠️ Simpan key ini baik-baik.`,
    { parse_mode: "HTML" }
  );
  await ctx.reply(`✅ Key berhasil dibuat & dikirim.\n\nUSER: ${targetId}\nKEY: ${key}`);
});

// ================= EXPRESS ROUTES =================
app.use(express.json());

app.get("/health", (req, res) => res.status(200).send("ok"));

app.post("/api/login", (req, res) => {
  const userId = Number(req.body?.userId || 0);
  const key = String(req.body?.key || "").trim();
  if (!userId || !key) {
    return res.status(400).json({ ok: false, error: "userId+key required" });
  }
  if (!checkKey(userId, key)) {
    return res.status(401).json({ ok: false, error: "Key salah / belum dibuat" });
  }
  return res.json({ ok: true });
});

app.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const filePath = req.file.path;
    const jobId = randomJobId();
    const buffer = fs.readFileSync(filePath);
    await uploadToRepo(`uploads/${jobId}.zip`, buffer, `Upload from web ${jobId}`);
    await dispatchWorkflow(jobId, { zipPath: `uploads/${jobId}.zip` });
    return res.json({ success: true, jobId });
  } catch (e) {
    return res.json({ success: false, error: e.message });
  }
});

app.get("/api/status/:jobId", (req, res) => {
  try {
    const jobId = String(req.params.jobId || "").trim();
    const job = getJob(jobId);
    if (!job) return res.status(404).json({ ok: false, error: "JOB NOT FOUND" });
    return res.json({ ok: true, job });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e?.message || String(e) });
  }
});

app.post("/api/buildzip", upload.single("file"), async (req, res) => {
  try {
    const userId = Number(req.body.userId || 0);
    if (!userId) return res.status(400).json({ ok: false, error: "userId required" });
    const file = req.file;
    if (!file) return res.status(400).json({ ok: false, error: "file required" });
    if (!String(file.originalname || "").toLowerCase().endsWith(".zip")) {
      return res.status(400).json({ ok: false, error: "file must be .zip" });
    }
    if (!isOwner(userId)) {
      const limit = getUserLimit(userId);
      if (limit <= 0) return res.status(403).json({ ok: false, error: "LIMIT HABIS" });
      consumeLimit(userId);
    }
    const jobId = randomJobId();
    const zipPath = `uploads/${jobId}.zip`;
    await uploadToRepo(zipPath, file.buffer, `Upload job ${jobId} (web)`);
    const dispatchAt = Date.now();
    await dispatchWorkflow(jobId, { zipPath });
    let runId = null, runUrl = null;
    for (let i = 0; i < 10; i++) {
      await new Promise(r => setTimeout(r, 2500));
      const runsData = await listWorkflowRuns();
      const runs = runsData.workflow_runs || [];
      const candidate = runs
        .filter(r => new Date(r.created_at).getTime() >= dispatchAt - 30000)
        .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0];
      const newest = candidate || runs[0];
      if (newest?.id) { runId = newest.id; runUrl = newest.html_url; break; }
    }
    saveJob(jobId, {
      job_id: jobId,
      zip_path: zipPath,
      zip_url: "",
      run_id: runId,
      run_url: runUrl,
      user_id: userId,
      created_at: new Date().toISOString(),
    });
    return res.json({ ok: true, jobId, runUrl, runId });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e?.message || String(e) });
  }
});

// ================= LAUNCH =================
app.listen(PANEL_PORT, () => {
  console.log("WEB RUNNING ON PORT", PANEL_PORT);
});

bot.launch();
console.log("BOT BUILD APK READY 🚀");