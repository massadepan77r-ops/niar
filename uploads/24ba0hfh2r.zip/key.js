module.exports = {
  VPS_IP: "https://cape-gw-ddosmulupanel.voltxyz.my.id",
  PANEL_PORT: 4867,
  FULL_URL: "http://cape-gw-ddosmulupanel.voltxyz.my.id:4867"
};