import 'dart:ui';
import 'package:flutter/material.dart';

class AquaColors {
  // Background Layers
  static const Color bgBase = Color(0xFF07131D);
  static const Color bgLayer = Color(0xFF0B1B29);
  static const Color bgSoft = Color(0xFF0E2233);

  // Glass
  static const Color glass = Color(0x14FFFFFF);
  static const Color glassBorder = Color(0x2E22F1FF);
  static const Color glassBorderStrong = Color(0x4D22F1FF);

  // Accent
  static const Color primary = Color(0xFF3DDAD7);
  static const Color primarySoft = Color(0xFF7CF6F2);
  static const Color highlight = Color(0xFF22F1FF);

  // Text
  static const Color textMain = Color(0xFFF1F7FF);
  static const Color textSecondary = Color(0xFFB2C3D6);
  static const Color textMuted = Color(0xFF7D97AD);

  // Status
  static const Color success = Color(0xFF3DDAD7);
  static const Color warning = Color(0xFFFACC15);
  static const Color danger = Color(0xFFFF4D6D);

  // Backward alias
  static const Color bgPrimary = bgBase;
  static const Color bgSecondary = bgLayer;
}

class AquaRadii {
  static const double sm = 12;
  static const double md = 16;
  static const double lg = 20;
  static const double xl = 26;
}

class AquaShadows {
  static List<BoxShadow> soft = [
    const BoxShadow(
      color: Colors.black26,
      blurRadius: 18,
      offset: Offset(0, 10),
    ),
  ];

  static List<BoxShadow> glowPrimary = [
    BoxShadow(
      color: AquaColors.primary.withOpacity(0.25),
      blurRadius: 22,
      offset: const Offset(0, 12),
    ),
  ];
}

class AquaGradients {
  static const LinearGradient page = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0xD907131D),
      Color(0xF507131D),
    ],
  );

  static const LinearGradient glassOverlay = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0x0FFFFFFF),
      Colors.transparent,
    ],
  );
}

class AquaTheme {
  static ThemeData get dark {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AquaColors.bgBase,
      fontFamily: 'Orbitron',

      colorScheme: const ColorScheme.dark(
        primary: AquaColors.primary,
        secondary: AquaColors.primarySoft,
        surface: AquaColors.bgLayer,
      ),

      /// APP BAR
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: AquaColors.textMain,
        centerTitle: true,
      ),

      /// TEXT
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w700,
          color: AquaColors.textMain,
        ),
        headlineMedium: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          color: AquaColors.textMain,
        ),
        bodyLarge: TextStyle(
          fontSize: 16,
          color: AquaColors.textMain,
        ),
        bodyMedium: TextStyle(
          fontSize: 14,
          color: AquaColors.textSecondary,
        ),
      ),

      /// CARD
      cardTheme: CardThemeData(
        elevation: 0,
        color: AquaColors.glass,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AquaRadii.lg),
          side: const BorderSide(
            color: AquaColors.glassBorder,
            width: 1,
          ),
        ),
      ),

      /// ELEVATED BUTTON
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AquaColors.primary,
          foregroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AquaRadii.md),
          ),
          elevation: 0,
        ),
      ),

      /// OUTLINED BUTTON
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AquaColors.primarySoft,
          side: const BorderSide(color: AquaColors.glassBorder),
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AquaRadii.md),
          ),
        ),
      ),

      /// INPUT
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AquaColors.bgLayer.withOpacity(0.55),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        hintStyle: const TextStyle(
          color: AquaColors.textMuted,
          fontFamily: 'ShareTechMono',
        ),
        labelStyle: const TextStyle(color: AquaColors.textSecondary),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AquaRadii.md),
          borderSide: const BorderSide(color: AquaColors.glassBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AquaRadii.md),
          borderSide: const BorderSide(color: AquaColors.glassBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AquaRadii.md),
          borderSide:
              const BorderSide(color: AquaColors.highlight, width: 1.5),
        ),
      ),

      /// DIVIDER
      dividerTheme: const DividerThemeData(
        color: AquaColors.glassBorder,
        thickness: 0.8,
      ),

      /// ✅ FIXED DIALOG THEME (Flutter 3.16+)
      dialogTheme: DialogThemeData(
        backgroundColor: AquaColors.bgLayer,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AquaRadii.lg),
          side: const BorderSide(
            color: AquaColors.glassBorder,
            width: 1,
          ),
        ),
        titleTextStyle: const TextStyle(
          color: AquaColors.textMain,
          fontFamily: 'Orbitron',
          fontWeight: FontWeight.w800,
          fontSize: 16,
        ),
        contentTextStyle: const TextStyle(
          color: AquaColors.textSecondary,
          fontFamily: 'ShareTechMono',
          fontSize: 13,
        ),
      ),

      /// BOTTOM SHEET
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: AquaColors.bgLayer,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius:
              BorderRadius.vertical(top: Radius.circular(AquaRadii.xl)),
        ),
      ),

      /// SNACKBAR
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AquaColors.bgSoft,
        contentTextStyle: const TextStyle(
          color: AquaColors.textMain,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AquaRadii.md),
          side: const BorderSide(color: AquaColors.glassBorder),
        ),
        behavior: SnackBarBehavior.floating,
        elevation: 0,
      ),
    );
  }
}

/// ===============================================
/// REUSABLE PREMIUM GLASS PANEL
/// ===============================================

class GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final bool glow;

  const GlassPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.radius = AquaRadii.lg,
    this.glow = false,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: AquaColors.glass,
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(
              color: glow
                  ? AquaColors.glassBorderStrong
                  : AquaColors.glassBorder,
              width: 1,
            ),
            boxShadow:
                glow ? AquaShadows.glowPrimary : AquaShadows.soft,
            gradient: AquaGradients.glassOverlay,
          ),
          child: child,
        ),
      ),
    );
  }
}

/// BACKWARD COMPAT
class GlassContainer extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final bool glow;

  const GlassContainer({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.radius = AquaRadii.lg,
    this.glow = false,
  });

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: padding,
      radius: radius,
      glow: glow,
      child: child,
    );
  }
}