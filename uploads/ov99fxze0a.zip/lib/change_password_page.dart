import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const String baseUrl = "http://zyroxlegal.rexy-stecu.my.id:10580";

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final oldPassCtrl = TextEditingController();
  final newPassCtrl = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool isLoading = false;
  bool _obscureOldPassword = true;
  bool _obscureNewPassword = true;
  bool _obscureConfirmPassword = true;

  // --- NEON CYAN THEME ---
  static const Color bgDark = Color(0xFF04060A);         // Hitam siber luar angkasa pekat
  static const Color cardColor = Color(0xFF0C101A);      // Biru siber pekat sangat gelap
  static const Color neonCyan = Color(0xFF0044CC);       // Biru neon tua solid mendalam
  static const Color neonCyanLight = Color(0xFF00D2FF);  // Cyan Neon Elektrik menyala cerah
  static const Color primaryWhite = Colors.white;

  Color get textGrey => Colors.grey.shade400;
  Color get subtleGlass => const Color(0xFF111726).withOpacity(0.4);
  Color get borderSubtle => const Color(0xFF00D2FF).withOpacity(0.15);
  
  LinearGradient get blueGradient => const LinearGradient(
        colors: [neonCyan, neonCyanLight],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  @override
  void dispose() {
    oldPassCtrl.dispose();
    newPassCtrl.dispose();
    confirmPassCtrl.dispose();
    super.dispose();
  }

  Future<void> _changePassword() async {
    final oldPass = oldPassCtrl.text.trim();
    final newPass = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _showMessage("Semua field harus diisi.");
      return;
    }

    if (newPass != confirmPass) {
      _showMessage("Password baru tidak cocok dengan konfirmasi.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPass,
          "newPass": newPass,
          "sessionKey": widget.sessionKey,
        },
      );

      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _showMessage("Password berhasil diubah!", isSuccess: true);
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
      } else {
        _showMessage(data['message'] ?? "Gagal mengubah password");
      }
    } catch (e) {
      _showMessage("Koneksi error: $e");
    }

    setState(() => isLoading = false);
  }

  void _showMessage(String msg, {bool isSuccess = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: neonCyanLight.withOpacity(0.4)),
        ),
        title: Row(
          children: [
            Icon(
              isSuccess ? Icons.check_circle_outline : Icons.info_outline,
              color: neonCyanLight,
              size: 24,
            ),
            const SizedBox(width: 10),
            Text(
              isSuccess ? "Sukses" : "Peringatan",
              style: const TextStyle(
                color: primaryWhite,
                fontWeight: FontWeight.w600,
                fontSize: 18,
              ),
            ),
          ],
        ),
        content: Text(msg, style: TextStyle(color: textGrey, fontSize: 14)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                gradient: blueGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text(
                  "OK",
                  style: TextStyle(
                    color: bgDark,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput(
    TextEditingController controller,
    String label,
    dynamic icon, {
    bool isPassword = false,
    bool isOldPassword = false,
    bool isNewPassword = false,
    bool isConfirmPassword = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              color: neonCyanLight.withOpacity(0.8),
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: controller,
            obscureText: isPassword
                ? (isOldPassword
                    ? _obscureOldPassword
                    : (isNewPassword
                        ? _obscureNewPassword
                        : (isConfirmPassword ? _obscureConfirmPassword : true)))
                : false,
            style: const TextStyle(color: primaryWhite, fontSize: 14),
            decoration: InputDecoration(
              hintText: "Enter your $label",
              hintStyle: TextStyle(color: textGrey.withOpacity(0.3), fontSize: 13),
              prefixIcon: _DynamicIcon(icon, color: neonCyanLight, size: 20),
              suffixIcon: isPassword
                  ? IconButton(
                      icon: Icon(
                        (isOldPassword
                                ? _obscureOldPassword
                                : (isNewPassword
                                    ? _obscureNewPassword
                                    : _obscureConfirmPassword))
                            ? Icons.visibility_off
                            : Icons.visibility,
                        color: neonCyanLight.withOpacity(0.6),
                        size: 20,
                      ),
                      onPressed: () {
                        setState(() {
                          if (isOldPassword) {
                            _obscureOldPassword = !_obscureOldPassword;
                          } else if (isNewPassword) {
                            _obscureNewPassword = !_obscureNewPassword;
                          } else if (isConfirmPassword) {
                            _obscureConfirmPassword = !_obscureConfirmPassword;
                          }
                        });
                      },
                    )
                  : null,
              filled: true,
              fillColor: subtleGlass,
              // PERBAIKAN: Menghapus keyword 'const' ilegal pada dekorasi border dinamis berbasis variabel warna runtime
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: borderSubtle),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: borderSubtle),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: const BorderRadius.all(Radius.circular(12)),
                borderSide: BorderSide(color: neonCyanLight, width: 2),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: neonCyanLight, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          "CHANGE PASSWORD",
          style: TextStyle(
            color: primaryWhite,
            fontWeight: FontWeight.bold,
            fontSize: 18,
            letterSpacing: 1,
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, neonCyanLight.withOpacity(0.03), bgDark],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 20),
              // Header Icon
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: blueGradient,
                  boxShadow: [
                    BoxShadow(
                      color: neonCyanLight.withOpacity(0.4),
                      blurRadius: 30,
                      spreadRadius: 2,
                    )
                  ],
                ),
                child: const Icon(Icons.lock_reset, color: bgDark, size: 36),
              ),
              const SizedBox(height: 24),
              const Text(
                "UPDATE SECURITY",
                style: TextStyle(
                  color: primaryWhite,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 40),
              _buildInput(oldPassCtrl, "Old Password", Icons.lock_outline, isPassword: true, isOldPassword: true),
              _buildInput(newPassCtrl, "New Password", Icons.vpn_key, isPassword: true, isNewPassword: true),
              _buildInput(confirmPassCtrl, "Confirm Password", Icons.enhanced_encryption, isPassword: true, isConfirmPassword: true),
              const SizedBox(height: 30),
              // Button
              Container(
                width: double.infinity,
                height: 52,
                decoration: BoxDecoration(
                  gradient: blueGradient,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(color: neonCyanLight.withOpacity(0.3), blurRadius: 15)],
                ),
                child: ElevatedButton(
                  onPressed: isLoading ? null : _changePassword,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: isLoading
                      ? const CircularProgressIndicator(color: bgDark)
                      : const Text(
                          "UPDATE PASSWORD",
                          style: TextStyle(
                            color: bgDark,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;

  const _DynamicIcon(this.icon, {Key? key, this.size, this.color}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);
    bool isFontAwesome = false;
    try {
      if (icon.runtimeType.toString().contains('FaIcon') || 
          icon.toString().contains('FaIcon') ||
          icon.toString().contains('font_awesome_flutter') ||
          icon.fontPackage == 'font_awesome_flutter') {
        isFontAwesome = true;
      }
    } catch (_) {}
    return Center(
      widthFactor: 1.0,
      heightFactor: 1.0,
      child: isFontAwesome ? FaIcon(icon, size: size, color: color) : Icon(icon, size: size, color: color),
    );
  }
}
// WEBA2APK_DYNAMIC_ICON_END
