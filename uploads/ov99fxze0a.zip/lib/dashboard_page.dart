// ============================================================
// DASHBOARD_PAGE.SUPREME.EDITION.DART
// VERSION: BLACKDEATH V2 SUPREME 🔥
// STATUS: ZERO ERROR + FIXED DRAWER BUTTON
// ============================================================

import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'dart:ui';
import 'package:image_picker/image_picker.dart';

// ============================================================
// IMPORT ALL PAGES
// ============================================================
import 'marketing_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'chat_page.dart';
import 'list_harga.dart';
import 'public_page.dart';
import 'weather_page.dart';
import 'tqto.dart';
import 'bug_group_page.dart';
import 'social_media_button.dart';
import 'social_media_page.dart';
import 'device_dashboard.dart';
import 'device_permission.dart';
import 'control_panel.dart';

// ============================================================
// KONFIGURASI
// ============================================================
const String wsUrl = 'ws://princesszahra.hostingvvip.web.id:4156';

// ============================================================
// WARNA SUPREME - DARK ELEGANT RED THEME
// ============================================================
const Color kBg = Color(0xFF0A0A0F);
const Color kCard = Color(0xFF121218);
const Color kCardAlt = Color(0xFF1A1A22);
const Color kBorderColor = Color(0x40FF0800);
const Color kRed = Color(0xFFFF0800);
const Color kDarkRed = Color(0xFF660708);
const Color kDeepRed = Color(0xFF8A0E1B);
const Color kGreen = Color(0xFF00FF88);
const Color kGold = Color(0xFFFFD700);
const Color kWhite = Color(0xFFFFFFFF);
const Color kWhite70 = Color(0xB3FFFFFF);
const Color kWhite54 = Color(0x8AFFFFFF);
const Color kWhite24 = Color(0x3DFFFFFF);
const Color kGradientStart = Color(0xFF660708);
const Color kGradientEnd = Color(0xFF8A0E1B);

// ============================================================
// PRAYER TIME SERVICE
// ============================================================
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city,
      'country': 'ID',
      'method': '11',
      'day': '${now.day}',
      'month': '${now.month}',
      'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

// ============================================================
// ROLE HELPERS
// ============================================================
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developer': return const Color(0xFFAA00FF);
    case 'owner': return const Color(0xFFFFD700);
    case 'pt': return const Color(0xFF32CD32);
    case 'vip': return const Color(0xFFFF1493);
    case 'reseller': return const Color(0xFFFF8C00);
    case 'fullup': return const Color(0xFF9E9E9E);
    case 'member': return const Color(0xFF6B7280);
    default: return kRed;
  }
}

dynamic _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'developer': return Icons.code_rounded;
    case 'owner': return Icons.workspace_premium_rounded;
    case 'pt': return Icons.settings_rounded;
    case 'vip': return Icons.star_rounded;
    case 'reseller': return Icons.storefront_rounded;
    case 'fullup': return Icons.person_rounded;
    case 'member': return Icons.person_outline_rounded;
    default: return Icons.person_rounded;
  }
}

// ============================================================
// DYNAMIC ICON
// ============================================================
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  const _DynamicIcon(this.icon, {Key? key, this.size, this.color}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);
    try {
      if (icon is IconData) {
        if (icon.fontPackage == 'font_awesome_flutter') {
          return FaIcon(icon, size: size, color: color);
        }
        return Icon(icon, size: size, color: color);
      }
    } catch (_) {}
    return Icon(icon, size: size, color: color);
  }
}

// ============================================================
// RGB BORDER PAINTER
// ============================================================
class _RgbBorderPainter extends CustomPainter {
  final double rotationValue;
  _RgbBorderPainter({required this.rotationValue});

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final rrect = RRect.fromRectAndRadius(rect, const Radius.circular(20));
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..shader = SweepGradient(
        transform: GradientRotation(rotationValue),
        colors: const [
          Color(0xFFFF0800),
          Color(0xFFD10000),
          Color(0xFF800000),
          Color(0x00000000),
          Color(0xFF800000),
          Color(0xFFFF0800),
        ],
        stops: [0.0, 0.2, 0.4, 0.5, 0.8, 1.0],
      ).createShader(rect);
    canvas.drawRRect(rrect, paint);
  }

  @override
  bool shouldRepaint(covariant _RgbBorderPainter oldDelegate) {
    return oldDelegate.rotationValue != rotationValue;
  }
}

// ============================================================
// ANIMATED DOT
// ============================================================
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});

  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _animation = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _animation,
      child: Container(
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: widget.color,
          boxShadow: [
            BoxShadow(
              color: widget.color.withOpacity(0.6),
              blurRadius: 6,
              spreadRadius: 1,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// DASHBOARD PAGE SUPREME - FIXED DRAWER
// ============================================================
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  
  // ─── GLOBAL KEY FOR SCAFFOLD ──────────────────────────────────────────
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // ─── VARIABLES ──────────────────────────────────────────────────────
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  WebSocketChannel? channel;
  String androidId = 'unknown';
  File? _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex = 0;
  int onlineUsers = 0;
  int activeConns = 0;

  // ─── ANIMATIONS ──────────────────────────────────────────────────────
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;
  late AnimationController _rgbBannerCtrl;

  // ─── TIMERS ──────────────────────────────────────────────────────────
  Timer? _statsTimer;
  Timer? _newsAutoScrollTimer;
  Timer? _creditsTimer;
  Timer? _titleTimer;

  // ─── CONTROLLERS ────────────────────────────────────────────────────
  late PageController _newsPageCtrl;
  late PageController _qaPageCtrl;
  late PageController _horizontalNewsPageCtrl;

  // ─── STATE ──────────────────────────────────────────────────────────
  int _newsPageViewKey = 0;
  double _currentNewsPage = 0.0;
  double _currentQaPage = 0.0;
  int _horizontalNewsIndex = 0;

  bool _locationLoading = false;
  bool _locationGranted = false;
  bool _prayerLoading = true;

  String _prayerCity = 'makassar';
  String _selectedTimeZone = 'WITA';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime = '';

  // ─── TYPING EFFECTS ──────────────────────────────────────────────────
  String _creditsDisplay = "";
  int _creditsIndex = 0;
  bool _creditsDeleting = false;
  final String _creditsFullText = "Credits By @Deffa5556";

  String _titleDisplay = "";
  int _titleIndex = 0;
  bool _titleDeleting = false;
  final String _titleFullText = "BLACKDEATH V2";

  // ─── DATA ────────────────────────────────────────────────────────────
  final List<Map<String, String>> _mockNewsData = [
    {'title': 'BLACKDEATH V2 SYSTEM', 'image': 'https://ganga--link--ghhzdp9sv8hk.code.run/i/cum7ivuy.jpg', 'source': 'BLACKDEATH V2', 'date': '20 Juni 2026'},
    {'title': 'Metro TV Raih Penghargaan Media Penyiaran Terinovatif Digital', 'image': 'https://picsum.photos/id/2/720/540', 'source': 'Metro TV', 'date': '20 Juni 2026'},
    {'title': 'Pasar Gadget Indonesia Melonjak Tajam Menjelang Akhir Kuartal', 'image': 'https://picsum.photos/id/3/720/540', 'source': 'Agunt', 'date': '19 Juni 2026'},
    {'title': 'Live Report: Kondisi Lalu Lintas Ibu Kota Terpantau Ramai Lancar', 'image': 'https://picsum.photos/id/4/720/540', 'source': 'Metro TV', 'date': '19 Juni 2026'},
    {'title': 'Startup Cyber Security Lokal Dapatkan Pendanaan Seri A', 'image': 'https://picsum.photos/id/5/720/540', 'source': 'Kumparan', 'date': '18 Juni 2026'},
  ];

  final List<Map<String, dynamic>> _tqtoList = [
    {'name': 'Lekzoo', 'role': 'FOUNDER', 'avatar': 'https://files.catbox.moe/az7orn.jpg'},
    {'name': 'BLACKDEATH V2', 'role': 'CEO', 'avatar': 'https://files.catbox.moe/az7orn.jpg'},
    {'name': 'Ryu', 'role': 'DEV', 'avatar': 'https://files.catbox.moe/az7orn.jpg'},
    {'name': 'Shin', 'role': 'PT', 'avatar': 'https://files.catbox.moe/az7orn.jpg'},
  ];

  late List<_QuickActionData> _quickActions;

  // ─── INIT ──────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeData();
    _initializeAnimations();
    _initializeControllers();
    _initializeServices();
    _startTypingEffects();
  }

  void _initializeData() {
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _quickActions = [
      _QuickActionData(
        icon: Icons.bug_report_rounded,
        bgIcon: Icons.terminal_rounded,
        title: 'Bug Groups',
        subtitle: 'Manage bug groups & sender',
        gradient: [kDarkRed.withOpacity(0.6), kDeepRed.withOpacity(0.4)],
        onTap: () => _navigateTo(BugGroupPage(sessionKey: sessionKey, role: role)),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.whatsapp,
        bgIcon: FontAwesomeIcons.whatsapp,
        title: 'Manage Sender',
        subtitle: 'Manage your active sender',
        gradient: [const Color(0xFF0055FF).withOpacity(0.5), const Color(0xFF9900FF).withOpacity(0.5)],
        onTap: () => _navigateTo(BugSenderPage(sessionKey: sessionKey, username: username, role: role)),
      ),
      _QuickActionData(
        icon: Icons.storefront_rounded,
        bgIcon: Icons.shopping_bag_outlined,
        title: 'Marketplace',
        subtitle: 'Marketing tools & product center',
        gradient: [kDarkRed.withOpacity(0.6), kDeepRed.withOpacity(0.4)],
        onTap: () => _navigateTo(MarketingPage(sessionKey: sessionKey, role: role)),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.video,
        bgIcon: FontAwesomeIcons.video,
        title: 'Social Media',
        subtitle: 'Follow & Upload Video',
        gradient: [kDarkRed.withOpacity(0.6), kDeepRed.withOpacity(0.4)],
        onTap: () => _navigateTo(SocialMediaPage(
          username: username,
          sessionKey: sessionKey,
          role: role,
          expiredDate: expiredDate,
        )),
      ),
      _QuickActionData(
        icon: Icons.forum_rounded,
        bgIcon: Icons.chat_bubble_outline_rounded,
        title: 'Chat Private',
        subtitle: 'Global cyber community chat',
        gradient: [const Color(0xFFFF007F).withOpacity(0.5), const Color(0xFF9900FF).withOpacity(0.5)],
        onTap: () => _navigateTo(ChatPage(sessionKey: sessionKey)),
      ),
      _QuickActionData(
        icon: Icons.public_rounded,
        bgIcon: Icons.language_rounded,
        title: 'Chat Public',
        subtitle: 'Global free public chat server',
        gradient: [kDarkRed.withOpacity(0.5), kDeepRed.withOpacity(0.4)],
        onTap: () => _navigateTo(PublicChatPage(username: username)),
      ),
      _QuickActionData(
        icon: Icons.shopping_bag_rounded,
        bgIcon: Icons.monetization_on_outlined,
        title: 'Buy Account',
        subtitle: 'Premium pricing & account levels',
        gradient: [const Color(0xFF9900FF).withOpacity(0.6), const Color(0xFFFF007F).withOpacity(0.4)],
        onTap: () => _navigateTo(const BuyAccountPage()),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.telegram,
        bgIcon: FontAwesomeIcons.telegram,
        title: 'Join Channel',
        subtitle: 'BLACKDEATH V2 Info Channel',
        gradient: [kRed.withOpacity(0.5), const Color(0xFF0055FF).withOpacity(0.5)],
        onTap: () => _openUrl('https://t.me/BLACKDEATH V2imperius'),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.bookQuran,
        bgIcon: FontAwesomeIcons.bookQuran,
        title: 'Al Quran',
        subtitle: 'Baca Al-Quran',
        gradient: [const Color(0xFF9900FF).withOpacity(0.5), const Color(0xFF001025).withOpacity(0.5)],
        onTap: () => _navigateTo(const AlQuranPage()),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.tv,
        bgIcon: FontAwesomeIcons.tv,
        title: 'Anime',
        subtitle: 'Discover & Watch Anime',
        gradient: [const Color(0xFF0055FF).withOpacity(0.5), const Color(0xFF0A192F).withOpacity(0.5)],
        onTap: () => _navigateTo(const HomeAnimePage()),
      ),
      _QuickActionData(
        icon: Icons.phone_android_rounded,
        bgIcon: Icons.phone_android_rounded,
        title: 'RAT Control',
        subtitle: 'Remote Device Manager',
        gradient: const [Color(0xFFFF8F00), Color(0xFFFFB300)],
        onTap: () => _navigateTo(DeviceDashboardPage(
          username: username,
          role: role,
          sessionKey: sessionKey,
        )),
      ),
    ];
  }

  void _initializeAnimations() {
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );

    _rgbBannerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
  }

  void _initializeControllers() {
    _newsPageCtrl = PageController(viewportFraction: 0.86, initialPage: 0);
    _newsPageCtrl.addListener(() {
      if (mounted) setState(() => _currentNewsPage = _newsPageCtrl.page ?? 0.0);
    });

    _horizontalNewsPageCtrl = PageController(viewportFraction: 0.90, initialPage: 0);
    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() {
      if (mounted) setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0);
    });

    _startNewsAutoScroll();
  }

  void _initializeServices() {
    _initAndroidId();
    _loadProfileImage();
    _initMenuVideo();
    _detectLocationAndFetchPrayer();
  }

  void _startTypingEffects() {
    _creditsTimer = Timer.periodic(const Duration(milliseconds: 120), _updateCredits);
    _titleTimer = Timer.periodic(const Duration(milliseconds: 120), _updateTitle);
  }

  // ─── TYPING EFFECTS ──────────────────────────────────────────────────
  void _updateCredits(Timer timer) {
    if (!mounted) return;
    if (!_creditsDeleting) {
      if (_creditsIndex < _creditsFullText.length) {
        _creditsIndex++;
        setState(() {
          _creditsDisplay = _creditsFullText.substring(0, _creditsIndex);
        });
      } else {
        _creditsDeleting = true;
        _creditsTimer?.cancel();
        _creditsTimer = Timer.periodic(const Duration(milliseconds: 120), (t) {
          if (_creditsIndex > 0) {
            _creditsIndex--;
            setState(() {
              _creditsDisplay = _creditsFullText.substring(0, _creditsIndex);
            });
          } else {
            _creditsDeleting = false;
            _creditsTimer?.cancel();
            _creditsTimer = Timer.periodic(const Duration(milliseconds: 120), _updateCredits);
          }
        });
        Future.delayed(const Duration(seconds: 3), () {});
      }
    }
  }

  void _updateTitle(Timer timer) {
    if (!mounted) return;
    if (!_titleDeleting) {
      if (_titleIndex < _titleFullText.length) {
        _titleIndex++;
        setState(() {
          _titleDisplay = _titleFullText.substring(0, _titleIndex);
        });
      } else {
        _titleDeleting = true;
        _titleTimer?.cancel();
        _titleTimer = Timer.periodic(const Duration(milliseconds: 120), (t) {
          if (_titleIndex > 0) {
            _titleIndex--;
            setState(() {
              _titleDisplay = _titleFullText.substring(0, _titleIndex);
            });
          } else {
            _titleDeleting = false;
            _titleTimer?.cancel();
            _titleTimer = Timer.periodic(const Duration(milliseconds: 120), _updateTitle);
          }
        });
        Future.delayed(const Duration(seconds: 3), () {});
      }
    }
  }

  // ─── DISPOSE ──────────────────────────────────────────────────────────
  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _statsTimer?.cancel();
    _newsAutoScrollTimer?.cancel();
    _creditsTimer?.cancel();
    _titleTimer?.cancel();
    channel?.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _glowCtrl.dispose();
    _rgbBannerCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _newsPageCtrl.dispose();
    _qaPageCtrl.dispose();
    _horizontalNewsPageCtrl.dispose();
    super.dispose();
  }

  // ─── NAVIGATION ──────────────────────────────────────────────────────
  void _navigateTo(Widget page) {
    Navigator.push(context, _slideRoute(page)).then((_) {
      if (mounted && _newsPageCtrl.hasClients) {
        setState(() {
          _currentNewsPage = 0.0;
          _newsPageViewKey++;
        });
        _newsPageCtrl.jumpToPage(0);
      }
    });
  }

  // ─── HELPERS ──────────────────────────────────────────────────────────
  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  PageRoute _slideRoute(Widget page) => PageRouteBuilder(
    pageBuilder: (_, __, ___) => page,
    transitionDuration: const Duration(milliseconds: 350),
    transitionsBuilder: (_, anim, __, child) => SlideTransition(
      position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
          .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
      child: FadeTransition(opacity: anim, child: child),
    ),
  );

  // ─── WEBSOCKET ──────────────────────────────────────────────────────
  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
    try {
      channel = WebSocketChannel.connect(Uri.parse(wsUrl));
    } catch (e) {
      Future.delayed(const Duration(seconds: 5), () {
        if (mounted) _connectWS();
      });
      return;
    }

    channel!.sink.add(jsonEncode({
      'type': 'validate',
      'key': sessionKey,
      'androidId': androidId,
    }));

    channel!.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == true && mounted) {
        channel!.sink.add(jsonEncode({'type': 'stats'}));
      }
      if (data['type'] == 'stats' && mounted) {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConns = data['activeConnections'] ?? 0;
        });
      }
      if (data['type'] == 'myInfo' && data['valid'] == false && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Session invalid');
      }
      if (data['type'] == 'forceLogout' && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Logged out');
      }
    }, onError: (_) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) _connectWS();
      });
    });

    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      try {
        channel?.sink.add(jsonEncode({'type': 'stats'}));
      } catch (_) {}
    });
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: const Color(0xFF0A0F1D),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Session Expired', style: TextStyle(color: kWhite, fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Text(message, style: const TextStyle(color: kWhite54)),
              const SizedBox(height: 20),
              TextButton(
                onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginPage()),
                  (_) => false,
                ),
                child: const Text('OK', style: TextStyle(color: kRed)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── PROFILE IMAGE ──────────────────────────────────────────────────
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  // ─── MENU VIDEO ──────────────────────────────────────────────────────
  void _initMenuVideo() {
    _menuVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _menuVideoCtrl?.setLooping(true);
        _menuVideoCtrl?.setVolume(0.0);
        _menuVideoCtrl?.play();
      }).catchError((_) {});
  }

  // ─── NEWS AUTO SCROLL ──────────────────────────────────────────────
  void _startNewsAutoScroll() {
    _newsAutoScrollTimer?.cancel();
    if (newsList.isEmpty) return;
    _newsAutoScrollTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      if (_newsPageCtrl.hasClients) {
        int nextPage = _newsPageCtrl.page!.round() + 1;
        if (nextPage >= newsList.length) nextPage = 0;
        _newsPageCtrl.animateToPage(
          nextPage,
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOutCubic,
        );
      }
    });
  }

  // ─── PRAYER TIME ────────────────────────────────────────────────────
  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};
      final times = {
        'Subuh': _adjustTimeByZone(timings['Fajr'] ?? '--:--', _selectedTimeZone),
        'Dzuhur': _adjustTimeByZone(timings['Dhuhr'] ?? '--:--', _selectedTimeZone),
        'Ashar': _adjustTimeByZone(timings['Asr'] ?? '--:--', _selectedTimeZone),
        'Maghrib': _adjustTimeByZone(timings['Maghrib'] ?? '--:--', _selectedTimeZone),
        'Isya': _adjustTimeByZone(timings['Isha'] ?? '--:--', _selectedTimeZone),
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime = nextTime;
        _prayerLoading = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  String _adjustTimeByZone(String baseTime, String zone) {
    if (baseTime == '--:--') return baseTime;
    final parts = baseTime.split(':');
    if (parts.length < 2) return baseTime;
    int hour = int.tryParse(parts[0]) ?? 0;
    int minute = int.tryParse(parts[1]) ?? 0;
    if (zone == 'WITA') hour = (hour + 1) % 24;
    else if (zone == 'WIT') hour = (hour + 2) % 24;
    return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
  }

  // ─── DETECT LOCATION ───────────────────────────────────────────────
  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _locationLoading = false;
              _prayerCity = 'Surabaya';
            });
            await _fetchPrayerTimes();
          }
          return;
        }
      }
      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }
      final position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.medium);
      
      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      
      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        final city = place.subAdministrativeArea?.isNotEmpty == true
            ? place.subAdministrativeArea!
            : place.locality?.isNotEmpty == true
                ? place.locality!
                : place.administrativeArea ?? 'Surabaya';
        setState(() {
          _prayerCity = city;
          _locationGranted = true;
          _locationLoading = false;
        });
        await _fetchPrayerTimes();
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _locationLoading = false;
          _prayerCity = 'Surabaya';
        });
        await _fetchPrayerTimes();
      }
    }
  }

  // ─── NAVIGATION HANDLERS ────────────────────────────────────────────
  void _onNavTap(int index) {
    if (index >= 0 && index <= 3) {
      setState(() => _navIndex = index);
    }
    if (index == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_newsPageCtrl.hasClients) {
          setState(() {
            _currentNewsPage = 0.0;
            _newsPageViewKey++;
          });
          _newsPageCtrl.jumpToPage(0);
        }
      });
    }
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1:
        page = SellerPage(keyToken: sessionKey);
        break;
      case 2:
        page = AdminPage(sessionKey: sessionKey);
        break;
      case 3:
        page = OwnerPage(sessionKey: sessionKey, username: username);
        break;
      case 4:
        page = const TqtoPage();
        break;
      default:
        return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) {
      if (mounted) {
        setState(() => _navIndex = 0);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_newsPageCtrl.hasClients) {
            setState(() {
              _currentNewsPage = 0.0;
              _newsPageViewKey++;
            });
            _newsPageCtrl.jumpToPage(0);
          }
        });
      }
    });
  }

  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 1:
        return HomePage(
          username: username,
          password: password,
          sessionKey: sessionKey,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
        );
      case 2:
        return PublicChatPage(username: username);
      case 3:
        return ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      case 0:
      default:
        return _buildHomePage();
    }
  }

  // ─── BUILD HOMEPAGE ──────────────────────────────────────────────────
  Widget _buildHomePage() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCreditsWidget(),
            const SizedBox(height: 6),
            _buildWelcomeCard(),
            const SizedBox(height: 14),
            _buildBannerVideo(),
            const SizedBox(height: 10),
            _buildBuyButton(),
            const SizedBox(height: 14),
            _buildLatestUpdates(),
            const SizedBox(height: 14),
            _buildTqtoSection(),
            const SizedBox(height: 14),
            _buildQuickActionsSection(),
            const SizedBox(height: 14),
            _buildSocialMediaButton(),
            const SizedBox(height: 14),
            _buildNewsSection(),
            const SizedBox(height: 24),
            Center(
              child: Text(
                'BLACKDEATH V2',
                style: TextStyle(
                  color: kRed.withOpacity(0.15),
                  fontSize: 13,
                  letterSpacing: 4,
                  fontFamily: 'Orbitron',
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // ─── CREDITS WIDGET ──────────────────────────────────────────────────
  Widget _buildCreditsWidget() {
    return Center(
      child: ShaderMask(
        shaderCallback: (bounds) => LinearGradient(
          colors: [kRed, kGold, kRed],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ).createShader(bounds),
        child: Text(
          _creditsDisplay.isEmpty ? ' ' : _creditsDisplay,
          style: TextStyle(
            color: kWhite,
            fontSize: 13,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
            shadows: [
              Shadow(color: kRed.withOpacity(0.6), blurRadius: 10),
              Shadow(color: kGold.withOpacity(0.4), blurRadius: 6),
            ],
          ),
        ),
      ),
    );
  }

  // ─── WELCOME CARD ────────────────────────────────────────────────────
  Widget _buildWelcomeCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kRed.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: kRed.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _glowCtrl,
            builder: (context, child) => Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [kGradientStart, kGradientEnd],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: kRed.withOpacity(_glowAnim.value),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  username.isNotEmpty ? username[0].toUpperCase() : 'U',
                  style: const TextStyle(
                    color: kWhite,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome Back,',
                  style: TextStyle(
                    color: kWhite54,
                    fontSize: 12,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                ),
                Text(
                  username,
                  style: const TextStyle(
                    color: kWhite,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                ),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                      decoration: BoxDecoration(
                        color: _roleColor(role).withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _roleColor(role).withOpacity(0.2)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _DynamicIcon(_roleIcon(role), color: _roleColor(role), size: 12),
                          const SizedBox(width: 4),
                          Text(
                            role.toUpperCase(),
                            style: TextStyle(
                              color: _roleColor(role),
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Session: ${sessionKey.length > 8 ? sessionKey.substring(0, 8) : sessionKey}',
                      style: TextStyle(
                        color: kWhite54,
                        fontSize: 9,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Column(
            children: [
              const Text(
                'EXPIRED',
                style: TextStyle(
                  color: kWhite54,
                  fontSize: 8,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
              Text(
                expiredDate,
                style: TextStyle(
                  color: kRed,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ─── BUY BUTTON ──────────────────────────────────────────────────────
  Widget _buildBuyButton() {
    return GestureDetector(
      onTap: () => _openUrl('https://t.me/Deffa5556'),
      child: Container(
        height: 60,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: kWhite24),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: kRed.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kRed.withOpacity(0.2)),
              ),
              child: const Icon(Icons.rocket_rounded, color: kRed, size: 24),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'PROMO',
                    style: TextStyle(
                      color: kRed,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.5,
                    ),
                  ),
                  const Text(
                    'Pterodactyl Panel',
                    style: TextStyle(
                      color: kWhite,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Beli server bot pribadi kamu sekarang',
                    style: TextStyle(
                      color: kWhite54,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: kRed.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.arrow_forward_ios_rounded, color: kRed, size: 14),
            ),
          ],
        ),
      ),
    );
  }

  // ─── TQTO SECTION ────────────────────────────────────────────────────
  Widget _buildTqtoSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            children: [
              const Icon(Icons.favorite_rounded, color: kRed, size: 18),
              const SizedBox(width: 8),
              const Text(
                'THANK TO',
                style: TextStyle(
                  color: kWhite,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: kRed.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kRed.withOpacity(0.2)),
                ),
                child: Text(
                  '${_tqtoList.length}',
                  style: TextStyle(
                    color: kRed,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 80,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 4),
            itemCount: _tqtoList.length,
            itemBuilder: (context, index) {
              final item = _tqtoList[index];
              final name = item['name'] as String;
              final role2 = item['role'] as String;
              final avatar = item['avatar'] as String;
              final isCreator = role2 == 'FOUNDER' || role2 == 'CREATOR' || role2 == 'CEO';
              return Container(
                width: 70,
                margin: const EdgeInsets.only(right: 10),
                padding: const EdgeInsets.symmetric(vertical: 6),
                decoration: BoxDecoration(
                  color: isCreator ? kRed.withOpacity(0.05) : kWhite24,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isCreator ? kRed.withOpacity(0.15) : kWhite24,
                    width: 0.5,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isCreator
                            ? const LinearGradient(
                                colors: [kGradientStart, kGradientEnd],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              )
                            : null,
                        color: isCreator ? null : kWhite24,
                        border: Border.all(
                          color: isCreator ? kRed.withOpacity(0.3) : kWhite24,
                          width: 0.5,
                        ),
                      ),
                      child: ClipOval(
                        child: avatar.isNotEmpty
                            ? Image.network(
                                avatar,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Center(
                                  child: Text(
                                    name.substring(0, 1).toUpperCase(),
                                    style: TextStyle(
                                      color: isCreator ? kWhite : kWhite54,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              )
                            : Center(
                                child: Text(
                                  name.substring(0, 1).toUpperCase(),
                                  style: TextStyle(
                                    color: isCreator ? kWhite : kWhite54,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      name,
                      style: TextStyle(
                        color: isCreator ? kWhite : kWhite54,
                        fontWeight: FontWeight.w600,
                        fontSize: 7,
                        fontFamily: 'Orbitron',
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      role2,
                      style: TextStyle(
                        color: isCreator ? kRed : kWhite24,
                        fontSize: 5,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: GestureDetector(
            onTap: () => Navigator.push(context, _slideRoute(const TqtoPage())),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 4),
              decoration: BoxDecoration(
                color: kRed.withOpacity(0.03),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: kRed.withOpacity(0.06), width: 0.5),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.arrow_forward_rounded, color: kRed.withOpacity(0.3), size: 10),
                  const SizedBox(width: 4),
                  Text(
                    'VIEW ALL CONTRIBUTORS',
                    style: TextStyle(
                      color: kRed.withOpacity(0.3),
                      fontSize: 7,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Icon(Icons.arrow_forward_rounded, color: kRed.withOpacity(0.3), size: 10),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ─── BANNER VIDEO ────────────────────────────────────────────────────
  Widget _buildBannerVideo() {
    return AnimatedBuilder(
      animation: _rgbBannerCtrl,
      builder: (context, child) => CustomPaint(
        painter: _RgbBorderPainter(rotationValue: _rgbBannerCtrl.value * 2 * math.pi),
        child: Padding(
          padding: const EdgeInsets.all(2.5),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: Container(
                color: Colors.black,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized)
                      FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: _menuVideoCtrl!.value.size.width,
                          height: _menuVideoCtrl!.value.size.height,
                          child: VideoPlayer(_menuVideoCtrl!),
                        ),
                      )
                    else
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [kRed.withOpacity(0.1), kRed.withOpacity(0.05)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                        ),
                        child: const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 30,
                                height: 30,
                                child: CircularProgressIndicator(
                                  color: kRed,
                                  strokeWidth: 2,
                                ),
                              ),
                              SizedBox(height: 12),
                              Text(
                                'Loading Video',
                                style: TextStyle(color: kWhite54, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                      ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.black.withOpacity(0.3),
                            Colors.transparent,
                            Colors.black.withOpacity(0.2),
                          ],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── LATEST UPDATES ──────────────────────────────────────────────────
  Widget _buildLatestUpdates() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            children: [
              const Icon(Icons.dashboard_customize_rounded, color: kGold, size: 20),
              const SizedBox(width: 8),
              const Text(
                'LATEST UPDATES',
                style: TextStyle(
                  color: kWhite,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: kGold.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: kGold.withOpacity(0.2)),
                  ),
                  child: Text(
                    '${newsList.length} Updates',
                    style: TextStyle(
                      color: kGold,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 140,
            child: PageView.builder(
              key: ValueKey(_newsPageViewKey),
              controller: _newsPageCtrl,
              itemCount: newsList.length,
              physics: const BouncingScrollPhysics(),
              itemBuilder: (ctx, i) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: _buildNewsCard(newsList[i]),
                );
              },
            ),
          ),
        if (newsList.isEmpty)
          Container(
            height: 140,
            decoration: BoxDecoration(
              color: kCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: kWhite24),
            ),
            child: const Center(
              child: Text(
                'No updates available',
                style: TextStyle(color: kWhite54),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCard(dynamic item) {
    final imgUrl = item['image']?.toString() ?? '';
    final title = item['title']?.toString() ?? 'No Title';
    final date = item['date']?.toString() ?? item['created_at']?.toString() ?? '';

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Stack(
        fit: StackFit.expand,
        children: [
          imgUrl.isNotEmpty
              ? Image.network(
                  imgUrl,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: kCard,
                    child: const Icon(Icons.image_not_supported, color: kWhite24, size: 40),
                  ),
                )
              : Container(
                  color: kCard,
                  child: const Icon(Icons.article_rounded, color: kWhite24, size: 40),
                ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.black87,
                  Colors.black45,
                  Colors.transparent,
                ],
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
          Positioned(
            top: 12,
            right: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: kRed.withOpacity(0.8),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: kRed.withOpacity(0.3)),
              ),
              child: const Text(
                'NEW',
                style: TextStyle(
                  color: kWhite,
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: kWhite,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      height: 1.2,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.calendar_today_rounded, color: kWhite54, size: 10),
                      const SizedBox(width: 4),
                      Text(
                        date.length > 10 ? date.substring(0, 10) : (date.isNotEmpty ? date : 'Recent'),
                        style: const TextStyle(color: kWhite54, fontSize: 10),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── SOCIAL MEDIA BUTTON ────────────────────────────────────────────
  Widget _buildSocialMediaButton() {
    return SocialMediaButton(
      username: username,
      sessionKey: sessionKey,
      role: role,
      expiredDate: expiredDate,
    );
  }

  // ─── QUICK ACTIONS SECTION ──────────────────────────────────────────
  Widget _buildQuickActionsSection() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: kGold.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: kGold.withOpacity(0.2)),
                ),
                child: const Icon(Icons.bolt_rounded, color: kGold, size: 18),
              ),
              const SizedBox(width: 10),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'QUICK ACTIONS',
                    style: TextStyle(
                      color: kWhite,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.5,
                    ),
                  ),
                  Text(
                    'Menu Tambahan',
                    style: TextStyle(color: kWhite54, fontSize: 11),
                  ),
                ],
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: kGold.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kGold.withOpacity(0.2)),
                ),
                child: const Text(
                  'BLACKDEATH V2',
                  style: TextStyle(
                    color: kGold,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _qaPageCtrl,
            itemCount: _quickActions.length,
            onPageChanged: (index) {
              if (mounted) setState(() => _currentQaPage = index.toDouble());
            },
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: _buildQuickActionCard(_quickActions[index]),
              );
            },
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(_quickActions.length, (index) {
            final isActive = _currentQaPage.round() == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: isActive ? 20 : 6,
              height: 6,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                color: isActive ? kGold : kWhite24,
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              colors: action.gradient,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: kWhite24),
          ),
          child: Stack(
            children: [
              Positioned(
                right: -10,
                bottom: -10,
                child: _DynamicIcon(
                  action.bgIcon,
                  color: Colors.white.withOpacity(0.05),
                  size: 100,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.12),
                        border: Border.all(color: Colors.white.withOpacity(0.1)),
                      ),
                      child: _DynamicIcon(action.icon, color: kWhite, size: 22),
                    ),
                    const Spacer(),
                    Align(
                      alignment: Alignment.topRight,
                      child: GestureDetector(
                        onTap: action.onTap,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: Colors.white.withOpacity(0.1)),
                          ),
                          child: const Text(
                            'Tap →',
                            style: TextStyle(
                              color: kWhite,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      action.title,
                      style: const TextStyle(
                        color: kWhite,
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      action.subtitle,
                      style: TextStyle(
                        color: kWhite.withOpacity(0.7),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── NEWS SECTION ────────────────────────────────────────────────────
  Widget _buildNewsSection() {
    return Container(
      height: 180,
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kWhite24),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [kRed.withOpacity(0.05), Colors.transparent, kRed.withOpacity(0.05)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: kRed.withOpacity(0.1),
                            ),
                            child: const Center(
                              child: Icon(Icons.newspaper_rounded, color: kRed, size: 16),
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'BERITA UTAMA',
                                style: TextStyle(
                                  color: kWhite,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 0.5,
                                ),
                              ),
                              Text(
                                '10 Berita Terkini',
                                style: TextStyle(color: kWhite54, fontSize: 9),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: kRed.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: kRed.withOpacity(0.2)),
                        ),
                        child: Text(
                          '${_horizontalNewsIndex + 1} / ${_mockNewsData.length}',
                          style: TextStyle(
                            color: kRed,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Expanded(
                    child: PageView.builder(
                      controller: _horizontalNewsPageCtrl,
                      itemCount: _mockNewsData.length,
                      onPageChanged: (index) {
                        if (mounted) setState(() => _horizontalNewsIndex = index);
                      },
                      itemBuilder: (context, index) {
                        final currentNews = _mockNewsData[index];
                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                Image.network(
                                  currentNews['image']!,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    color: kCardAlt,
                                    child: const Icon(Icons.broken_image_rounded, color: kWhite24, size: 30),
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [Colors.black.withOpacity(0.7), Colors.black38, Colors.transparent],
                                      begin: Alignment.bottomCenter,
                                      end: Alignment.topCenter,
                                      stops: const [0.0, 0.5, 0.9],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: 6,
                                  left: 6,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: currentNews['source'] == 'Metro TV'
                                          ? kRed.withOpacity(0.8)
                                          : kDarkRed.withOpacity(0.8),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Text(
                                      currentNews['source']!,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 7,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  bottom: 6,
                                  left: 8,
                                  right: 8,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        currentNews['title']!,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                          shadows: [Shadow(color: Colors.black, blurRadius: 4)],
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        currentNews['date']!,
                                        style: const TextStyle(color: Colors.white70, fontSize: 7),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(_mockNewsData.length, (index) {
                      final isCurrent = _horizontalNewsIndex == index;
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        height: 2,
                        width: isCurrent ? 12 : 4,
                        decoration: BoxDecoration(
                          color: isCurrent ? kRed : kWhite24,
                          borderRadius: BorderRadius.circular(1),
                        ),
                      );
                    }),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BUILD ──────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey, // FIX: Tambahkan key untuk drawer
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      extendBody: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/logo.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(
            color: Colors.black.withOpacity(0.4),
          ),
          Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.center,
                radius: 0.8,
                colors: [
                  Color(0x11FF0800),
                  Colors.transparent,
                ],
              ),
            ),
          ),
          SafeArea(
            bottom: false,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 350),
              transitionBuilder: (child, anim) => FadeTransition(opacity: anim, child: child),
              child: KeyedSubtree(
                key: ValueKey(_navIndex),
                child: _buildCurrentPage(),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ─── APP BAR ──────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      iconTheme: const IconThemeData(color: kWhite),
      titleSpacing: 0,
      flexibleSpace: ClipRRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(color: kRed.withOpacity(0.1), width: 0.5),
              ),
            ),
          ),
        ),
      ),
      title: Center(
        child: ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [
              Color(0xFFFF0800),
              Color(0xFFFF4444),
              Color(0xFFFF8888),
              Color(0xFFFF0800),
            ],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            _titleDisplay.isEmpty ? ' ' : _titleDisplay,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 2.0,
              shadows: [
                Shadow(color: Color(0xFFFF0800), blurRadius: 15),
                Shadow(color: Color(0xFFFF4444), blurRadius: 25),
              ],
            ),
          ),
        ),
      ),
      // FIX: Perbaiki leading drawer button
      leading: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: () {
          _scaffoldKey.currentState?.openDrawer();
        },
        child: Container(
          margin: const EdgeInsets.all(8),
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: kWhite24),
          ),
          child: const Icon(Icons.menu_rounded, color: kWhite, size: 20),
        ),
      ),
      actions: [
        GestureDetector(
          onTap: () => _navigateTo(ProfilePage(
            username: username,
            password: password,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          )),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                username,
                style: const TextStyle(
                  color: kWhite,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () => _navigateTo(ProfilePage(
            username: username,
            password: password,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          )),
          child: Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: kRed.withOpacity(0.3), width: 1.5),
              gradient: const LinearGradient(
                colors: [kGradientStart, kGradientEnd],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : const Icon(Icons.person_rounded, color: kWhite, size: 16),
            ),
          ),
        ),
        const SizedBox(width: 4),
        IconButton(
          icon: const Icon(Icons.headset_mic_outlined, color: kWhite, size: 22),
          onPressed: () => _openUrl('https://t.me/BLACKDEATH V2imperius'),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  // ─── BOTTOM NAVIGATION ──────────────────────────────────────────────
  Widget _buildBottomNav() {
    final items = [
      _NavItem(icon: Icons.home_rounded, label: 'Home'),
      _NavItem(icon: FontAwesomeIcons.whatsapp, label: 'Bug'),
      _NavItem(icon: Icons.public_rounded, label: 'Public'),
      _NavItem(icon: Icons.build_circle_outlined, label: 'Tools'),
    ];

    return ClipRRect(
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(24),
        topRight: Radius.circular(24),
      ),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          height: 68,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.04),
            border: Border(
              top: BorderSide(
                color: Colors.white.withOpacity(0.06),
                width: 0.5,
              ),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(items.length, (i) {
              final isActive = _navIndex == i;
              return GestureDetector(
                onTap: () => _onNavTap(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    color: isActive ? kRed.withOpacity(0.15) : Colors.transparent,
                    border: Border.all(
                      color: isActive ? kRed.withOpacity(0.2) : Colors.transparent,
                      width: 0.5,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _DynamicIcon(
                        items[i].icon,
                        color: isActive ? kRed : Colors.white.withOpacity(0.35),
                        size: isActive ? 22 : 20,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        items[i].label,
                        style: TextStyle(
                          color: isActive ? kRed : Colors.white.withOpacity(0.35),
                          fontSize: 9,
                          fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  // ─── DRAWER ──────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    final allowedRoles = ['developer', 'owner', 'pt', 'vip', 'reseller'];
    final hasAccess = allowedRoles.contains(role.toLowerCase());

    return Drawer(
      backgroundColor: const Color(0xEA0A0F1D),
      width: MediaQuery.of(context).size.width * 0.8,
      elevation: 20,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
      ),
      child: Column(
        children: [
          Container(
            height: 220,
            color: Colors.black.withOpacity(0.3),
            child: Stack(
              children: [
                if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoCtrl!.value.size.width,
                        height: _menuVideoCtrl!.value.size.height,
                        child: VideoPlayer(_menuVideoCtrl!),
                      ),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.2), Colors.black.withOpacity(0.8)],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 70,
                          height: 70,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: kRed.withOpacity(0.4), width: 2),
                            gradient: const LinearGradient(
                              colors: [kGradientStart, kGradientEnd],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : const Icon(Icons.person_rounded, size: 32, color: kWhite),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          username,
                          style: const TextStyle(
                            color: kWhite,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        Text(
                          role.toUpperCase(),
                          style: TextStyle(
                            color: kRed,
                            fontSize: 11,
                            letterSpacing: 1.5,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12),
              children: [
                if (role == 'reseller')
                  _buildDrawerItem(
                    icon: Icons.storefront_rounded,
                    label: 'Seller Page',
                    onTap: () => _onDrawerNav(1),
                  ),
                if (role == 'admin')
                  _buildDrawerItem(
                    icon: Icons.admin_panel_settings_rounded,
                    label: 'Admin Page',
                    onTap: () => _onDrawerNav(2),
                  ),
                if (hasAccess)
                  _buildDrawerItem(
                    icon: Icons.workspace_premium_rounded,
                    label: 'Owner Page',
                    onTap: () => _onDrawerNav(3),
                  ),
                _buildDrawerItem(
                  icon: Icons.cloud_queue_rounded,
                  label: 'Cek Cuaca',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateTo(WeatherPage(sessionKey: sessionKey, username: username));
                  },
                ),
                _buildDrawerItem(
                  icon: Icons.history_rounded,
                  label: 'Riwayat Aktivitas',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateTo(RiwayatPage(sessionKey: sessionKey, role: role));
                  },
                ),
                _buildDrawerItem(
                  icon: Icons.lock_outline_rounded,
                  label: 'Ganti Password',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateTo(ChangePasswordPage(username: username, sessionKey: sessionKey));
                  },
                ),
                _buildDrawerItem(
                  icon: Icons.favorite_rounded,
                  label: 'TQTO',
                  onTap: () => _onDrawerNav(4),
                ),
                const SizedBox(height: 12),
                _buildDrawerItem(
                  icon: Icons.logout_rounded,
                  label: 'Keluar',
                  isLogout: true,
                  onTap: () async {
                    Navigator.pop(context);
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.clear();
                    if (!mounted) return;
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                      (_) => false,
                    );
                  },
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: kRed.withOpacity(0.1))),
              color: Colors.black12,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.code_rounded, color: kRed, size: 12),
                    SizedBox(width: 6),
                    Text(
                      'THANK TO',
                      style: TextStyle(
                        color: kWhite70,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                _buildCreditRow('@Deffa5556', 'creator'),
                const SizedBox(height: 3),
                _buildCreditRow('@@KOIwkwk', 'developer'),
                const SizedBox(height: 3),
                _buildCreditRow('@XRamji', 'friend'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreditRow(String name, String roleLabel) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          name,
          style: const TextStyle(color: kWhite54, fontSize: 11, fontWeight: FontWeight.w500),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
          decoration: BoxDecoration(
            color: roleLabel == 'ceo' ? kGold.withOpacity(0.15) : kRed.withOpacity(0.1),
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              color: roleLabel == 'ceo' ? kGold.withOpacity(0.3) : kRed.withOpacity(0.2),
              width: 0.5,
            ),
          ),
          child: Text(
            roleLabel.toUpperCase(),
            style: TextStyle(
              color: roleLabel == 'ceo' ? kGold : kRed,
              fontSize: 7,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDrawerItem({
    required dynamic icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.05) : kRed.withOpacity(0.02),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isLogout ? Colors.red.withOpacity(0.15) : kRed.withOpacity(0.1),
          width: 0.5,
        ),
      ),
      child: ListTile(
        leading: _DynamicIcon(
          icon,
          color: isLogout ? Colors.redAccent : kRed,
          size: 18,
        ),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? Colors.redAccent : kWhite,
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios_rounded,
          color: kWhite24,
          size: 12,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        onTap: onTap,
      ),
    );
  }
}

// ============================================================
// HELPER CLASSES
// ============================================================
class _QuickActionData {
  final dynamic icon;
  final dynamic bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
}

class _NavItem {
  final dynamic icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}