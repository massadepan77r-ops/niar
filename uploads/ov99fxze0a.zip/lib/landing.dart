import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'dart:ui';

// ===== VEXORV THEME (MERAH) =====
const Color kBg      = Color(0xFF0A0F1D);
const Color kRed     = Color(0xFFFF0800);
const Color kRedGlow = Color(0xFFCC0000);
const Color kWhite   = Colors.white;
const Color kWhite70 = Colors.white70;
const Color kWhite54 = Colors.white54;
const Color kWhite24 = Colors.white24;

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  late final AnimationController _entranceController;
  late final AnimationController _floatingController;
  late final AnimationController _pulseController;

  late final Animation<Offset> _charSlideAnim;
  late final Animation<double> _fadeTitleAnim;
  late final Animation<Offset> _slideTitleAnim;
  late final Animation<double> _fadeUiAnim;
  late final Animation<Offset> _slideUiAnim;
  late final Animation<double> _scaleButtonAnim;

  int _currentPage = 0;
  final PageController _pageController = PageController();

  @override
  void initState() {
    super.initState();

    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    );

    _floatingController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _charSlideAnim = Tween<Offset>(
      begin: const Offset(0, 1.15),
      end: const Offset(0, 0.06),
    ).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: const Interval(0.0, 0.55, curve: Curves.easeOutQuart),
      ),
    );

    _slideUiAnim = Tween<Offset>(
      begin: const Offset(-1.2, 0),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: const Interval(0.18, 0.62, curve: Curves.easeOutBack),
      ),
    );

    _fadeUiAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: const Interval(0.18, 0.52, curve: Curves.easeIn),
      ),
    );

    _slideTitleAnim = Tween<Offset>(
      begin: const Offset(0, 0.35),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: const Interval(0.38, 0.80, curve: Curves.easeOutCubic),
      ),
    );

    _fadeTitleAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: const Interval(0.38, 0.72, curve: Curves.easeIn),
      ),
    );

    _scaleButtonAnim = Tween<double>(begin: 1.0, end: 1.03).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOutSine),
    );

    _entranceController.forward();
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _floatingController.dispose();
    _pulseController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _navigateToLogin() async {
    FocusScope.of(context).unfocus();
    await _entranceController.reverse();
    if (!mounted) return;
    Navigator.pushReplacementNamed(context, '/login');
  }

  // ===== SLIDE 1: WELCOME =====
Widget _buildSlide1() {
  return Stack(
    fit: StackFit.expand,
    children: [
      // Background
      Image.asset(
        'assets/images/Slide1.jpg',
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: kBg),
      ),
      // Overlay biar teks kebaca
      Container(
        color: kBg.withOpacity(0.55),
      ),
      // Konten
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ShaderMask(
              shaderCallback: (b) => const LinearGradient(
                colors: [Colors.white, kRed],
              ).createShader(b),
              child: const Text(
                'WELCOME.',
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 42,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                  letterSpacing: 6,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Cyber Glass Dashboard',
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 16,
                color: kWhite70.withOpacity(0.9),
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 24),
            const Icon(
              Icons.arrow_downward_rounded,
              color: kRed,
              size: 32,
            ),
          ],
        ),
      ),
    ],
  );
}

  // ===== SLIDE 2: ARABIC =====
Widget _buildSlide2() {
  return Stack(
    fit: StackFit.expand,
    children: [
      // Background
      Image.asset(
        'assets/images/Slide2.jpg',
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: kBg),
      ),
      Container(
        color: kBg.withOpacity(0.55),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Bēnvēnūtī',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.w700,
                color: Colors.white,
                height: 1.3,
                fontFamily: 'Orbitron',
              ),
            ),
            const SizedBox(height: 20),
            Text(
              '''VEXORV

Costruito per chi è coraggioso.
Creato per chi ha sete di eccellenza.

Non è solo un tool.  
Questa è un'arma digitale.  
Usala nel miglior modo possibile.

VEXORV – Beyond the Limits.''',
              style: TextStyle(
                fontSize: 15,
                color: kWhite70.withOpacity(0.9),
                height: 1.8,
                fontFamily: 'ShareTechMono',
              ),
            ),
            const SizedBox(height: 24),
            const Icon(
              Icons.arrow_downward_rounded,
              color: kRed,
              size: 32,
            ),
          ],
        ),
      ),
    ],
  );
}

  // ===== SLIDE 3: VEXORV LANDING =====
  Widget _buildSlide3Vexorv() {
    final size = MediaQuery.of(context).size;

    return Stack(
      fit: StackFit.expand,
      children: [
        // ===== BACKGROUND =====
        Image.asset(
  'assets/images/landing_bg.jpg',
  fit: BoxFit.cover,
  errorBuilder: (_, __, ___) => Container(color: kBg),
),

        // ===== Overlay =====
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                kBg.withOpacity(0.72),
                kBg.withOpacity(0.45),
                kBg.withOpacity(0.92),
              ],
            ),
          ),
        ),

        // ===== Glow blobs =====
        Positioned(
          top: -80,
          left: -80,
          child: _GlowBlob(
            color: kRed.withOpacity(0.20),
            size: 220,
          ),
        ),
        Positioned(
          bottom: -120,
          right: -90,
          child: _GlowBlob(
            color: kRed.withOpacity(0.12),
            size: 260,
          ),
        ),

        // ===== CHARACTER =====
        SlideTransition(
          position: _charSlideAnim,
          child: AnimatedBuilder(
            animation: _floatingController,
            builder: (context, child) {
              final dy = math.sin(_floatingController.value * 2 * math.pi) * 10;
              return Transform.translate(
                offset: Offset(0, dy),
                child: Align(
                  alignment: Alignment.bottomRight,
                  child: SizedBox(
                    height: size.height * 0.86,
                    width: size.width,
                    child: Image.asset(
  'assets/images/character.png',
  fit: BoxFit.contain,
  alignment: Alignment.bottomRight,
  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
),
                  ),
                ),
              );
            },
          ),
        ),

        // ===== CONTENT =====
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),

              // Brand Chip
              AnimatedBuilder(
                animation: _floatingController,
                builder: (context, child) {
                  final dy = math.sin((_floatingController.value * 2 * math.pi) + 0.0) * 6;
                  return Transform.translate(
                    offset: Offset(0, dy),
                    child: _GlassPanel(
                      glow: true,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      radius: 16,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.water_drop_rounded, color: kRed, size: 18),
                          SizedBox(width: 8),
                          Text(
                            "VEXORV",
                            style: TextStyle(
                              color: kWhite,
                              fontFamily: 'Orbitron',
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // System Profile
              AnimatedBuilder(
                animation: _floatingController,
                builder: (context, child) {
                  final dy = math.sin((_floatingController.value * 2 * math.pi) + 0.55) * 6;
                  return Transform.translate(
                    offset: Offset(0, dy),
                    child: _GlassPanel(
                      padding: const EdgeInsets.all(14),
                      radius: 20,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          _MiniPill(text: "SYSTEM PROFILE"),
                          SizedBox(height: 10),
                          Text(
                            "Cyber Glass Dashboard",
                            style: TextStyle(
                              color: kWhite,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                            ),
                          ),
                          SizedBox(height: 8),
                          Divider(height: 1, thickness: 0.8),
                          SizedBox(height: 10),
                          Text(
                            "Theme: Dark Shadow\nMode: Premium (Calm)\nStatus: Online",
                            style: TextStyle(
                              color: kWhite70,
                              fontFamily: 'ShareTechMono',
                              fontSize: 12,
                              height: 1.35,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),

              const Spacer(),

              // Title
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "WELCOME TO",
                    style: TextStyle(
                      color: kWhite70.withOpacity(0.9),
                      fontSize: 12,
                      letterSpacing: 4,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Image.network(
                          "https://files.catbox.moe/65s9yd.jpg",
                          width: 46,
                          height: 46,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            width: 46,
                            height: 46,
                            color: kBg,
                            alignment: Alignment.center,
                            child: const Icon(Icons.image_not_supported,
                                color: kWhite54),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              "VEXORV",
                              style: TextStyle(
                                fontFamily: 'Orbitron',
                                fontSize: 34,
                                fontWeight: FontWeight.w900,
                                color: kWhite,
                                letterSpacing: 1.5,
                                shadows: [
                                  Shadow(color: kRed, blurRadius: 14),
                                ],
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              "Cyber Glass Dashboard • Dark Shadow",
                              style: TextStyle(
                                color: kWhite70,
                                fontFamily: 'ShareTechMono',
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // CTA Button
              ScaleTransition(
                scale: _scaleButtonAnim,
                child: GestureDetector(
                  onTap: _navigateToLogin,
                  child: Container(
                    height: 60,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [kRed, kRedGlow],
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: kRed.withOpacity(0.3),
                          blurRadius: 20,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.rocket_launch_rounded,
                            color: Colors.black, size: 24),
                        SizedBox(width: 10),
                        Text(
                          "LAUNCH SYSTEM",
                          style: TextStyle(
                            fontFamily: 'Orbitron',
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: Colors.black,
                            letterSpacing: 1.6,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

        // ===== GALLERY =====
        AnimatedBuilder(
          animation: _floatingController,
          builder: (context, child) {
            final dy = math.sin((_floatingController.value * 2 * math.pi) + 0.85) * 6;
            return Positioned(
              top: 160,
              right: 16,
              child: Transform.translate(
                offset: Offset(0, dy),
                child: _GlassPanel(
                  padding: const EdgeInsets.all(12),
                  radius: 20,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const _MiniPill(text: "GALLERY", alignEnd: true),
                      const SizedBox(height: 10),
                      Column(
                        children: [
                          _buildGalleryItem("https://files.catbox.moe/kvdu22.jpg"),
                          const SizedBox(height: 8),
                          _buildGalleryItem("https://files.catbox.moe/65s9yd.jpg"),
                          const SizedBox(height: 8),
                          _buildGalleryItem("https://files.catbox.moe/fuqb8x.jpg"),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background gradient
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  kBg,
                  kBg,
                  kBg,
                ],
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _fadeUiAnim,
              child: SlideTransition(
                position: _slideUiAnim,
                child: Stack(
                  children: [
                    PageView(
                      controller: _pageController,
                      scrollDirection: Axis.vertical,
                      onPageChanged: (index) {
                        setState(() {
                          _currentPage = index;
                        });
                      },
                      children: [
                        _buildSlide1(),
                        _buildSlide2(),
                        _buildSlide3Vexorv(),
                      ],
                    ),
                    // Dot Indicator
                    Positioned(
                      right: 14,
                      top: 0,
                      bottom: 0,
                      child: Center(
                        child: _buildDotIndicator(),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGalleryItem(String url) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 68,
        height: 68,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: kRed.withOpacity(0.3), width: 1),
        ),
        child: Image.network(
          url,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(
            color: kBg.withOpacity(0.6),
            child: const Center(
              child: Icon(Icons.image_not_supported, color: kWhite54),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDotIndicator() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (index) {
        final isActive = _currentPage == index;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          margin: const EdgeInsets.symmetric(vertical: 4),
          width: isActive ? 12 : 8,
          height: isActive ? 12 : 8,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: isActive ? kRed : kWhite24,
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: kRed.withOpacity(0.4),
                      blurRadius: 10,
                    ),
                  ]
                : null,
          ),
        );
      }),
    );
  }
}

// ===== Mini pill label =====
class _MiniPill extends StatelessWidget {
  final String text;
  final bool alignEnd;

  const _MiniPill({
    required this.text,
    this.alignEnd = false,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: alignEnd ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: kBg.withOpacity(0.3),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kRed.withOpacity(0.2)),
        ),
        child: Text(
          text,
          style: const TextStyle(
            color: kWhite70,
            fontSize: 10,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.2,
            fontFamily: 'ShareTechMono',
          ),
        ),
      ),
    );
  }
}

// ===== Glow blob =====
class _GlowBlob extends StatelessWidget {
  final Color color;
  final double size;

  const _GlowBlob({
    required this.color,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [
              color,
              color.withOpacity(0.4),
              Colors.transparent,
            ],
          ),
        ),
      ),
    );
  }
}

// ===== Floating wrapper =====
class _FloatingWidget extends StatelessWidget {
  final AnimationController controller;
  final Widget child;
  final double delay;

  const _FloatingWidget({
    required this.controller,
    required this.child,
    this.delay = 0.0,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final offsetValue =
            math.sin((controller.value * 2 * math.pi) + delay) * 6.0;

        return Transform.translate(
          offset: Offset(0, offsetValue),
          child: child,
        );
      },
    );
  }
}

// ===== Glass Panel =====
class _GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final bool glow;

  const _GlassPanel({
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.radius = 20,
    this.glow = false,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(
              color: glow
                  ? kRed.withOpacity(0.4)
                  : kRed.withOpacity(0.15),
              width: 1,
            ),
            boxShadow: glow
                ? [
                    BoxShadow(
                      color: kRed.withOpacity(0.2),
                      blurRadius: 20,
                      offset: const Offset(0, 8),
                    )
                  ]
                : null,
          ),
          child: child,
        ),
      ),
    );
  }
}