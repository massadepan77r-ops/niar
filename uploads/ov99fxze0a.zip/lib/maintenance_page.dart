// maintenance_page.dart — Simple Update Prompt (inspired by image)
// ✅ Tema: Clean dark with Material Design
// ✅ Fungsi asli: auto re-check, countdown, retry, openUrl, info dialog
// ✅ UI: Icon, judul, pesan, versi, dua tombol: LEARNMORE & UPDATENOW

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math; // <-- FIX: tambahkan import math
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

// ════════════════════════════════════════════════════════════════
//  KONSTANTA ENDPOINT (ganti dengan URL API Anda)
// ════════════════════════════════════════════════════════════════
const String _statusEndpoint = 'http://zyroxlegal.rexy-stecu.my.id:10580/api/status'; // <-- GANTI

// ════════════════════════════════════════════════════════════════
//  WIDGET UTAMA
// ════════════════════════════════════════════════════════════════
class MaintenancePage extends StatefulWidget {
  final String       message;
  final String       version;
  final String       downloadUrl;
  final VoidCallback onRetry;

  const MaintenancePage({
    super.key,
    required this.message,
    required this.version,
    required this.downloadUrl,
    required this.onRetry,
  });

  @override
  State<MaintenancePage> createState() => _MaintenancePageState();
}

class _MaintenancePageState extends State<MaintenancePage> {
  // ══════════════════════════════════════════════════════════════
  //  STATE VARIABLES
  // ══════════════════════════════════════════════════════════════
  Timer? _recheckTimer;
  Timer? _countdownTimer;
  bool   _checking    = false;
  int    _countdown   = 30;
  bool   _btnPressed  = false;   // efek tap tombol update

  // ══════════════════════════════════════════════════════════════
  //  INIT
  // ══════════════════════════════════════════════════════════════
  @override
  void initState() {
    super.initState();

    // Auto re-check tiap 30 detik
    _recheckTimer =
        Timer.periodic(const Duration(seconds: 30), (_) => _checkStatus());

    // Countdown display (tetap jalan, tapi tidak ditampilkan)
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() => _countdown = _countdown > 0 ? _countdown - 1 : 30);
    });
  }

  // ══════════════════════════════════════════════════════════════
  //  DISPOSE
  // ══════════════════════════════════════════════════════════════
  @override
  void dispose() {
    _recheckTimer?.cancel();
    _countdownTimer?.cancel();
    super.dispose();
  }

  // ══════════════════════════════════════════════════════════════
  //  LOGIC: Cek status maintenance
  // ══════════════════════════════════════════════════════════════
  Future<void> _checkStatus() async {
    if (_checking || !mounted) return;
    setState(() {
      _checking  = true;
      _countdown = 30;
    });
    try {
      final res = await http
          .get(Uri.parse(_statusEndpoint))
          .timeout(const Duration(seconds: 10));
      if (!mounted) return;
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final isActive = data['maintenance'] == true;
        if (!isActive) {
          widget.onRetry();
          return;
        }
      }
    } on TimeoutException {
      // Timeout — tetap di halaman maintenance
    } on FormatException {
      // JSON parse error — abaikan
    } catch (_) {
      // Network error atau lainnya — abaikan
    }
    if (mounted) setState(() => _checking = false);
  }

  // ══════════════════════════════════════════════════════════════
  //  LOGIC: Buka URL download
  // ══════════════════════════════════════════════════════════════
  Future<void> _openUrl(String url) async {
    if (url.isEmpty) return;
    try {
      final uri = Uri.parse(url);
      final launched =
          await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Row(
              children: [
                Icon(Icons.error_outline, color: Colors.white, size: 18),
                SizedBox(width: 10),
                Text('Tidak dapat membuka link'),
              ],
            ),
            backgroundColor: Colors.red.shade800,
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.all(16),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14)),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } on FormatException {
      // URL tidak valid
    } catch (_) {}
  }

  // ══════════════════════════════════════════════════════════════
  //  UI: Dialog Informasi (untuk tombol LEARNMORE)
  // ══════════════════════════════════════════════════════════════
  void _showInfoDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          'Informasi',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Text(
          widget.message.isNotEmpty
              ? widget.message
              : 'Aplikasi sedang dalam pemeliharaan.\nMohon tunggu hingga proses selesai.',
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text(
              'Tutup',
              style: TextStyle(color: Colors.blueAccent),
            ),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  BUILD
  // ══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // ── Icon Update ──────────────────────────────────
              Icon(
                Icons.system_update_alt_rounded,
                color: Colors.blueAccent,
                size: 80,
              ),

              const SizedBox(height: 24),

              // ── Judul ────────────────────────────────────────
              const Text(
                'UPDATE AVAILABLE',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.2,
                ),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 12),

              // ── Pesan ──────────────────────────────────────
              Text(
                _checking
                    ? 'Memeriksa pembaruan...'
                    : (widget.message.isNotEmpty
                        ? widget.message
                        : 'Unable to check for updates.\nPlease check your internet connection and try again.'),
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  height: 1.6,
                ),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 20),

              // ── Versi ───────────────────────────────────────
              Text(
                'Version ${widget.version.isEmpty ? 'Unknown' : widget.version}',
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),

              const SizedBox(height: 32),

              // ── Tombol ──────────────────────────────────────
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // LEARNMORE
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _showInfoDialog,
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.blueAccent),
                        foregroundColor: Colors.blueAccent,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'LEARNMORE',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(width: 12),

                  // UPDATENOW
                  Expanded(
                    child: ElevatedButton(
                      onPressed: widget.downloadUrl.isNotEmpty
                          ? () => _openUrl(widget.downloadUrl)
                          : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blueAccent,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        disabledBackgroundColor: Colors.blueAccent.withOpacity(0.4),
                      ),
                      child: const Text(
                        'UPDATE NOW',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0,
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              // ── Loading indicator saat checking ─────────────
              if (_checking) ...[
                const SizedBox(height: 24),
                const CircularProgressIndicator(
                  color: Colors.blueAccent,
                  strokeWidth: 2,
                ),
              ],

              // ── Small footer (opsional) ─────────────────────
              const SizedBox(height: 32),
              Text(
                '© ᴠᴇxᴏʀᴠ App System',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 10,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CyberBgPainter extends CustomPainter {
  final double angle;
  final double scanProg;

  const _CyberBgPainter({required this.angle, required this.scanProg});

  static const Color _blue = Color(0xFFFF0800);

  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = _blue.withOpacity(0.015)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;
    
    const g = 30.0;
    for (double x = 0; x <= size.width; x += g) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y <= size.height; y += g) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    final double sy = size.height * scanProg;
    final scanPaintLine = Paint()
      ..color = _blue.withOpacity(0.025)
      ..strokeWidth = 1.5;
    canvas.drawLine(Offset(0, sy), Offset(size.width, sy), scanPaintLine);

    final rng = math.Random(42);
    final t   = angle / (2 * math.pi);
    final particlePaint = Paint()..style = PaintingStyle.fill;
    
    for (int i = 0; i < 12; i++) {
      final bx  = rng.nextDouble() * size.width;
      final by  = rng.nextDouble() * size.height;
      final ox  = math.cos(t * 2 * math.pi + i) * 6;
      final oy  = math.sin(t * 2 * math.pi + i) * 10;
      
      particlePaint.color = _blue.withOpacity(0.06);
      canvas.drawCircle(Offset(bx + ox, by + oy), 1.2, particlePaint);
    }
  }

  @override
  bool shouldRepaint(_CyberBgPainter old) =>
      old.angle != angle || old.scanProg != scanProg;
}