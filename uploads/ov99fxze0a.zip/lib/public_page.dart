// ============================================================
// FILE: public_page.dart
// VERSION: Blackdeath SUPREME EDITION 🔥
// STATUS: ZERO ERROR + ULTRA PREMIUM UI
// ============================================================

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PublicChatPage extends StatefulWidget {
  final String username;
  const PublicChatPage({super.key, required this.username});

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  
  // ─── KONFIGURASI ──────────────────────────────────────────────────
  final String baseUrl = "http://zyroxlegal.rexy-stecu.my.id:10580";

  // ─── CONTROLLERS ──────────────────────────────────────────────────
  final TextEditingController _msgController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  // ─── STATE ─────────────────────────────────────────────────────────
  List<dynamic> _messages = [];
  int _onlineUsers = 0;
  Timer? _refreshTimer;
  Timer? _onlineTimer;
  bool _isSending = false;
  bool _isUploadingImage = false;
  bool _isLoading = true;
  bool _isTyping = false;

  // ─── IMAGE PICKER ──────────────────────────────────────────────────
  final ImagePicker _picker = ImagePicker();

  // ─── ANIMASI ────────────────────────────────────────────────────────
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;
  late AnimationController _bounceCtrl;
  late Animation<double> _bounceAnim;

  // ─── WARNA SUPREME ────────────────────────────────────────────────
  static const Color _kBg = Color(0xFF0A0A0F);
  static const Color _kCard = Color(0xFF121218);
  static const Color _kCardAlt = Color(0xFF1A1A22);
  static const Color _kBorder = Color(0x40FF0800);
  static const Color _kRed = Color(0xFFFF0800);
  static const Color _kDarkRed = Color(0xFF660708);
  static const Color _kDeepRed = Color(0xFF8A0E1B);
  static const Color _kGold = Color(0xFFFFD700);
  static const Color _kWhite = Color(0xFFFFFFFF);
  static const Color _kWhite70 = Color(0xB3FFFFFF);
  static const Color _kWhite54 = Color(0x8AFFFFFF);
  static const Color _kWhite24 = Color(0x3DFFFFFF);
  static const Color _kGreen = Color(0xFF00FF88);
  static const Color _kGradientStart = Color(0xFF660708);
  static const Color _kGradientEnd = Color(0xFF8A0E1B);
  static const Color _kBubbleMe = Color(0xFF660708);
  static const Color _kBubbleOther = Color(0xFF1A1A22);
  static const Color _kGlass = Color(0x20FFFFFF);

  // ─── INIT ──────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _initAnimations();
    _fetchMessages();
    _fetchOnlineUsers();
    _startTimers();
  }

  void _initAnimations() {
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.92, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.2, end: 0.9).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );

    _bounceCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
    _bounceAnim = Tween<double>(begin: 0.0, end: -8.0).animate(
      CurvedAnimation(parent: _bounceCtrl, curve: Curves.easeInOut),
    );
  }

  void _startTimers() {
    _refreshTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      if (mounted) _fetchMessages();
    });

    _onlineTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (mounted) _fetchOnlineUsers();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _refreshTimer?.cancel();
    _onlineTimer?.cancel();
    _msgController.dispose();
    _scrollController.dispose();
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _glowCtrl.dispose();
    _bounceCtrl.dispose();
    super.dispose();
  }

  // ─── API CALLS ──────────────────────────────────────────────────────

  Future<void> _fetchMessages() async {
    try {
      final res = await http.post(
        Uri.parse("$baseUrl/get-public-chat"),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 5));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          List newMsgs = data['messages'] ?? [];
          bool shouldScroll = newMsgs.length > _messages.length;
          if (mounted) {
            setState(() {
              _messages = newMsgs;
              _isLoading = false;
            });
            if (shouldScroll) _scrollToBottom();
          }
        }
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final res = await http.get(
        Uri.parse("$baseUrl/online-users"),
      ).timeout(const Duration(seconds: 3));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['online'] != null && mounted) {
          setState(() => _onlineUsers = data['online']);
        }
      }
    } catch (_) {}
  }

  Future<void> _sendMessage({String? imageBase64}) async {
    String text = _msgController.text.trim();
    if (text.isEmpty && imageBase64 == null) return;

    _msgController.clear();
    setState(() {
      _isSending = true;
      _isTyping = false;
    });

    try {
      final body = {
        "username": widget.username,
        "message": text,
      };
      if (imageBase64 != null) {
        body["image"] = imageBase64;
      }

      final response = await http.post(
        Uri.parse("$baseUrl/send-public-chat"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(body),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        await _fetchMessages();
        _scrollToBottom();
      }
    } catch (_) {
      if (mounted) _showSnackbar("Failed to send message", isError: true);
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
        maxWidth: 1024,
      );
      if (pickedFile != null) {
        setState(() => _isUploadingImage = true);
        final bytes = await pickedFile.readAsBytes();
        final base64Image = base64Encode(bytes);
        await _sendMessage(imageBase64: base64Image);
        setState(() => _isUploadingImage = false);
      }
    } catch (_) {
      if (mounted) {
        _showSnackbar("Failed to pick image", isError: true);
      }
      setState(() => _isUploadingImage = false);
    }
  }

  void _showImageSourceDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => TweenAnimationBuilder(
        tween: Tween<double>(begin: 0.85, end: 1.0),
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeOutCubic,
        builder: (context, value, child) => Transform.scale(
          scale: value,
          child: child,
        ),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_kCard, _kBg],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
            border: Border(
              top: BorderSide(color: _kRed.withOpacity(0.15), width: 1),
            ),
          ),
          child: ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: SafeArea(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Handle
                    Container(
                      margin: const EdgeInsets.symmetric(vertical: 12),
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: _kWhite24,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    // Header
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'ATTACH IMAGE',
                            style: TextStyle(
                              color: _kWhite,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1,
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: _kRed.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: _kRed.withOpacity(0.15)),
                            ),
                            child: const Icon(
                              Icons.image_rounded,
                              color: _kRed,
                              size: 20,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Divider(color: _kWhite24),
                    // Camera
                    _buildDialogOption(
                      icon: Icons.camera_alt_rounded,
                      title: 'Camera',
                      subtitle: 'Take a photo with camera',
                      onTap: () {
                        Navigator.pop(context);
                        _pickImage(ImageSource.camera);
                      },
                    ),
                    // Gallery
                    _buildDialogOption(
                      icon: Icons.photo_library_rounded,
                      title: 'Gallery',
                      subtitle: 'Choose from gallery',
                      onTap: () {
                        Navigator.pop(context);
                        _pickImage(ImageSource.gallery);
                      },
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDialogOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: _kBg.withOpacity(0.4),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kWhite24),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_kGradientStart, _kGradientEnd],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: _kRed.withOpacity(0.2),
                blurRadius: 10,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Icon(icon, color: _kWhite, size: 22),
        ),
        title: Text(
          title,
          style: const TextStyle(
            color: _kWhite,
            fontWeight: FontWeight.w600,
            fontSize: 15,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(color: _kWhite54, fontSize: 12),
        ),
        trailing: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: _kRed.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: const Icon(
            Icons.arrow_forward_ios_rounded,
            color: _kRed,
            size: 14,
          ),
        ),
        onTap: onTap,
      ),
    );
  }

  // ─── HELPERS ──────────────────────────────────────────────────────

  void _showSnackbar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline_rounded : Icons.check_circle_rounded,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
        backgroundColor: isError ? _kDarkRed : _kCard,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: isError ? _kRed : _kRed.withOpacity(0.3),
            width: 1,
          ),
        ),
        elevation: 20,
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  String _formatTime(String? timeStr) {
    if (timeStr == null || timeStr.isEmpty) return '';
    return timeStr;
  }

  // ─── UI ──────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: _buildSupremeAppBar(),
      body: _isLoading
          ? _buildLoadingScreen()
          : Stack(
              children: [
                Column(
                  children: [
                    _buildOnlineStatus(),
                    Expanded(
                      child: _messages.isEmpty
                          ? _buildEmptyState()
                          : ListView.builder(
                              controller: _scrollController,
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              itemCount: _messages.length,
                              itemBuilder: (context, index) {
                                final msg = _messages[index];
                                final isMe = msg['username'] == widget.username;
                                return _buildChatBubble(msg, isMe);
                              },
                            ),
                    ),
                    _buildInputArea(),
                  ],
                ),
                if (_isTyping)
                  Positioned(
                    bottom: 100,
                    left: 0,
                    right: 0,
                    child: _buildTypingIndicator(),
                  ),
              ],
            ),
    );
  }

  // ─── SUPREME APP BAR ──────────────────────────────────────────────

  PreferredSizeWidget _buildSupremeAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      flexibleSpace: ClipRRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _kBg.withOpacity(0.85),
                  _kCard.withOpacity(0.85),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              border: Border(
                bottom: BorderSide(
                  color: _kRed.withOpacity(0.08),
                  width: 0.5,
                ),
              ),
            ),
          ),
        ),
      ),
      title: Row(
        children: [
          AnimatedBuilder(
            animation: _glowCtrl,
            builder: (context, child) => Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_kGradientStart, _kGradientEnd],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: _kRed.withOpacity(_glowAnim.value),
                    blurRadius: 25,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: const Icon(Icons.public_rounded, color: _kWhite, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'PUBLIC CHAT',
                style: TextStyle(
                  color: _kWhite,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
              ),
              AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (context, child) => Row(
                  children: [
                    Transform.scale(
                      scale: _pulseAnim.value,
                      child: Container(
                        width: 6,
                        height: 6,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: _kGreen,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '$_onlineUsers online',
                      style: TextStyle(
                        color: _kWhite54,
                        fontSize: 10,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: _kCard,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _kWhite24),
          ),
          child: const Icon(Icons.arrow_back_rounded, color: _kWhite, size: 20),
        ),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: _kCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _kWhite24),
          ),
          child: Row(
            children: [
              AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (context, child) => Transform.scale(
                  scale: _pulseAnim.value,
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: _kGreen,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                _onlineUsers > 0 ? '$_onlineUsers Online' : 'Offline',
                style: TextStyle(
                  color: _onlineUsers > 0 ? _kWhite54 : _kWhite24,
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: _kCard,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _kWhite24),
          ),
          child: const Icon(Icons.more_vert_rounded, color: _kWhite54, size: 20),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  // ─── LOADING SCREEN ───────────────────────────────────────────────

  Widget _buildLoadingScreen() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedBuilder(
            animation: _glowCtrl,
            builder: (context, child) => Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [_kGradientStart, _kGradientEnd],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _kRed.withOpacity(_glowAnim.value),
                    blurRadius: 50,
                    spreadRadius: 10,
                  ),
                ],
              ),
              child: const Center(
                child: SizedBox(
                  width: 30,
                  height: 30,
                  child: CircularProgressIndicator(
                    color: _kWhite,
                    strokeWidth: 2,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 30),
          const Text(
            'PUBLIC CHAT',
            style: TextStyle(
              color: _kWhite,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Loading messages...',
            style: TextStyle(color: _kWhite54, fontSize: 13),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(3, (index) => AnimatedBuilder(
              animation: _bounceCtrl,
              builder: (context, child) => Transform.translate(
                offset: Offset(0, _bounceAnim.value * (index == 1 ? 1 : 0.5)),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _kRed.withOpacity(0.3 + (index * 0.3)),
                  ),
                ),
              ),
            )),
          ),
        ],
      ),
    );
  }

  // ─── ONLINE STATUS ─────────────────────────────────────────────────

  Widget _buildOnlineStatus() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: _kCard.withOpacity(0.3),
        border: Border(
          bottom: BorderSide(color: _kWhite24, width: 0.3),
        ),
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (context, child) => Transform.scale(
              scale: _pulseAnim.value,
              child: Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _onlineUsers > 0 ? _kGreen : _kWhite24,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            _onlineUsers > 0
                ? '$_onlineUsers users online • ${_messages.length} messages'
                : 'No users online',
            style: TextStyle(
              color: _onlineUsers > 0 ? _kWhite54 : _kWhite24,
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: _kRed.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _kRed.withOpacity(0.15)),
            ),
            child: Text(
              '${_messages.length}',
              style: const TextStyle(
                color: _kRed,
                fontSize: 9,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── EMPTY STATE ───────────────────────────────────────────────────

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedBuilder(
            animation: _glowCtrl,
            builder: (context, child) => Container(
              padding: const EdgeInsets.all(30),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [_kCard, _kCardAlt],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: _kRed.withOpacity(_glowAnim.value),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _kRed.withOpacity(_glowAnim.value * 0.3),
                    blurRadius: 40,
                    spreadRadius: 15,
                  ),
                ],
              ),
              child: const Icon(
                Icons.chat_bubble_outline_rounded,
                color: _kWhite24,
                size: 50,
              ),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'NO MESSAGES YET',
            style: TextStyle(
              color: _kWhite,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Be the first to start the conversation',
            style: TextStyle(color: _kWhite54, fontSize: 13),
          ),
          const SizedBox(height: 24),
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (context, child) => Transform.scale(
              scale: _pulseAnim.value,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [_kGradientStart, _kGradientEnd],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: _kRed.withOpacity(0.4),
                      blurRadius: 25,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.send_rounded, color: _kWhite, size: 18),
                    SizedBox(width: 10),
                    Text(
                      'SEND FIRST MESSAGE',
                      style: TextStyle(
                        color: _kWhite,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── CHAT BUBBLE ──────────────────────────────────────────────────

  Widget _buildChatBubble(dynamic msg, bool isMe) {
    final String? imageUrl = msg['image'];
    final String message = msg['message'] ?? '';
    final String time = msg['time'] ?? '';
    final String username = msg['username'] ?? 'Unknown';

    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) => Transform.translate(
        offset: Offset(0, 30 * (1 - value)),
        child: Opacity(opacity: value, child: child),
      ),
      child: Align(
        alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.78,
          ),
          child: Column(
            crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: [
              if (!isMe)
                Padding(
                  padding: const EdgeInsets.only(left: 12, bottom: 6),
                  child: Row(
                    children: [
                      Container(
                        width: 26,
                        height: 26,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            colors: [_kGradientStart, _kGradientEnd],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _kRed.withOpacity(0.2),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            username.substring(0, 1).toUpperCase(),
                            style: const TextStyle(
                              color: _kWhite,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        username,
                        style: const TextStyle(
                          color: _kRed,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              // ─── FIX: CHAT BUBBLE WITHOUT loadingBuilder ──────────
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isMe
                        ? [_kBubbleMe, _kGradientEnd]
                        : [_kBubbleOther, _kCard],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(20),
                    topRight: const Radius.circular(20),
                    bottomLeft: Radius.circular(isMe ? 20 : 4),
                    bottomRight: Radius.circular(isMe ? 4 : 20),
                  ),
                  border: Border.all(
                    color: isMe ? _kRed.withOpacity(0.25) : _kWhite24,
                    width: 0.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: isMe ? _kRed.withOpacity(0.15) : Colors.black.withOpacity(0.2),
                      blurRadius: 15,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ─── FIX: IMAGE WITHOUT loadingBuilder ──────────
                    if (imageUrl != null && imageUrl.isNotEmpty) ...[
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.memory(
                          base64Decode(imageUrl),
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: 200,
                          errorBuilder: (_, __, ___) => Container(
                            height: 200,
                            color: _kCard,
                            child: const Icon(
                              Icons.broken_image_rounded,
                              color: _kWhite24,
                              size: 40,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                    ],
                    if (message.isNotEmpty)
                      Text(
                        message,
                        style: const TextStyle(
                          color: _kWhite,
                          fontSize: 14,
                          height: 1.4,
                        ),
                      ),
                    const SizedBox(height: 4),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Text(
                        _formatTime(time),
                        style: TextStyle(
                          color: _kWhite.withOpacity(0.35),
                          fontSize: 9,
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── TYPING INDICATOR ─────────────────────────────────────────────

  Widget _buildTypingIndicator() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: _kCard.withOpacity(0.85),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kWhite24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'Someone is typing',
            style: TextStyle(
              color: _kWhite54,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(width: 12),
          Row(
            children: List.generate(3, (index) => TweenAnimationBuilder(
              tween: Tween<double>(begin: 0.0, end: 1.0),
              duration: Duration(milliseconds: 600 + (index * 200)),
              curve: Curves.easeInOut,
              builder: (context, value, child) => Transform.translate(
                offset: Offset(0, -6 * value),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _kRed.withOpacity(0.3 + (value * 0.5)),
                  ),
                ),
              ),
            )),
          ),
        ],
      ),
    );
  }

  // ─── INPUT AREA ────────────────────────────────────────────────────

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _kCard,
        border: Border(
          top: BorderSide(color: _kWhite24, width: 0.3),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Row(
        children: [
          // ─── ATTACH BUTTON ──────────────────────────────────────
          GestureDetector(
            onTap: _isUploadingImage ? null : _showImageSourceDialog,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: _isUploadingImage ? _kCard : _kBg,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _isUploadingImage ? _kRed.withOpacity(0.3) : _kWhite24,
                  width: 1,
                ),
                boxShadow: _isUploadingImage
                    ? []
                    : [
                        BoxShadow(
                          color: _kRed.withOpacity(0.1),
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
              ),
              child: Center(
                child: _isUploadingImage
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: _kRed,
                        ),
                      )
                    : const Icon(
                        Icons.attach_file_rounded,
                        color: _kRed,
                        size: 22,
                      ),
              ),
            ),
          ),
          const SizedBox(width: 10),

          // ─── TEXT INPUT ──────────────────────────────────────────
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: _kBg,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _kWhite24),
                boxShadow: [
                  BoxShadow(
                    color: _kRed.withOpacity(0.05),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: TextField(
                controller: _msgController,
                style: const TextStyle(color: _kWhite, fontSize: 14),
                cursorColor: _kRed,
                decoration: InputDecoration(
                  hintText: "Type a message...",
                  hintStyle: TextStyle(color: _kWhite24, fontSize: 13),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 10),
                ),
                onSubmitted: (_) => _sendMessage(),
                onChanged: (value) {
                  setState(() => _isTyping = value.isNotEmpty);
                },
              ),
            ),
          ),
          const SizedBox(width: 10),

          // ─── SEND BUTTON ──────────────────────────────────────────
          GestureDetector(
            onTap: _isSending ? null : _sendMessage,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                gradient: _isSending
                    ? null
                    : const LinearGradient(
                        colors: [_kGradientStart, _kGradientEnd],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                color: _isSending ? _kCard : null,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _isSending ? _kWhite24 : _kRed.withOpacity(0.3),
                  width: 1,
                ),
                boxShadow: _isSending
                    ? []
                    : [
                        BoxShadow(
                          color: _kRed.withOpacity(0.4),
                          blurRadius: 20,
                          spreadRadius: 2,
                        ),
                      ],
              ),
              child: Center(
                child: _isSending
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: _kRed,
                        ),
                      )
                    : const Icon(
                        Icons.send_rounded,
                        color: _kWhite,
                        size: 20,
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}