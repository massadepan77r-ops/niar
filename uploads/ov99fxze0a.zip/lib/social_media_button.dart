// ============================================================
// FILE: social_media_button.dart
// FUNGSI: TOMBOL SOSIAL MEDIA DI DASHBOARD
// DEWA: ZAMZZZ 😈
// ============================================================

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'social_media_page.dart';

class SocialMediaButton extends StatelessWidget {
  final String username;
  final String sessionKey;
  final String role;
  final String expiredDate;

  const SocialMediaButton({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => SocialMediaPage(
              username: username,
              sessionKey: sessionKey,
              role: role,
              expiredDate: expiredDate,
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFFF0800), Color(0xFF800000)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFF0800).withOpacity(0.3),
              blurRadius: 10,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const _DynamicIcon(
                FontAwesomeIcons.video,
                color: Colors.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SOSIAL MEDIA',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                Text(
                  'Follow & Upload Video',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.arrow_forward_ios_rounded,
                color: Colors.white,
                size: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;

  const _DynamicIcon(this.icon, {Key? key, this.size, this.color}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);
    bool isFontAwesome = false;
    try {
      if (icon.runtimeType.toString().contains('FaIcon') || 
          icon.toString().contains('FaIcon') ||
          icon.toString().contains('font_awesome_flutter') ||
          icon.fontPackage == 'font_awesome_flutter') {
        isFontAwesome = true;
      }
    } catch (_) {}
    return Center(
      widthFactor: 1.0,
      heightFactor: 1.0,
      child: isFontAwesome ? FaIcon(icon, size: size, color: color) : Icon(icon, size: size, color: color),
    );
  }
}
// WEBA2APK_DYNAMIC_ICON_END
