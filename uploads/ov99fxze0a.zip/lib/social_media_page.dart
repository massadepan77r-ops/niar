// ============================================================
// FILE: social_media_page.dart
// VERSION: BLACKDEATH ULTRA PREMIUM 🔥 FIXED v3
// STATUS: ZERO ERROR - FULLY FIXED
// API: http://private-panel.gixsz.biz.id:10693
// ============================================================

import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── API ──────────────────────────────────────────────────────────────
const String API_BASE_URL = 'http://zyroxlegal.rexy-stecu.my.id:10580/api';

// ─── THEME ────────────────────────────────────────────────────────────
class SocialTheme {
  static const Color bg = Color(0xFF0A0A0F);
  static const Color card = Color(0xFF121218);
  static const Color cardAlt = Color(0xFF1A1A22);
  static const Color border = Color(0x40FF0800);
  static const Color red = Color(0xFFFF0800);
  static const Color darkRed = Color(0xFF660708);
  static const Color deepRed = Color(0xFF8A0E1B);
  static const Color gold = Color(0xFFFFD700);
  static const Color white = Color(0xFFFFFFFF);
  static const Color white54 = Color(0x8AFFFFFF);
  static const Color white24 = Color(0x3DFFFFFF);
  static const Color green = Color(0xFF00FF88);
  static const Color gradientStart = Color(0xFF660708);
  static const Color gradientEnd = Color(0xFF8A0E1B);
}

// ─── MODELS ────────────────────────────────────────────────────────────

class SocialUser {
  final String id;
  final String username;
  final String name;
  final String? profilePic;
  final String role;
  int followers;
  int following;
  final int postCount;
  final String? joinedAt;
  bool isFollowing;

  SocialUser({
    required this.id,
    required this.username,
    required this.name,
    this.profilePic,
    this.role = 'member',
    this.followers = 0,
    this.following = 0,
    this.postCount = 0,
    this.joinedAt,
    this.isFollowing = false,
  });

  factory SocialUser.fromJson(Map<String, dynamic> json) => SocialUser(
    id: json['id']?.toString() ?? json['username']?.toString() ?? '',
    username: json['username']?.toString() ?? '',
    name: json['name']?.toString() ?? json['username']?.toString() ?? '',
    profilePic: json['profilePic']?.toString(),
    role: json['role']?.toString() ?? 'member',
    followers: json['followers'] ?? 0,
    following: json['following'] ?? 0,
    postCount: json['postCount'] ?? 0,
    joinedAt: json['joinedAt']?.toString(),
    isFollowing: json['isFollowing'] ?? false,
  );

  SocialUser copyWith({bool? isFollowing, int? followers, String? profilePic}) {
    return SocialUser(
      id: id,
      username: username,
      name: name,
      profilePic: profilePic ?? this.profilePic,
      role: role,
      followers: followers ?? this.followers,
      following: following,
      postCount: postCount,
      joinedAt: joinedAt,
      isFollowing: isFollowing ?? this.isFollowing,
    );
  }
}

class SocialPost {
  final String id;
  final String userId;
  final String username;
  final String? caption;
  final String? videoUrl;
  final String? imageUrl;
  final String? thumbnail;
  final DateTime createdAt;
  final List<String> likes;
  final List<SocialComment> comments;
  int likeCount;
  int commentCount;
  bool isLiked;

  SocialPost({
    required this.id,
    required this.userId,
    required this.username,
    this.caption,
    this.videoUrl,
    this.imageUrl,
    this.thumbnail,
    required this.createdAt,
    this.likes = const [],
    this.comments = const [],
    this.likeCount = 0,
    this.commentCount = 0,
    this.isLiked = false,
  });

  factory SocialPost.fromJson(Map<String, dynamic> json) => SocialPost(
    id: json['id']?.toString() ?? '',
    userId: json['userId']?.toString() ?? '',
    username: json['username']?.toString() ?? '',
    caption: json['caption']?.toString(),
    videoUrl: json['videoUrl']?.toString(),
    imageUrl: json['imageUrl']?.toString(),
    thumbnail: json['thumbnail']?.toString(),
    createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '') ?? DateTime.now(),
    likes: List<String>.from(json['likes'] ?? []),
    comments: (json['comments'] as List?)?.map((e) => SocialComment.fromJson(e)).toList() ?? [],
    likeCount: json['likeCount'] ?? 0,
    commentCount: json['commentCount'] ?? 0,
    isLiked: json['isLiked'] ?? false,
  );

  SocialPost copyWith({
    bool? isLiked,
    int? likeCount,
    int? commentCount,
    List<SocialComment>? comments,
  }) {
    return SocialPost(
      id: id,
      userId: userId,
      username: username,
      caption: caption,
      videoUrl: videoUrl,
      imageUrl: imageUrl,
      thumbnail: thumbnail,
      createdAt: createdAt,
      likes: likes,
      comments: comments ?? this.comments,
      likeCount: likeCount ?? this.likeCount,
      commentCount: commentCount ?? this.commentCount,
      isLiked: isLiked ?? this.isLiked,
    );
  }
}

class SocialComment {
  final String username;
  final String text;
  final DateTime createdAt;

  SocialComment({
    required this.username,
    required this.text,
    required this.createdAt,
  });

  factory SocialComment.fromJson(Map<String, dynamic> json) => SocialComment(
    username: json['username']?.toString() ?? '',
    text: json['text']?.toString() ?? '',
    createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '') ?? DateTime.now(),
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────

class SocialMediaPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;
  final String expiredDate;

  const SocialMediaPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<SocialMediaPage> createState() => _SocialMediaPageState();
}

class _SocialMediaPageState extends State<SocialMediaPage>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  
  // ─── STATE ──────────────────────────────────────────────────────────
  List<SocialPost> _posts = [];
  List<SocialUser> _users = [];
  List<SocialUser> _searchResults = [];
  
  String? _selectedVideoPath;
  String? _selectedImagePath;
  String _postCaption = '';
  bool _isUploading = false;
  bool _isLoading = true;
  int _currentTab = 0;
  String _searchQuery = '';
  bool _isVideoUpload = true;
  
  final TextEditingController _commentController = TextEditingController();
  String? _commentingPostId;
  File? _profileImage;
  late TabController _tabController;
  
  final Map<String, VideoPlayerController> _videoControllers = {};
  final Map<String, bool> _videoInitialized = {};
  final Map<String, bool> _likeState = {};

  // ─── ANIMATIONS ──────────────────────────────────────────────────────
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;

  // ─── INIT ──────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initControllers();
    _initAnimations();
    _loadProfileImage();
    _fetchAllData();
  }

  void _initControllers() {
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      if (mounted) setState(() => _currentTab = _tabController.index);
    });
  }

  void _initAnimations() {
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tabController.dispose();
    _commentController.dispose();
    _fadeCtrl.dispose();
    _glowCtrl.dispose();
    for (var c in _videoControllers.values) c.dispose();
    super.dispose();
  }

  // ─── API ────────────────────────────────────────────────────────────
  Map<String, String> _headers() => {
    'Authorization': 'Bearer ${widget.sessionKey}',
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  // ─── DATA FETCHING ──────────────────────────────────────────────────
  Future<void> _fetchAllData() async {
    if (!mounted) return;
    setState(() => _isLoading = true);
    await Future.wait([_fetchPosts(), _fetchUsers()]);
    if (mounted) setState(() => _isLoading = false);
  }

  Future<void> _fetchPosts() async {
    try {
      final res = await http.get(
        Uri.parse('$API_BASE_URL/social/posts'),
        headers: _headers(),
      ).timeout(const Duration(seconds: 15));

      print('[FETCH POSTS] Status: ${res.statusCode}');
      print('[FETCH POSTS] Body: ${res.body}');

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is List) {
          setState(() {
            _posts = data.map((e) => SocialPost.fromJson(e)).toList();
            _initVideoControllers();
            _initLikeState();
          });
        } else if (data['success'] == true && data['posts'] is List) {
          setState(() {
            _posts = (data['posts'] as List).map((e) => SocialPost.fromJson(e)).toList();
            _initVideoControllers();
            _initLikeState();
          });
        }
      }
    } catch (e) { 
      print('[FETCH POSTS ERROR]: $e'); 
    }
  }

  Future<void> _fetchUsers() async {
    try {
      final res = await http.get(
        Uri.parse('$API_BASE_URL/social/users'),
        headers: _headers(),
      ).timeout(const Duration(seconds: 15));

      print('[FETCH USERS] Status: ${res.statusCode}');

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        List userList = [];
        
        if (data['users'] is List) {
          userList = data['users'];
        } else if (data is List) {
          userList = data;
        } else if (data['success'] == true && data['users'] is List) {
          userList = data['users'];
        }
        
        setState(() {
          _users = userList.map((e) => SocialUser.fromJson(e)).toList();
          _searchResults = _users;
        });
      }
    } catch (e) { 
      print('[FETCH USERS ERROR]: $e'); 
    }
  }

  Future<void> _fetchUserPosts(String userId) async {
    try {
      final res = await http.get(
        Uri.parse('$API_BASE_URL/social/posts/user/$userId'),
        headers: _headers(),
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        List postList = [];
        
        if (data is List) {
          postList = data;
        } else if (data['success'] == true && data['posts'] is List) {
          postList = data['posts'];
        }
        
        setState(() {
          _posts = postList.map((e) => SocialPost.fromJson(e)).toList();
          _initVideoControllers();
          _initLikeState();
        });
      }
    } catch (e) { 
      print('[FETCH USER POSTS ERROR]: $e'); 
    }
  }

  // ─── VIDEO ──────────────────────────────────────────────────────────
  void _initVideoControllers() {
    for (var post in _posts) {
      if (post.videoUrl != null && post.videoUrl!.isNotEmpty && 
          !_videoControllers.containsKey(post.id)) {
        _initVideo(post.id, post.videoUrl!);
      }
    }
  }

  Future<void> _initVideo(String postId, String url) async {
    try {
      final fullUrl = url.startsWith('http') ? url : '${API_BASE_URL.replaceAll('/api', '')}$url';
      final ctrl = VideoPlayerController.networkUrl(
        Uri.parse(fullUrl),
        httpHeaders: {'Cache-Control': 'max-age=86400'},
      );
      await ctrl.initialize();
      ctrl.setVolume(0.0);
      ctrl.setLooping(true);
      if (mounted) {
        setState(() {
          _videoControllers[postId] = ctrl;
          _videoInitialized[postId] = true;
        });
      }
      ctrl.play();
    } catch (e) {
      print('[INIT VIDEO ERROR] $postId: $e');
      if (mounted) setState(() => _videoInitialized[postId] = false);
    }
  }

  // ─── STATE INIT ────────────────────────────────────────────────────
  void _initLikeState() {
    _likeState.clear();
    for (var post in _posts) {
      _likeState[post.id] = post.isLiked;
    }
  }

  // ─── FOLLOW ──────────────────────────────────────────────────────
  Future<void> _toggleFollow(String targetId) async {
    print('[FOLLOW] Target: $targetId');
    
    final currentUser = _getCurrentUser();
    if (currentUser != null && (targetId == currentUser.id || targetId == currentUser.username)) {
      _showSnackbar('Cannot follow yourself');
      return;
    }

    final idx = _users.indexWhere((u) => u.id == targetId || u.username == targetId);
    if (idx == -1) { 
      _showSnackbar('User not found', isError: true); 
      return; 
    }

    final currentState = _users[idx].isFollowing;
    _updateUserLocally(idx, !currentState);

    try {
      final response = await http.post(
        Uri.parse('$API_BASE_URL/social/follow'),
        headers: _headers(),
        body: jsonEncode({
          'username': widget.username,
          'targetUsername': _users[idx].username,
        }),
      ).timeout(const Duration(seconds: 10));

      print('[FOLLOW] Status: ${response.statusCode}');
      print('[FOLLOW] Body: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          _updateUserLocally(idx, data['isFollowing'] ?? false, data['followersCount']);
          _showSnackbar(data['isFollowing'] ? 'Followed @${_users[idx].username}' : 'Unfollowed @${_users[idx].username}');
          await _fetchUsers();
          return;
        }
      }
      _rollbackUser(idx, currentState);
      _showSnackbar('Failed to follow', isError: true);
    } catch (e) {
      print('[FOLLOW ERROR]: $e');
      _rollbackUser(idx, currentState);
      _showSnackbar('Error: ${e.toString()}', isError: true);
    }
  }

  void _updateUserLocally(int idx, bool isFollowing, [int? followers]) {
    setState(() {
      _users[idx].isFollowing = isFollowing;
      if (followers != null) {
        _users[idx].followers = followers;
      } else {
        _users[idx].followers += isFollowing ? 1 : -1;
      }
      final searchIdx = _searchResults.indexWhere((u) => u.id == _users[idx].id);
      if (searchIdx != -1) {
        _searchResults[searchIdx] = _users[idx];
      }
    });
  }

  void _rollbackUser(int idx, bool state) {
    setState(() {
      _users[idx].isFollowing = state;
      final searchIdx = _searchResults.indexWhere((u) => u.id == _users[idx].id);
      if (searchIdx != -1) _searchResults[searchIdx] = _users[idx];
    });
  }

  // ─── LIKE ──────────────────────────────────────────────────────────
  Future<void> _toggleLike(String postId) async {
    final idx = _posts.indexWhere((p) => p.id == postId);
    if (idx == -1) return;

    final currentState = _likeState[postId] ?? false;
    _updatePostLocally(idx, !currentState);

    try {
      final response = await http.post(
        Uri.parse('$API_BASE_URL/social/like'),
        headers: _headers(),
        body: jsonEncode({'postId': postId, 'username': widget.username}),
      ).timeout(const Duration(seconds: 10));

      print('[LIKE] Status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          _updatePostLocally(idx, data['isLiked'] ?? false, data['likeCount']);
          return;
        }
      }
      _rollbackPost(idx, currentState);
      _showSnackbar('Failed to like', isError: true);
    } catch (e) {
      print('[LIKE ERROR]: $e');
      _rollbackPost(idx, currentState);
      _showSnackbar('Error liking post', isError: true);
    }
  }

  void _updatePostLocally(int idx, bool isLiked, [int? likeCount]) {
    setState(() {
      _likeState[_posts[idx].id] = isLiked;
      _posts[idx].isLiked = isLiked;
      _posts[idx].likeCount = likeCount ?? _posts[idx].likeCount + (isLiked ? 1 : -1);
    });
  }

  void _rollbackPost(int idx, bool state) {
    setState(() {
      _likeState[_posts[idx].id] = state;
      _posts[idx].isLiked = state;
    });
  }

  // ─── COMMENT ──────────────────────────────────────────────────────
  Future<void> _addComment(String postId, String text) async {
    if (text.trim().isEmpty) { _showSnackbar('Comment cannot be empty'); return; }

    final temp = SocialComment(username: widget.username, text: text.trim(), createdAt: DateTime.now());
    final idx = _posts.indexWhere((p) => p.id == postId);
    if (idx != -1) {
      setState(() {
        final post = _posts[idx];
        final newComments = List<SocialComment>.from(post.comments)..add(temp);
        _posts[idx] = post.copyWith(
          comments: newComments,
          commentCount: post.commentCount + 1,
        );
      });
    }

    try {
      final response = await http.post(
        Uri.parse('$API_BASE_URL/social/comment'),
        headers: _headers(),
        body: jsonEncode({'postId': postId, 'username': widget.username, 'text': text.trim()}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        await _fetchPosts();
        _commentController.clear();
        setState(() => _commentingPostId = null);
        _showSnackbar('Comment added');
        return;
      }
      _rollbackComment(idx, temp);
      _showSnackbar('Failed to comment', isError: true);
    } catch (e) {
      print('[COMMENT ERROR]: $e');
      _rollbackComment(idx, temp);
      _showSnackbar('Error commenting', isError: true);
    }
  }

  void _rollbackComment(int idx, SocialComment temp) {
    if (idx != -1) {
      setState(() {
        final post = _posts[idx];
        final newComments = List<SocialComment>.from(post.comments)
          ..removeWhere((c) => c.username == temp.username && c.text == temp.text);
        _posts[idx] = post.copyWith(
          comments: newComments,
          commentCount: post.commentCount - 1,
        );
      });
    }
  }

  // ─── UPLOAD ──────────────────────────────────────────────────────
  Future<void> _uploadVideo() async {
    if (_selectedVideoPath == null) { 
      _showSnackbar('Select a video first'); 
      return; 
    }
    setState(() => _isUploading = true);

    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$API_BASE_URL/social/post'),
      );
      
      request.headers['Authorization'] = 'Bearer ${widget.sessionKey}';
      request.fields['key'] = widget.sessionKey;
      request.fields['caption'] = _postCaption;
      
      final file = await http.MultipartFile.fromPath('video', _selectedVideoPath!);
      request.files.add(file);

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();
      
      print('[UPLOAD VIDEO] Status: ${response.statusCode}');
      print('[UPLOAD VIDEO] Body: $responseBody');

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = jsonDecode(responseBody);
        if (data['success'] == true) {
          setState(() { 
            _selectedVideoPath = null; 
            _postCaption = ''; 
            _isUploading = false; 
          });
          await _fetchPosts();
          _showSnackbar('Video uploaded successfully');
          return;
        } else {
          _showSnackbar(data['message'] ?? data['error'] ?? 'Upload failed', isError: true);
        }
      } else {
        _showSnackbar('Upload failed: ${response.statusCode}', isError: true);
      }
    } catch (e) {
      print('[UPLOAD VIDEO ERROR]: $e');
      _showSnackbar('Error: ${e.toString()}', isError: true);
    }
    setState(() => _isUploading = false);
  }

  Future<void> _uploadImage() async {
    if (_selectedImagePath == null) { 
      _showSnackbar('Select an image first'); 
      return; 
    }
    setState(() => _isUploading = true);

    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$API_BASE_URL/social/post-image'),
      );
      
      request.headers['Authorization'] = 'Bearer ${widget.sessionKey}';
      request.fields['key'] = widget.sessionKey;
      request.fields['caption'] = _postCaption;
      
      final file = await http.MultipartFile.fromPath('image', _selectedImagePath!);
      request.files.add(file);

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();
      
      print('[UPLOAD IMAGE] Status: ${response.statusCode}');
      print('[UPLOAD IMAGE] Body: $responseBody');

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = jsonDecode(responseBody);
        if (data['success'] == true) {
          setState(() { 
            _selectedImagePath = null; 
            _postCaption = ''; 
            _isUploading = false; 
          });
          await _fetchPosts();
          _showSnackbar('Image uploaded successfully');
          return;
        } else {
          _showSnackbar(data['message'] ?? data['error'] ?? 'Upload failed', isError: true);
        }
      } else {
        _showSnackbar('Upload failed: ${response.statusCode}', isError: true);
      }
    } catch (e) {
      print('[UPLOAD IMAGE ERROR]: $e');
      _showSnackbar('Error: ${e.toString()}', isError: true);
    }
    setState(() => _isUploading = false);
  }

  // ─── UPLOAD PROFILE PICTURE ──────────────────────────────────────
  Future<void> _pickAndUploadImage() async {
    try {
      final picker = ImagePicker();
      final XFile? file = await picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 500,
        maxHeight: 500,
        imageQuality: 80,
      );
      if (file != null) {
        setState(() => _isUploading = true);
        await _uploadProfilePic(file.path);
      }
    } catch (e) {
      setState(() => _isUploading = false);
      _showSnackbar('Error picking image: $e', isError: true);
    }
  }

  Future<void> _uploadProfilePic(String path) async {
    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$API_BASE_URL/social/upload-pp'),
      );
      
      request.headers['Authorization'] = 'Bearer ${widget.sessionKey}';
      request.fields['key'] = widget.sessionKey;
      
      final file = await http.MultipartFile.fromPath('profilePic', path);
      request.files.add(file);

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();
      
      print('[UPLOAD PP] Status: ${response.statusCode}');
      print('[UPLOAD PP] Body: $responseBody');

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = jsonDecode(responseBody);
        if (data['success'] == true) {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('profile_image_${widget.username}', path);
          
          if (mounted) {
            setState(() {
              _profileImage = File(path);
              _isUploading = false;
            });
            await _fetchUsers();
            _showSnackbar('Profile picture updated');
          }
        } else {
          setState(() => _isUploading = false);
          _showSnackbar(data['message'] ?? data['error'] ?? 'Upload failed', isError: true);
        }
      } else {
        setState(() => _isUploading = false);
        _showSnackbar('Upload failed: ${response.statusCode}', isError: true);
      }
    } catch (e) {
      setState(() => _isUploading = false);
      _showSnackbar('Error: ${e.toString()}', isError: true);
    }
  }

  // ─── HELPERS ──────────────────────────────────────────────────────
  Future<void> _loadProfileImage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final path = prefs.getString('profile_image_${widget.username}');
      if (path != null && path.isNotEmpty) {
        final file = File(path);
        if (await file.exists()) {
          if (mounted) setState(() => _profileImage = file);
        }
      }
    } catch (_) {}
  }

  Future<void> _pickVideo() async {
    final file = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (file != null && mounted) {
      setState(() {
        _selectedVideoPath = file.path;
        _selectedImagePath = null;
        _isVideoUpload = true;
      });
    }
  }

  Future<void> _pickImage() async {
    final file = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 1080,
      maxHeight: 1080,
      imageQuality: 80,
    );
    if (file != null && mounted) {
      setState(() {
        _selectedImagePath = file.path;
        _selectedVideoPath = null;
        _isVideoUpload = false;
      });
    }
  }

  Future<void> _deletePost(String postId) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => _PremiumDialog(
        title: 'Delete Post',
        content: 'Are you sure you want to delete this post?',
        confirmText: 'Delete',
        isDanger: true,
      ).build(context),
    );
    if (confirm != true) return;

    try {
      final response = await http.delete(
        Uri.parse('$API_BASE_URL/social/post/$postId'),
        headers: _headers(),
        body: jsonEncode({'key': widget.sessionKey}),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        setState(() => _posts.removeWhere((p) => p.id == postId));
        _showSnackbar('Post deleted');
      }
    } catch (e) { 
      print('[DELETE POST ERROR]: $e');
      _showSnackbar('Delete failed', isError: true); 
    }
  }

  void _searchUsers(String query) {
    setState(() {
      _searchQuery = query;
      _searchResults = query.isEmpty
          ? _users
          : _users.where((u) => 
              u.username.toLowerCase().contains(query.toLowerCase()) ||
              u.name.toLowerCase().contains(query.toLowerCase())
            ).toList();
    });
  }

  void _showSnackbar(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          Icon(isError ? Icons.error_outline_rounded : Icons.check_circle_rounded,
            color: Colors.white, size: 20),
          const SizedBox(width: 12),
          Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
        ]),
        backgroundColor: isError ? SocialTheme.darkRed : SocialTheme.card,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: isError ? SocialTheme.red : SocialTheme.red.withOpacity(0.3)),
        ),
        elevation: 20,
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  SocialUser? _getCurrentUser() {
    try { 
      return _users.firstWhere((u) => u.username == widget.username || u.id == widget.username); 
    } catch (_) { return null; }
  }

  bool _isFollowing(String userId) {
    final user = _users.firstWhere(
      (u) => u.id == userId || u.username == userId,
      orElse: () => SocialUser(id: '', username: '', name: ''),
    );
    return user.isFollowing;
  }

  String _formatTime(DateTime date) {
    final diff = DateTime.now().difference(date);
    if (diff.inDays > 7) return '${diff.inDays}d ago';
    if (diff.inDays > 0) return '${diff.inDays}d ago';
    if (diff.inHours > 0) return '${diff.inHours}h ago';
    if (diff.inMinutes > 0) return '${diff.inMinutes}m ago';
    return 'Just now';
  }

  String _formatDuration(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return d.inHours > 0 ? '$h:$m:$s' : '$m:$s';
  }

  // ─── COMMENT DIALOG ───────────────────────────────────────────────
  void _showCommentDialog(String postId, List<SocialComment> comments) {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _CommentDialog(
        postId: postId,
        comments: comments,
        controller: ctrl,
        onSend: _addComment,
        formatTime: _formatTime,
      ),
    );
  }

  // ─── BUILD ──────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SocialTheme.bg,
      appBar: _buildPremiumAppBar(),
      body: _isLoading
          ? _buildLoadingScreen()
          : TabBarView(
              controller: _tabController,
              children: [
                _buildFeedTab(),
                _buildSearchTab(),
                _buildUploadTab(),
                _buildProfileTab(),
              ],
            ),
    );
  }

  // ─── WIDGETS ──────────────────────────────────────────────────────

  PreferredSizeWidget _buildPremiumAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      flexibleSpace: ClipRRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: SocialTheme.red.withOpacity(0.1))),
            ),
          ),
        ),
      ),
      title: Row(
        children: [
          AnimatedBuilder(
            animation: _glowCtrl,
            builder: (context, child) => Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [SocialTheme.gradientStart, SocialTheme.gradientEnd],
                ),
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: SocialTheme.red.withOpacity(_glowAnim.value),
                    blurRadius: 20,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: const Icon(Icons.bolt_rounded, color: Colors.white, size: 18),
            ),
          ),
          const SizedBox(width: 10),
          const Text(
            'BLACKDEATH SOCIAL',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: SocialTheme.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: SocialTheme.white24),
          ),
          child: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 20),
        ),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: SocialTheme.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: SocialTheme.white24),
          ),
          child: Row(
            children: [
              Container(width: 8, height: 8, decoration: const BoxDecoration(shape: BoxShape.circle, color: SocialTheme.green)),
              const SizedBox(width: 8),
              Text('Online', style: TextStyle(color: SocialTheme.white54, fontSize: 10)),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: SocialTheme.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: SocialTheme.white24),
          ),
          child: const Icon(Icons.notifications_none_rounded, color: SocialTheme.white54, size: 20),
        ),
        const SizedBox(width: 4),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(50),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: SocialTheme.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: SocialTheme.white24),
          ),
          child: TabBar(
            controller: _tabController,
            indicator: BoxDecoration(
              gradient: const LinearGradient(
                colors: [SocialTheme.gradientStart, SocialTheme.gradientEnd],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            indicatorSize: TabBarIndicatorSize.tab,
            labelColor: Colors.white,
            unselectedLabelColor: SocialTheme.white54,
            tabs: const [
              Tab(icon: Icon(Icons.home_rounded, size: 20), text: 'Feed'),
              Tab(icon: Icon(Icons.search_rounded, size: 20), text: 'Search'),
              Tab(icon: Icon(Icons.add_circle_rounded, size: 20), text: 'Upload'),
              Tab(icon: Icon(Icons.person_rounded, size: 20), text: 'Profile'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingScreen() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedBuilder(
            animation: _glowCtrl,
            builder: (context, child) => Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [SocialTheme.gradientStart, SocialTheme.gradientEnd],
                ),
                boxShadow: [
                  BoxShadow(
                    color: SocialTheme.red.withOpacity(_glowAnim.value),
                    blurRadius: 30,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: const Center(
                child: SizedBox(
                  width: 30,
                  height: 30,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          const Text('BLACKDEATH SOCIAL',
            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 2)),
          const SizedBox(height: 8),
          Text('Loading content...', style: TextStyle(color: SocialTheme.white54)),
        ],
      ),
    );
  }

  // ─── FEED TAB ──────────────────────────────────────────────────────
  Widget _buildFeedTab() {
    if (_posts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: SocialTheme.card,
                border: Border.all(color: SocialTheme.white24),
              ),
              child: const Icon(Icons.video_library_rounded, color: SocialTheme.white24, size: 40),
            ),
            const SizedBox(height: 16),
            const Text('NO POSTS YET',
              style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
            const SizedBox(height: 8),
            Text('Upload your first video or image now!', style: TextStyle(color: SocialTheme.white54)),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _fetchAllData,
      color: SocialTheme.red,
      backgroundColor: SocialTheme.card,
      child: ListView.builder(
        padding: const EdgeInsets.all(12),
        physics: const BouncingScrollPhysics(),
        itemCount: _posts.length,
        itemBuilder: (context, index) => _PostCard(
          post: _posts[index],
          isLiked: _likeState[_posts[index].id] ?? false,
          isFollowing: _isFollowing(_posts[index].userId),
          isOwner: _posts[index].username == widget.username || _posts[index].userId == widget.username,
          onFollow: _toggleFollow,
          onLike: _toggleLike,
          onComment: _addComment,
          onDelete: _deletePost,
          onCommentDialog: _showCommentDialog,
          formatTime: _formatTime,
          formatDuration: _formatDuration,
          videoControllers: _videoControllers,
          videoInitialized: _videoInitialized,
          commentController: _commentController,
          commentingPostId: _commentingPostId,
          onCommentingChanged: (id) => setState(() => _commentingPostId = id),
        ),
      ),
    );
  }

  // ─── SEARCH TAB ────────────────────────────────────────────────────
  Widget _buildSearchTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Container(
            decoration: BoxDecoration(
              color: SocialTheme.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: SocialTheme.white24),
            ),
            child: TextField(
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Search users...',
                hintStyle: TextStyle(color: SocialTheme.white54),
                prefixIcon: const Icon(Icons.search_rounded, color: SocialTheme.white54),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
              onChanged: _searchUsers,
            ),
          ),
        ),
        Expanded(
          child: _searchResults.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.search_off_rounded, color: SocialTheme.white24, size: 40),
                      const SizedBox(height: 12),
                      Text('No users found', style: TextStyle(color: SocialTheme.white54)),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _searchResults.length,
                  itemBuilder: (context, index) {
                    final user = _searchResults[index];
                    final isOwner = user.username == widget.username || user.id == widget.username;
                    return _UserTile(
                      user: user,
                      isOwner: isOwner,
                      onFollow: _toggleFollow,
                    );
                  },
                ),
        ),
      ],
    );
  }

  // ─── UPLOAD TAB ────────────────────────────────────────────────────
  Widget _buildUploadTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.upload_file_rounded, color: SocialTheme.red, size: 24),
              SizedBox(width: 8),
              Text('UPLOAD MEDIA',
                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
            ],
          ),
          const SizedBox(height: 8),
          Text('Share your video or image with all users', style: TextStyle(color: SocialTheme.white54)),
          const SizedBox(height: 16),

          // ─── Toggle Upload Type ──────────────────────────────────
          Row(
            children: [
              _buildUploadTypeButton('Video', Icons.videocam_rounded, true),
              const SizedBox(width: 12),
              _buildUploadTypeButton('Image', Icons.image_rounded, false),
            ],
          ),
          const SizedBox(height: 16),

          // ─── Upload Area ─────────────────────────────────────────
          GestureDetector(
            onTap: _isVideoUpload ? _pickVideo : _pickImage,
            child: Container(
              height: 220,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [SocialTheme.card, SocialTheme.cardAlt]),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: (_selectedVideoPath != null || _selectedImagePath != null) 
                      ? SocialTheme.red.withOpacity(0.3) 
                      : SocialTheme.white24,
                ),
              ),
              child: _selectedVideoPath != null && _isVideoUpload
                  ? _buildVideoPreview()
                  : _selectedImagePath != null && !_isVideoUpload
                      ? _buildImagePreview()
                      : _buildUploadPlaceholder(),
            ),
          ),
          const SizedBox(height: 16),

          // ─── Caption ─────────────────────────────────────────────
          Container(
            decoration: BoxDecoration(
              color: SocialTheme.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: SocialTheme.white24),
            ),
            child: TextField(
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                hintText: 'Write a caption... (optional)',
                hintStyle: TextStyle(color: SocialTheme.white54),
                border: InputBorder.none,
                contentPadding: EdgeInsets.all(16),
              ),
              maxLines: 3,
              onChanged: (v) => _postCaption = v,
            ),
          ),
          const SizedBox(height: 16),

          // ─── Upload Button ───────────────────────────────────────
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isUploading ? null : (_isVideoUpload ? _uploadVideo : _uploadImage),
              style: ElevatedButton.styleFrom(
                backgroundColor: SocialTheme.red,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: _isUploading
                  ? const SizedBox(width: 24, height: 24,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(_isVideoUpload ? Icons.cloud_upload_rounded : Icons.image_rounded, 
                            color: Colors.white),
                        const SizedBox(width: 8),
                        Text(
                          _isVideoUpload ? 'UPLOAD VIDEO' : 'UPLOAD IMAGE',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 12),

          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: SocialTheme.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: SocialTheme.white24),
            ),
            child: Row(
              children: [
                const Icon(Icons.info_outline_rounded, color: SocialTheme.red, size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _isVideoUpload 
                        ? 'Videos appear in everyone\'s feed. Max 100MB.'
                        : 'Images appear in everyone\'s feed. Max 10MB.',
                    style: TextStyle(color: SocialTheme.white54),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUploadTypeButton(String label, IconData icon, bool isVideo) {
    final isSelected = _isVideoUpload == isVideo;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() => _isVideoUpload = isVideo);
          if (!isVideo) _selectedVideoPath = null;
          else _selectedImagePath = null;
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? SocialTheme.card : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? SocialTheme.red.withOpacity(0.3) : SocialTheme.white24,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isSelected ? SocialTheme.red : SocialTheme.white54, size: 20),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.white : SocialTheme.white54,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVideoPreview() {
    return Stack(
      fit: StackFit.expand,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Image.file(File(_selectedVideoPath!), fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              color: SocialTheme.card,
              child: const Icon(Icons.video_library_rounded, color: SocialTheme.white24, size: 40),
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              colors: [Colors.transparent, Colors.black.withOpacity(0.6)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
        const Center(
          child: Icon(Icons.play_circle_filled, color: Colors.white, size: 60),
        ),
        Positioned(
          bottom: 16,
          right: 16,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.7),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: SocialTheme.red.withOpacity(0.3)),
            ),
            child: const Text('CHANGE',
              style: TextStyle(color: SocialTheme.white54, fontSize: 10, fontWeight: FontWeight.bold)),
          ),
        ),
        Positioned(
          top: 16,
          left: 16,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: SocialTheme.red.withOpacity(0.8),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Text('VIDEO',
              style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
          ),
        ),
      ],
    );
  }

  Widget _buildImagePreview() {
    return Stack(
      fit: StackFit.expand,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Image.file(File(_selectedImagePath!), fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              color: SocialTheme.card,
              child: const Icon(Icons.image_rounded, color: SocialTheme.white24, size: 40),
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              colors: [Colors.transparent, Colors.black.withOpacity(0.3)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
        Positioned(
          bottom: 16,
          right: 16,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.7),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: SocialTheme.red.withOpacity(0.3)),
            ),
            child: const Text('CHANGE',
              style: TextStyle(color: SocialTheme.white54, fontSize: 10, fontWeight: FontWeight.bold)),
          ),
        ),
        Positioned(
          top: 16,
          left: 16,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.blue.withOpacity(0.8),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Text('IMAGE',
              style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
          ),
        ),
      ],
    );
  }

  Widget _buildUploadPlaceholder() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: SocialTheme.red.withOpacity(0.05),
            border: Border.all(color: SocialTheme.red.withOpacity(0.2)),
          ),
          child: Icon(
            _isVideoUpload ? Icons.video_library_rounded : Icons.image_rounded,
            color: SocialTheme.white24, 
            size: 40
          ),
        ),
        const SizedBox(height: 12),
        Text(
          _isVideoUpload ? 'TAP TO SELECT VIDEO' : 'TAP TO SELECT IMAGE',
          style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(
          _isVideoUpload ? 'From your device gallery' : 'From your device gallery',
          style: TextStyle(color: SocialTheme.white54),
        ),
      ],
    );
  }

  // ─── PROFILE TAB ──────────────────────────────────────────────────
  Widget _buildProfileTab() {
    final user = _getCurrentUser();
    if (user == null) {
      return const Center(child: Text('User not found', style: TextStyle(color: SocialTheme.white54)));
    }

    final userPosts = _posts.where((p) => p.userId == user.id || p.username == user.username).toList();

    return RefreshIndicator(
      onRefresh: () => _fetchUserPosts(user.id),
      color: SocialTheme.red,
      backgroundColor: SocialTheme.card,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [SocialTheme.card, SocialTheme.cardAlt]),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: SocialTheme.white24),
              ),
              child: Column(
                children: [
                  GestureDetector(
                    onTap: _isUploading ? null : _pickAndUploadImage,
                    child: Stack(
                      children: [
                        Container(
                          width: 90,
                          height: 90,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              colors: [SocialTheme.gradientStart, SocialTheme.gradientEnd],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: SocialTheme.red.withOpacity(0.3),
                                blurRadius: 20,
                                spreadRadius: 5,
                              ),
                            ],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(
                                    _profileImage!,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(
                                      color: SocialTheme.card,
                                      child: const Icon(Icons.person_rounded, color: SocialTheme.white54, size: 40),
                                    ),
                                  )
                                : Container(
                                    color: SocialTheme.card,
                                    child: const Icon(Icons.person_rounded, color: SocialTheme.white54, size: 40),
                                  ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: _isUploading ? SocialTheme.white24 : SocialTheme.red,
                              shape: BoxShape.circle,
                              border: Border.all(color: SocialTheme.bg, width: 2),
                              boxShadow: [
                                BoxShadow(
                                  color: SocialTheme.red.withOpacity(0.3),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                            child: _isUploading
                                ? const SizedBox(
                                    width: 14,
                                    height: 14,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Icon(
                                    Icons.camera_alt_rounded,
                                    color: Colors.white,
                                    size: 14,
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(user.username,
                    style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron', letterSpacing: 0.5)),
                  Text(user.name, style: TextStyle(color: SocialTheme.white54)),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: SocialTheme.red.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: SocialTheme.red.withOpacity(0.2)),
                    ),
                    child: Text(user.role.toUpperCase(),
                      style: TextStyle(color: SocialTheme.red, fontSize: 10, fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _ProfileStat('Posts', userPosts.length.toString()),
                      _ProfileStat('Followers', user.followers.toString()),
                      _ProfileStat('Following', user.following.toString()),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            if (userPosts.isEmpty)
              Container(
                padding: const EdgeInsets.symmetric(vertical: 40),
                alignment: Alignment.center,
                child: Column(
                  children: [
                    Icon(Icons.video_library_rounded, color: SocialTheme.white24, size: 40),
                    const SizedBox(height: 8),
                    const Text('No posts yet', style: TextStyle(color: SocialTheme.white54)),
                  ],
                ),
              )
            else
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 4,
                  mainAxisSpacing: 4,
                ),
                itemCount: userPosts.length > 9 ? 9 : userPosts.length,
                itemBuilder: (context, index) {
                  final post = userPosts[index];
                  return Container(
                    decoration: BoxDecoration(
                      color: SocialTheme.card,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: SocialTheme.white24),
                    ),
                    child: Center(
                      child: post.videoUrl != null && post.videoUrl!.isNotEmpty
                          ? const Icon(Icons.video_library_rounded, color: SocialTheme.white24, size: 30)
                          : const Icon(Icons.image_rounded, color: SocialTheme.white24, size: 30),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }

  Widget _ProfileStat(String label, String value) {
    return Column(
      children: [
        Text(value,
          style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
        Text(label,
          style: TextStyle(color: SocialTheme.white54, fontSize: 12)),
      ],
    );
  }
}

// ─── WIDGET: POST CARD ─────────────────────────────────────────────

class _PostCard extends StatelessWidget {
  final SocialPost post;
  final bool isLiked;
  final bool isFollowing;
  final bool isOwner;
  final Function(String) onFollow;
  final Function(String) onLike;
  final Function(String, String) onComment;
  final Function(String) onDelete;
  final Function(String, List<SocialComment>) onCommentDialog;
  final String Function(DateTime) formatTime;
  final String Function(Duration) formatDuration;
  final Map<String, VideoPlayerController> videoControllers;
  final Map<String, bool> videoInitialized;
  final TextEditingController commentController;
  final String? commentingPostId;
  final Function(String?) onCommentingChanged;

  const _PostCard({
    required this.post,
    required this.isLiked,
    required this.isFollowing,
    required this.isOwner,
    required this.onFollow,
    required this.onLike,
    required this.onComment,
    required this.onDelete,
    required this.onCommentDialog,
    required this.formatTime,
    required this.formatDuration,
    required this.videoControllers,
    required this.videoInitialized,
    required this.commentController,
    required this.commentingPostId,
    required this.onCommentingChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [SocialTheme.card, SocialTheme.cardAlt]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isOwner ? SocialTheme.red.withOpacity(0.2) : SocialTheme.border,
          width: 0.5,
        ),
        boxShadow: [
          BoxShadow(
            color: SocialTheme.red.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            _buildMedia(),
            _buildCaption(),
            _buildActions(),
            _buildCommentsPreview(),
            _buildCommentInput(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: SocialTheme.white24, width: 0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [SocialTheme.gradientStart, SocialTheme.gradientEnd],
              ),
              boxShadow: [
                BoxShadow(
                  color: SocialTheme.red.withOpacity(0.2),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Center(
              child: Text(
                post.username.isNotEmpty ? post.username[0].toUpperCase() : 'U',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(post.username,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: SocialTheme.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: SocialTheme.red.withOpacity(0.2)),
                      ),
                      child: Text('${post.likeCount}',
                        style: const TextStyle(color: SocialTheme.red, fontSize: 8, fontWeight: FontWeight.bold)),
                    ),
                    if (post.imageUrl != null && post.imageUrl!.isNotEmpty) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.blue.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: Colors.blue.withOpacity(0.2)),
                        ),
                        child: const Text('📷',
                          style: TextStyle(fontSize: 8)),
                      ),
                    ],
                  ],
                ),
                Text(formatTime(post.createdAt),
                  style: const TextStyle(color: SocialTheme.white54, fontSize: 10)),
              ],
            ),
          ),
          if (!isOwner)
            GestureDetector(
              onTap: () => onFollow(post.userId),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  gradient: isFollowing ? null : const LinearGradient(
                    colors: [SocialTheme.gradientStart, SocialTheme.gradientEnd],
                  ),
                  color: isFollowing ? SocialTheme.white24 : null,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isFollowing ? SocialTheme.white24 : SocialTheme.red.withOpacity(0.3),
                    width: 0.5,
                  ),
                ),
                child: Text(
                  isFollowing ? 'Unfollow' : 'Follow',
                  style: TextStyle(
                    color: isFollowing ? SocialTheme.white54 : Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          if (isOwner)
            IconButton(
              icon: const Icon(Icons.more_horiz_rounded, color: SocialTheme.white54, size: 20),
              onPressed: () => onDelete(post.id),
            ),
        ],
      ),
    );
  }

  Widget _buildMedia() {
    // Jika ada video, tampilkan video
    if (post.videoUrl != null && post.videoUrl!.isNotEmpty) {
      final controller = videoControllers[post.id];
      final isInit = videoInitialized[post.id] ?? false;

      if (controller == null || !isInit) {
        return Container(
          height: 250,
          color: SocialTheme.card,
          child: const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(color: SocialTheme.red, strokeWidth: 2),
                SizedBox(height: 12),
                Text('Loading Video', style: TextStyle(color: SocialTheme.white54)),
              ],
            ),
          ),
        );
      }

      return Container(
        height: 250,
        color: Colors.black,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AspectRatio(
              aspectRatio: controller.value.aspectRatio,
              child: VideoPlayer(controller),
            ),
            GestureDetector(
              onTap: () {
                controller.value.isPlaying ? controller.pause() : controller.play();
              },
              child: Container(
                color: Colors.transparent,
                child: Center(
                  child: AnimatedOpacity(
                    opacity: controller.value.isPlaying ? 0.0 : 0.8,
                    duration: const Duration(milliseconds: 300),
                    child: Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [SocialTheme.gradientStart, SocialTheme.gradientEnd],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: SocialTheme.red.withOpacity(0.3),
                            blurRadius: 20,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: Icon(
                        controller.value.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                        color: Colors.white,
                        size: 32,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            if (controller.value.isBuffering)
              const Center(
                child: SizedBox(
                  width: 30,
                  height: 30,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                ),
              ),
            Positioned(
              bottom: 12,
              right: 16,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: SocialTheme.white24),
                ),
                child: Text(
                  formatDuration(controller.value.position),
                  style: const TextStyle(color: Colors.white, fontSize: 11),
                ),
              ),
            ),
            Positioned(
              bottom: 12,
              left: 16,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: SocialTheme.red.withOpacity(0.3)),
                ),
                child: const Text('HD',
                  style: TextStyle(color: SocialTheme.red, fontSize: 10, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      );
    }
    
    // Jika ada image, tampilkan image
    if (post.imageUrl != null && post.imageUrl!.isNotEmpty) {
      final imageUrl = post.imageUrl!.startsWith('http') 
          ? post.imageUrl! 
          : '${API_BASE_URL.replaceAll('/api', '')}${post.imageUrl!}';
      
      return Container(
        height: 250,
        color: SocialTheme.card,
        child: Image.network(
          imageUrl,
          fit: BoxFit.cover,
          loadingBuilder: (context, child, progress) {
            if (progress == null) return child;
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(color: SocialTheme.red, strokeWidth: 2),
                  const SizedBox(height: 12),
                  Text('Loading Image', style: TextStyle(color: SocialTheme.white54)),
                ],
              ),
            );
          },
          errorBuilder: (_, __, ___) => Container(
            color: SocialTheme.card,
            child: const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.broken_image_rounded, color: SocialTheme.white24, size: 40),
                  SizedBox(height: 12),
                  Text('Failed to load image', style: TextStyle(color: SocialTheme.white54)),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return const SizedBox.shrink();
  }

  Widget _buildCaption() {
    if (post.caption == null || post.caption!.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Text(post.caption!,
        style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.4)),
    );
  }

  Widget _buildActions() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => onLike(post.id),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: isLiked ? SocialTheme.red.withOpacity(0.1) : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isLiked ? SocialTheme.red.withOpacity(0.3) : Colors.transparent,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    isLiked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: isLiked ? SocialTheme.red : SocialTheme.white54,
                    size: 22,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    post.likeCount.toString(),
                    style: TextStyle(
                      color: isLiked ? SocialTheme.red : SocialTheme.white54,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 12),
          GestureDetector(
            onTap: () => onCommentDialog(post.id, post.comments),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: SocialTheme.white24),
              ),
              child: Row(
                children: [
                  const Icon(Icons.comment_rounded, color: SocialTheme.white54, size: 20),
                  const SizedBox(width: 6),
                  Text(
                    post.commentCount.toString(),
                    style: const TextStyle(color: SocialTheme.white54, fontSize: 13),
                  ),
                ],
              ),
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: SocialTheme.white24),
            ),
            child: const Icon(Icons.share_rounded, color: SocialTheme.white54, size: 20),
          ),
        ],
      ),
    );
  }

  Widget _buildCommentsPreview() {
    if (post.comments.isEmpty) return const SizedBox.shrink();
    return GestureDetector(
      onTap: () => onCommentDialog(post.id, post.comments),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        child: Text(
          'View ${post.comments.length} comments',
          style: const TextStyle(color: SocialTheme.white54, fontSize: 12),
        ),
      ),
    );
  }

  Widget _buildCommentInput() {
    final isActive = commentingPostId == post.id;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: SocialTheme.bg.withOpacity(0.3),
        border: Border(top: BorderSide(color: SocialTheme.white24, width: 0.3)),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: isActive ? commentController : TextEditingController(),
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Write a comment...',
                hintStyle: TextStyle(color: SocialTheme.white54),
                filled: true,
                fillColor: Colors.white.withOpacity(0.03),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                suffixIcon: isActive && commentController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.send_rounded, color: SocialTheme.red, size: 18),
                        onPressed: () => onComment(post.id, commentController.text),
                      )
                    : null,
              ),
              onChanged: (v) {
                if (commentingPostId != post.id) onCommentingChanged(post.id);
              },
              onSubmitted: (v) {
                if (commentingPostId != post.id) onCommentingChanged(post.id);
                onComment(post.id, v);
              },
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [SocialTheme.gradientStart, SocialTheme.gradientEnd],
              ),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: SocialTheme.red.withOpacity(0.3),
                  blurRadius: 10,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
          ),
        ],
      ),
    );
  }
}

// ─── WIDGET: USER TILE ─────────────────────────────────────────────

class _UserTile extends StatelessWidget {
  final SocialUser user;
  final bool isOwner;
  final Function(String) onFollow;

  const _UserTile({
    required this.user,
    required this.isOwner,
    required this.onFollow,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: SocialTheme.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: SocialTheme.white24),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [SocialTheme.gradientStart, SocialTheme.gradientEnd],
              ),
              boxShadow: [
                BoxShadow(
                  color: SocialTheme.red.withOpacity(0.2),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Center(
              child: Text(
                user.username[0].toUpperCase(),
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user.username,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                Text(user.name,
                  style: TextStyle(color: SocialTheme.white54, fontSize: 12)),
                Row(
                  children: [
                    Text('${user.followers} followers',
                      style: TextStyle(color: SocialTheme.white54, fontSize: 10)),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: SocialTheme.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(user.role.toUpperCase(),
                        style: TextStyle(color: SocialTheme.red, fontSize: 8, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (!isOwner)
            GestureDetector(
              onTap: () => onFollow(user.id),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: user.isFollowing ? null : const LinearGradient(
                    colors: [SocialTheme.gradientStart, SocialTheme.gradientEnd],
                  ),
                  color: user.isFollowing ? SocialTheme.white24 : null,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: user.isFollowing ? SocialTheme.white24 : SocialTheme.red.withOpacity(0.3),
                    width: 0.5,
                  ),
                ),
                child: Text(
                  user.isFollowing ? 'Unfollow' : 'Follow',
                  style: TextStyle(
                    color: user.isFollowing ? SocialTheme.white54 : Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ─── WIDGET: PREMIUM DIALOG ────────────────────────────────────────

class _PremiumDialog {
  final String title;
  final String content;
  final String confirmText;
  final bool isDanger;

  _PremiumDialog({
    required this.title,
    required this.content,
    required this.confirmText,
    this.isDanger = false,
  });

  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: SocialTheme.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
        side: BorderSide(
          color: isDanger ? SocialTheme.red : SocialTheme.red.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isDanger ? SocialTheme.red.withOpacity(0.1) : SocialTheme.red.withOpacity(0.05),
                border: Border.all(
                  color: isDanger ? SocialTheme.red.withOpacity(0.3) : SocialTheme.red.withOpacity(0.1),
                ),
              ),
              child: Icon(
                isDanger ? Icons.warning_rounded : Icons.info_outline_rounded,
                color: isDanger ? SocialTheme.red : SocialTheme.red,
                size: 28,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                letterSpacing: 0.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              content,
              style: TextStyle(color: SocialTheme.white54, fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(color: SocialTheme.white24),
                      ),
                    ),
                    child: const Text('Cancel', style: TextStyle(color: SocialTheme.white54)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context, true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isDanger ? SocialTheme.red : SocialTheme.red,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      confirmText,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ─── WIDGET: COMMENT DIALOG ────────────────────────────────────────

class _CommentDialog extends StatelessWidget {
  final String postId;
  final List<SocialComment> comments;
  final TextEditingController controller;
  final Function(String, String) onSend;
  final String Function(DateTime) formatTime;

  const _CommentDialog({
    required this.postId,
    required this.comments,
    required this.controller,
    required this.onSend,
    required this.formatTime,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.75,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [SocialTheme.card, SocialTheme.bg],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        border: Border(
          top: BorderSide(color: SocialTheme.red.withOpacity(0.2), width: 1),
        ),
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 12),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: SocialTheme.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Comments',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: SocialTheme.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: SocialTheme.red.withOpacity(0.2)),
                        ),
                        child: Text(
                          '${comments.length}',
                          style: const TextStyle(color: SocialTheme.red, fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                const Divider(color: SocialTheme.white24),
                Expanded(
                  child: comments.isEmpty
                      ? const Center(child: Text('No comments yet', style: TextStyle(color: SocialTheme.white54)))
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: comments.length,
                          itemBuilder: (context, index) {
                            final comment = comments[index];
                            return Container(
                              margin: const EdgeInsets.symmetric(vertical: 4),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: SocialTheme.bg.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: SocialTheme.white24),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CircleAvatar(
                                    radius: 16,
                                    backgroundColor: SocialTheme.red.withOpacity(0.1),
                                    child: Text(
                                      comment.username[0].toUpperCase(),
                                      style: const TextStyle(
                                        color: SocialTheme.red,
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Text(
                                              comment.username,
                                              style: const TextStyle(
                                                color: SocialTheme.red,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 12,
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              formatTime(comment.createdAt),
                                              style: const TextStyle(color: SocialTheme.white54, fontSize: 9),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          comment.text,
                                          style: const TextStyle(color: Colors.white, fontSize: 13),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(color: SocialTheme.white24, width: 0.3),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: controller,
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: 'Write a comment...',
                            hintStyle: TextStyle(color: SocialTheme.white54),
                            filled: true,
                            fillColor: Colors.white.withOpacity(0.03),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: () {
                          if (controller.text.isNotEmpty) {
                            onSend(postId, controller.text);
                            Navigator.pop(context);
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [SocialTheme.gradientStart, SocialTheme.gradientEnd],
                            ),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: SocialTheme.red.withOpacity(0.3),
                                blurRadius: 10,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }
}