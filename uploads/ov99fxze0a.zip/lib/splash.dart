import 'dart:ui'; 
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController videoController;
  late AnimationController fadeController;
  late AnimationController progressController;
  bool fadeOutStarted = false;
  double loadingProgress = 0.0;
  bool hasNavigated = false;

  // ─────────────────────────────────────────────
  //  CANDY APPLE SYSTEM THEME (RED NEON & GLOW)
  // ─────────────────────────────────────────────
  static const Color bgDark      = Color(0xFF0A0404); // Hitam pekat dengan tint merah gelap (Background)
  static const Color accentLava  = Color(0xFF8B0000); // Dark Red / Deep Maroon solid mendalam
  static const Color darkLava    = Color(0xFF1A0C0C); // Merah siber pekat sangat gelap
  static const Color lightLava   = Color(0xFFFF0800); // Candy Apple Red menyala cerah (Aksen Utama)
  static const Color frostLava   = Color(0xFFFFF0F0); // Putih bias merah sangat cerah

  LinearGradient get lavaGradient => const LinearGradient(
    colors: [accentLava, lightLava], // Gradasi mulus Maroon ke Candy Apple Red
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  void initState() {
    super.initState();
    
    progressController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..addListener(() {
      setState(() {
        loadingProgress = progressController.value;
      });
    });
    
    videoController = VideoPlayerController.asset("assets/videos/splash.mp4")
      ..initialize().then((_) {
        setState(() {});
        videoController.setLooping(false);
        videoController.play();
        progressController.forward();

        fadeController = AnimationController(
          vsync: this,
          duration: const Duration(seconds: 1),
        );

        videoController.addListener(() {
          final position = videoController.value.position;
          final duration = videoController.value.duration;

          if (duration != null &&
              position >= duration - const Duration(seconds: 1) &&
              !fadeOutStarted) {
            fadeOutStarted = true;
            fadeController.forward();
          }

          if (position >= duration && !hasNavigated) {
            navigateToDashboard();
          }
        });
      }).catchError((error) {
        // If video fails to load, auto navigate after 3 seconds
        debugPrint("Video failed to load: $error");
        progressController.forward();
        Future.delayed(const Duration(seconds: 3), () {
          if (!hasNavigated && mounted) {
            fadeOutStarted = true;
            fadeController.forward();
            Future.delayed(const Duration(milliseconds: 1000), () {
              if (mounted && !hasNavigated) {
                navigateToDashboard();
              }
            });
          }
        });
      });
  }

  void navigateToDashboard() {
    if (hasNavigated) return;
    hasNavigated = true;
    
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (context) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  void skipToDashboard() {
    if (hasNavigated) return;
    
    // Stop video and animations
    videoController.pause();
    if (fadeController.isAnimating) {
      fadeController.stop();
    }
    if (progressController.isAnimating) {
      progressController.stop();
    }
    
    navigateToDashboard();
  }

  @override
  void dispose() {
    videoController.dispose();
    fadeController.dispose();
    progressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: skipToDashboard,
      behavior: HitTestBehavior.opaque,
      child: Scaffold(
        backgroundColor: bgDark,
        body: Stack(
          children: [
            if (videoController.value.isInitialized)
              Positioned.fill(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: videoController.value.size.width,
                    height: videoController.value.size.height,
                    child: VideoPlayer(videoController),
                  ),
                ),
              )
            else
              Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.topLeft,
                    radius: 1.5,
                    colors: [
                      lightLava.withOpacity(0.15),
                      bgDark,
                      bgDark,
                    ],
                  ),
                ),
                child: const Center(
                  child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(lightLava),
                  ),
                ),
              ),

            Positioned.fill(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 0, sigmaY: 0),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        bgDark.withOpacity(0.4),
                        bgDark.withOpacity(0.9),
                      ],
                      stops: const [0.0, 0.4, 1.0],
                    ),
                  ),
                ),
              ),
            ),

            Positioned.fill(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Animated Logo Container with Logo Image
                    TweenAnimationBuilder(
                      tween: Tween<double>(begin: 0.8, end: 1.0),
                      duration: const Duration(milliseconds: 800),
                      builder: (context, double scale, child) {
                        return Transform.scale(
                          scale: scale,
                          child: Container(
                            width: 120,
                            height: 120,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: lavaGradient,
                              boxShadow: [
                                BoxShadow(
                                  color: lightLava.withOpacity(0.4),
                                  blurRadius: 30,
                                  spreadRadius: 5,
                                ),
                              ],
                            ),
                            child: ClipOval(
                              child: Image.asset(
                                'assets/images/logo.jpg',
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return Container(
                                    decoration: BoxDecoration(
                                      gradient: lavaGradient,
                                    ),
                                    child: const Icon(
                                      Icons.flash_on,
                                      color: frostLava,
                                      size: 60,
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                    
                    const SizedBox(height: 32),

                    // Glass Text Container for Title
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                      decoration: BoxDecoration(
                        color: const Color(0xFF261111).withOpacity(0.4), // Diubah ke tint merah transparan
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: lightLava.withOpacity(0.2)),
                      ),
                      child: Column(
                        children: [
                          ShaderMask(
                            shaderCallback: (bounds) => const LinearGradient(
                              colors: [lightLava, frostLava, accentLava],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ).createShader(bounds),
                            child: const Text(
                              "ᴠᴇxᴏʀᴠ",
                              style: TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                                color: frostLava,
                                letterSpacing: 3,
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          
                          // Glass Badge for Version
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.3),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: lightLava.withOpacity(0.15)),
                            ),
                            child: Text(
                              "V1.0 • Powered by @LekzoMarketV22",
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                                color: frostLava.withOpacity(0.8),
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 48),
                    
                    // Modern Glass Loading Progress Bar
                    Container(
                      width: 250,
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: lightLava.withOpacity(0.2)),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: Stack(
                          children: [
                            Container(
                              height: 4,
                              color: Colors.white.withOpacity(0.05),
                            ),
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 50),
                              width: 250 * loadingProgress,
                              height: 4,
                              decoration: BoxDecoration(
                                gradient: lavaGradient,
                                boxShadow: [
                                  BoxShadow(
                                    color: lightLava.withOpacity(0.6),
                                    blurRadius: 8,
                                    spreadRadius: 0,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 20),
                    
                    // Glass Percentage Badge
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withOpacity(0.05),
                            Colors.white.withOpacity(0.02),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: lightLava.withOpacity(0.15)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.bolt_rounded,
                            size: 14,
                            color: lightLava,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            "${(loadingProgress * 100).toInt()}% LOADING",
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: frostLava,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 40),

                    // ─── TOMBOL TEKS BARU DENGAN GLOW (CAHAYA TERANG DI PINGGIRAN TEKS) ───
                    _buildGlowTextButton(),

                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),

            // --- FADE OUT OVERLAY ---
            if (fadeOutStarted)
              FadeTransition(
                opacity: fadeController.drive(Tween(begin: 1.0, end: 0.0)),
                child: Container(color: bgDark),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildGlowTextButton() {
    return GestureDetector(
      onTap: skipToDashboard,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
        child: Text(
          "LANJUTKAN", 
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            letterSpacing: 2.5,
            color: lightLava, 
            shadows: [

              Shadow(
                blurRadius: 12,
                color: frostLava.withOpacity(0.6),
                offset: const Offset(0, 0),
              ),
      
              Shadow(
                blurRadius: 24,
                color: lightLava.withOpacity(0.5),
                offset: const Offset(0, 0),
              ),

              Shadow(
                blurRadius: 8,
                color: accentLava.withOpacity(0.4),
                offset: const Offset(0, 0),
              ),
            ],
          ),
        ),
      ),
    );
  }
}