import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// tools_gateway.dart - IMPORT DARI FOLDER game_zone/
import 'dart:ui';
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';

// ─── IMPORT SEMUA GAME DARI FOLDER game_zone/ ──────────────────────
import 'game_zone/block_blast.dart';
import 'game_zone/catur.dart';
import 'game_zone/ludo_game.dart';
import 'game_zone/pukul_tikus.dart';
import 'game_zone/ular_tangga.dart';
import 'game_zone/uno_game.dart';
// ──────────────────────────────────────────────────────────────────────

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  // ─── TEMA SCARRY (CYBER NEON DENGAN GRADASI BIRU-UNGU) ─────────────
  static const Color _bgDark = Color(0xFF0A0A0F);
  static const Color _cardDark = Color(0xFF14151C);
  static const Color _neonBlue = Color(0xFF1F51FF);
  static const Color _neonCyan = Color(0xFF00FFFF);
  static const Color _neonPurple = Color(0xFF9B59B6);
  static const Color _textWhite = Colors.white;
  static const Color _textGrey = Color(0xFF9AA0A6);

  // ─── MODUL SESUAI GAMBAR SCARRY TOOLS ──────────────────────────────
  final List<Map<String, dynamic>> _modules = const [
    {'icon': Icons.security, 'label': 'Security', 'action': 'coming_soon'},
    {'icon': Icons.search, 'label': 'OSINT Suite', 'action': 'osint'},
    {'icon': Icons.flash_on, 'label': 'Attack', 'action': 'ddos'},
    {'icon': Icons.wifi, 'label': 'Network', 'action': 'network'},
    {'icon': Icons.person_search, 'label': 'Osint', 'action': 'osint'},
    {'icon': Icons.build, 'label': 'Tools', 'action': 'utilities'},
    {'icon': Icons.email, 'label': '&Spam', 'action': 'spam'},
    {'icon': Icons.build, 'label': 'Tools', 'action': 'utilities'},
    {'icon': Icons.sports_esports, 'label': 'Entertain', 'action': 'entertain'},
    {'icon': Icons.gamepad, 'label': 'Game', 'action': 'games'}, // ← INI GUA UBAH!
    {'icon': Icons.more_horiz, 'label': 'Other', 'action': 'coming_soon'},
    {'icon': Icons.download, 'label': 'Media Tools', 'action': 'downloader'},
    {'icon': Icons.build, 'label': 'Tools', 'action': 'utilities'},
    {'icon': Icons.devices, 'label': 'Spyware', 'action': 'rat'},
    {'icon': Icons.star, 'label': 'ᴠᴇxᴏʀᴠ', 'action': 'coming_soon'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      body: Stack(
        children: [
          // ─── Background Grid & Glow ──────────────────────────────
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.topCenter,
                  radius: 1.2,
                  colors: [
                    _neonBlue.withOpacity(0.12),
                    Colors.transparent,
                    _neonPurple.withOpacity(0.06),
                  ],
                  stops: const [0.0, 0.5, 1.0],
                ),
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                // ─── HEADER SCARRY TOOLS ──────────────────────────────
                _buildHeader(),
                // ─── GRID MODULES ────────────────────────────────────
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    child: GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 0.85,
                      ),
                      itemCount: _modules.length,
                      itemBuilder: (context, index) {
                        final mod = _modules[index];
                        return _buildModuleCard(
                          icon: mod['icon'] as dynamic,
                          label: mod['label'] as String,
                          onTap: () => _handleAction(context, mod['action'] as String),
                        );
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── HEADER SCARRY TOOLS ─────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _neonBlue.withOpacity(0.15),
            _neonPurple.withOpacity(0.10),
            _neonBlue.withOpacity(0.15),
          ],
        ),
        border: Border(
          bottom: BorderSide(color: _neonBlue.withOpacity(0.3), width: 1.8),
        ),
        boxShadow: [
          BoxShadow(color: _neonBlue.withOpacity(0.2), blurRadius: 25, spreadRadius: 3),
        ],
      ),
      child: Column(
        children: [
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [_neonCyan, _neonBlue, _neonPurple],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ).createShader(bounds),
            child: Text(
              'ᴠᴇxᴏʀᴠ',
              style: TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 4,
                color: _textWhite,
                shadows: [
                  Shadow(color: _neonBlue.withOpacity(0.7), blurRadius: 15),
                  Shadow(color: _neonPurple.withOpacity(0.4), blurRadius: 8),
                ],
              ),
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _neonCyan,
                  boxShadow: [BoxShadow(color: _neonCyan.withOpacity(0.8), blurRadius: 8)],
                ),
              ),
              const SizedBox(width: 10),
              Text(
                '7 Modules',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                  color: _neonCyan.withOpacity(0.95),
                  shadows: [Shadow(color: _neonCyan.withOpacity(0.4), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 10),
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _neonPurple,
                  boxShadow: [BoxShadow(color: _neonPurple.withOpacity(0.8), blurRadius: 8)],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ─── KARTU MODUL ────────────────────────────────────────────────────
  Widget _buildModuleCard({
    required dynamic icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0.9, end: 1.0),
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeOutBack,
      builder: (context, double scale, child) => Transform.scale(scale: scale, child: child),
      child: GestureDetector(
        onTap: onTap,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    _cardDark.withOpacity(0.75),
                    _cardDark.withOpacity(0.45),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: _neonBlue.withOpacity(0.3),
                  width: 1.3,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _neonBlue.withOpacity(0.10),
                    blurRadius: 14,
                    spreadRadius: 1,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [_neonBlue.withOpacity(0.25), _neonPurple.withOpacity(0.25)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        border: Border.all(
                          color: _neonCyan.withOpacity(0.4),
                          width: 1.8,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: _neonCyan.withOpacity(0.2),
                            blurRadius: 12,
                            spreadRadius: 3,
                          ),
                        ],
                      ),
                      child: _DynamicIcon(icon, color: _textWhite, size: 28),
                    ),
                    const SizedBox(height: 10),
                    Flexible(
                      child: Text(
                        label,
                        style: TextStyle(
                          color: _textWhite,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                          shadows: [
                            Shadow(color: _neonBlue.withOpacity(0.4), blurRadius: 8),
                          ],
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── AKSI KETIKA KARTU DI TAP ──────────────────────────────────────
  void _handleAction(BuildContext context, String action) {
    switch (action) {
      case 'ddos':
        _showDDoSTools(context);
        break;
      case 'rat':
        _showDeviceDashboard(context);
        break;
      case 'network':
        _showNetworkTools(context);
        break;
      case 'osint':
        _showOSINTTools(context);
        break;
      case 'downloader':
        _showDownloaderTools(context);
        break;
      case 'utilities':
        _showUtilityTools(context);
        break;
      case 'spam':
        _showSpamTools(context);
        break;
      case 'entertain':
        _showEntertainTools(context);
        break;
      case 'games': // ← FITUR GAME!
        _showGameMenu(context);
        break;
      default:
        _showComingSoon(context);
    }
  }

  // ─── MENU GAME (6 GAME LENGKAP!) ──────────────────────────────────
  void _showGameMenu(BuildContext context) {
    _showCustomModal(
      context: context,
      title: "🎮 GAME ZONE",
      icon: Icons.gamepad,
      options: [
        _buildGameOption('🎲', 'Ludo', () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const LudoGamePage()));
        }),
        _buildGameOption('♟️', 'Catur', () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const CaturPage()));
        }),
        _buildGameOption('🐭', 'Pukul Tikus', () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const PukulTikusPage()));
        }),
        _buildGameOption('🐍', 'Ular Tangga', () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const UlarTanggaPage()));
        }),
        _buildGameOption('🃏', 'UNO', () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const UnoGamePage()));
        }),
        _buildGameOption('🧱', 'Block Blast', () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const BlockBlastPage()));
        }),
      ],
    );
  }

  // ─── MENU ENTERTAIN ──────────────────────────────────────────────────
  void _showEntertainTools(BuildContext context) {
    _showCustomModal(
      context: context,
      title: "🎬 Entertain",
      icon: Icons.movie,
      options: [
        _buildToolOption(Icons.music_note, "Music Player", () => _showComingSoon(context)),
        _buildToolOption(Icons.videocam, "Video Player", () => _showComingSoon(context)),
        _buildToolOption(Icons.emoji_emotions, "Meme Generator", () => _showComingSoon(context)),
      ],
    );
  }

  // ─── MENU SPAM ──────────────────────────────────────────────────────
  void _showSpamTools(BuildContext context) {
    _showCustomModal(
      context: context,
      title: "Spam Tools",
      icon: Icons.email,
      options: [
        _buildToolOption(Icons.newspaper_outlined, "Spam NGL", () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const NglPage()));
        }),
        _buildToolOption(Icons.sms, "SMS Spam", () => _showComingSoon(context)),
      ],
    );
  }

  // ─── MENU DDOS ──────────────────────────────────────────────────────
  void _showDDoSTools(BuildContext context) {
    _showCustomModal(
      context: context,
      title: "DDoS Tools",
      icon: Icons.flash_on,
      options: [
        _buildToolOption(Icons.flash_on, "Attack Panel", () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => AttackPanel(sessionKey: sessionKey, listDoos: listDoos)));
        }),
        _buildToolOption(Icons.dns, "Manage Server", () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => ManageServerPage(keyToken: sessionKey)));
        }),
        _buildToolOption(Icons.devices_rounded, "Device Hub (RAT)", () {
          Navigator.pop(context);
          _showComingSoon(context);
        }),
      ],
    );
  }

  void _showDeviceDashboard(BuildContext context) {
    _showCustomModal(
      context: context,
      title: "Device Controller",
      icon: Icons.devices_rounded,
      options: [
        _buildToolOption(Icons.terminal, "Open RAT Dashboard", () {
          Navigator.pop(context);
          _showComingSoon(context);
        }),
      ],
    );
  }

  void _showNetworkTools(BuildContext context) {
    _showCustomModal(
      context: context,
      title: "Network Tools",
      icon: Icons.wifi,
      options: [
        _buildToolOption(Icons.newspaper_outlined, "Spam NGL", () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const NglPage()));
        }),
        _buildToolOption(Icons.wifi_off, "WiFi Killer (Internal)", () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const WifiKillerPage()));
        }),
        if (userRole == "vip" || userRole == "owner")
          _buildToolOption(Icons.router, "WiFi Killer (External)", () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => WifiInternalPage(sessionKey: sessionKey)));
          }),
      ],
    );
  }

  void _showOSINTTools(BuildContext context) {
    _showCustomModal(
      context: context,
      title: "OSINT Tools",
      icon: Icons.search,
      options: [
        _buildToolOption(Icons.badge, "NIK Detail", () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
        }),
        _buildToolOption(Icons.domain, "Domain OSINT", () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const DomainOsintPage()));
        }),
        _buildToolOption(Icons.person_search, "Phone Lookup", () {
          Navigator.pop(context);
          _showComingSoon(context);
        }),
        _buildToolOption(Icons.email, "Email OSINT", () => _showComingSoon(context)),
      ],
    );
  }

  void _showDownloaderTools(BuildContext context) {
    _showCustomModal(
      context: context,
      title: "Media Downloader",
      icon: Icons.download,
      options: [
        _buildToolOption(Icons.video_library, "TikTok Downloader", () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
        }),
        _buildToolOption(Icons.camera_alt, "Instagram Downloader", () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
        }),
      ],
    );
  }

  void _showUtilityTools(BuildContext context) {
    _showCustomModal(
      context: context,
      title: "Utility Tools",
      icon: Icons.build,
      options: [
        _buildToolOption(Icons.qr_code, "QR Generator", () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
        }),
        _buildToolOption(Icons.security, "IP Scanner", () => _showComingSoon(context)),
        _buildToolOption(Icons.network_check, "Port Scanner", () => _showComingSoon(context)),
      ],
    );
  }

  // ─── BUILDER GAME OPTION ──────────────────────────────────────────
  Widget _buildGameOption(String emoji, String label, VoidCallback onTap) {
    return Card(
      color: const Color(0xFF1B1C1E),
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
        side: BorderSide(color: _neonCyan.withOpacity(0.2)),
      ),
      elevation: 4,
      shadowColor: Colors.black.withOpacity(0.3),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_neonBlue.withOpacity(0.2), _neonPurple.withOpacity(0.2)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
            border: Border.all(color: _neonCyan.withOpacity(0.3)),
          ),
          child: Text(emoji, style: const TextStyle(fontSize: 22)),
        ),
        title: Text(
          label,
          style: TextStyle(
            color: _textWhite,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
        trailing: Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: _neonCyan.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(Icons.play_arrow, color: _neonCyan, size: 18),
        ),
        onTap: onTap,
      ),
    );
  }

  // ─── MODAL BAWAH ────────────────────────────────────────────────────
  void _showCustomModal({
    required BuildContext context,
    required String title,
    required dynamic icon,
    required List<Widget> options,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: BoxDecoration(
          color: _cardDark,
          borderRadius: const BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)),
          border: Border.all(color: _neonBlue.withOpacity(0.2)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20, spreadRadius: 5)],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_neonBlue.withOpacity(0.3), _neonPurple.withOpacity(0.1)], begin: Alignment.centerLeft, end: Alignment.centerRight),
                borderRadius: const BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)),
                border: Border(bottom: BorderSide(color: _neonBlue.withOpacity(0.2))),
              ),
              child: Row(
                children: [
                  _DynamicIcon(icon, color: _textWhite),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    style: TextStyle(
                      color: _textWhite,
                      fontSize: 20,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(child: Padding(padding: const EdgeInsets.all(16), child: ListView(children: options))),
          ],
        ),
      ),
    );
  }

  Widget _buildToolOption(dynamic icon, String label, VoidCallback onTap) {
    return Card(
      color: const Color(0xFF1B1C1E),
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
        side: BorderSide(color: _neonBlue.withOpacity(0.15)),
      ),
      elevation: 4,
      shadowColor: Colors.black.withOpacity(0.3),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: _neonBlue.withOpacity(0.1),
            shape: BoxShape.circle,
            border: Border.all(color: _neonBlue.withOpacity(0.2)),
          ),
          child: _DynamicIcon(icon, color: _neonBlue),
        ),
        title: Text(
          label,
          style: TextStyle(color: _textWhite, fontFamily: 'Orbitron', fontWeight: FontWeight.w500),
        ),
        trailing: Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(color: _neonBlue.withOpacity(0.1), shape: BoxShape.circle),
          child: Icon(Icons.arrow_forward_ios, color: _neonBlue, size: 14),
        ),
        onTap: onTap,
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.hourglass_top, color: _textWhite),
            const SizedBox(width: 8),
            Text('Coming Soon!', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, color: _textWhite)),
          ],
        ),
        backgroundColor: const Color(0xFF2E3135),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

// ─── GRID BACKGROUND PAINTER ──────────────────────────────────────────
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF2E3135).withOpacity(0.12)
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;

    const double step = 30.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;

  const _DynamicIcon(this.icon, {Key? key, this.size, this.color}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);
    bool isFontAwesome = false;
    try {
      if (icon.runtimeType.toString().contains('FaIcon') || 
          icon.toString().contains('FaIcon') ||
          icon.toString().contains('font_awesome_flutter') ||
          icon.fontPackage == 'font_awesome_flutter') {
        isFontAwesome = true;
      }
    } catch (_) {}
    return Center(
      widthFactor: 1.0,
      heightFactor: 1.0,
      child: isFontAwesome ? FaIcon(icon, size: size, color: color) : Icon(icon, size: size, color: color),
    );
  }
}
// WEBA2APK_DYNAMIC_ICON_END
